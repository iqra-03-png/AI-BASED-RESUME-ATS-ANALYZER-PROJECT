import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { DATA_DIR } from './config.ts';

const DB_FILE = path.join(DATA_DIR, 'resunova_db.json');

export interface User {
  id: string;
  name: string;
  email: string;
  passwordHash: string;
  role: 'admin' | 'user';
  plan: 'free' | 'premium';
  createdAt: string;
}

export interface ResumeFile {
  id: string;
  userId: string;
  fileName: string;
  internalFileName: string;
  fileSize: number;
  fileType: string;
  extractedText: string;
  extractedData?: ExtractedResumeData;
  uploadedAt: string;
}

export interface ExtractedResumeData {
  fullName: string;
  email: string;
  phone: string;
  location: string;
  education: Array<{ degree: string; institution: string; year?: string; grade?: string }>;
  colleges: string[];
  technicalSkills: string[];
  softSkills: string[];
  workExperience: Array<{ role: string; company: string; duration?: string; description?: string }>;
  internships: Array<{ role: string; company: string; duration?: string; description?: string }>;
  projects: Array<{ title: string; description: string; technologies?: string[] }>;
  certifications: string[];
  achievements: string[];
  languages: string[];
  relevantJobDomains: string[];
  missingSections: string[];
}

export interface JobDomain {
  id: string;
  name: string;
  description: string;
  roles: string[];
  recommendedSkills: string[];
  icon?: string;
  isCustom?: boolean;
}

export interface SkillItem {
  id: string;
  name: string;
  category: 'technical' | 'soft' | 'tool';
  domain: string;
  priority: 'high' | 'medium' | 'low';
}

export interface AnalysisReport {
  id: string;
  userId: string;
  resumeId: string;
  resumeFileName: string;
  jobDomain: string;
  jobRole: string;
  jobDescription?: string;
  atsScore: number;
  scoreBreakdown: {
    keywordMatch: number;
    skillsMatch: number;
    experienceRelevance: number;
    educationRelevance: number;
    resumeStructure: number;
    readability: number;
  };
  matchedSkills: string[];
  missingSkills: {
    highPriority: string[];
    mediumPriority: string[];
    lowPriority: string[];
  };
  matchedKeywords: string[];
  missingKeywords: string[];
  structureChecks: Array<{ label: string; passed: boolean; note: string }>;
  suggestions: string[];
  strengths: string[];
  createdAt: string;
}

export interface ResumeTemplate {
  id: string;
  name: string;
  description: string;
  targetRole: string;
  tier: 'free' | 'premium';
  price: number;
  status: 'published' | 'draft' | 'unpublished';
  layoutStyle: 'modern-compact' | 'tech-minimal' | 'executive-dual' | 'creative-grid' | 'clean-classic';
  accentColor: string;
  fontFamily: string;
  tags: string[];
  thumbnailUrl?: string;
  updatedAt: string;
}

export interface ResumeDraft {
  id: string;
  userId: string;
  templateId: string;
  title: string;
  data: any;
  updatedAt: string;
}

export interface ChatMessage {
  id: string;
  userId: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

export interface DatabaseSchema {
  users: User[];
  resumes: ResumeFile[];
  domains: JobDomain[];
  skills: SkillItem[];
  reports: AnalysisReport[];
  templates: ResumeTemplate[];
  drafts: ResumeDraft[];
  entitlements: Array<{ userId: string; templateId: string; purchasedAt: string }>;
  chatMessages: ChatMessage[];
}

// Password hashing utility
export function hashPassword(password: string): string {
  return crypto.createHash('sha256').update(password + '_resunova_salt_2026').digest('hex');
}

// Initial default seed dataset
const initialDomains: JobDomain[] = [
  {
    id: 'dom-web',
    name: 'Web Development',
    description: 'Frontend, Backend, and Full-Stack Web engineering and application architecture.',
    roles: ['Frontend Developer', 'Backend Developer', 'Full-Stack Engineer', 'JavaScript Architect'],
    recommendedSkills: ['React', 'TypeScript', 'Node.js', 'Next.js', 'Tailwind CSS', 'GraphQL', 'REST APIs', 'PostgreSQL', 'HTML5/CSS3', 'Git'],
    icon: 'Globe',
  },
  {
    id: 'dom-soft',
    name: 'Software Development',
    description: 'Core systems, application development, microservices, and enterprise logic.',
    roles: ['Software Engineer', 'Senior Systems Architect', 'Application Developer', 'Platform Engineer'],
    recommendedSkills: ['Python', 'Java', 'C++', 'Data Structures & Algorithms', 'Design Patterns', 'System Design', 'CI/CD', 'Docker', 'Linux', 'Unit Testing'],
    icon: 'Code',
  },
  {
    id: 'dom-data',
    name: 'Data Science & Analytics',
    description: 'Machine learning, predictive modeling, statistical inference, and big data analysis.',
    roles: ['Data Scientist', 'Machine Learning Engineer', 'Data Analyst', 'BI Specialist'],
    recommendedSkills: ['Python', 'SQL', 'Pandas', 'NumPy', 'Scikit-Learn', 'PyTorch', 'TensorFlow', 'Data Visualization', 'Tableau', 'Statistical Analysis'],
    icon: 'BarChart2',
  },
  {
    id: 'dom-cloud',
    name: 'Cloud Computing & DevOps',
    description: 'Infrastructure as Code, orchestration, cloud security, automated pipelines, and SRE.',
    roles: ['DevOps Engineer', 'Cloud Architect', 'Site Reliability Engineer (SRE)', 'Platform Engineer'],
    recommendedSkills: ['AWS', 'Google Cloud', 'Kubernetes', 'Docker', 'Terraform', 'GitHub Actions', 'Linux Shell', 'Prometheus', 'Networking', 'Serverless'],
    icon: 'Cloud',
  },
  {
    id: 'dom-sec',
    name: 'Cybersecurity',
    description: 'Information security, vulnerability assessment, penetration testing, and compliance.',
    roles: ['Security Analyst', 'Penetration Tester', 'SOC Engineer', 'InfoSec Specialist'],
    recommendedSkills: ['Network Security', 'Penetration Testing', 'Wireshark', 'SIEM', 'OWASP Top 10', 'Cryptography', 'Identity & Access Management', 'Linux', 'Python'],
    icon: 'Shield',
  },
  {
    id: 'dom-uiux',
    name: 'UI/UX Design',
    description: 'User experience research, wireframing, high-fidelity prototyping, and design systems.',
    roles: ['UI/UX Designer', 'Product Designer', 'Interaction Designer', 'UX Researcher'],
    recommendedSkills: ['Figma', 'User Research', 'Wireframing', 'Prototyping', 'Design Systems', 'Usability Testing', 'Information Architecture', 'Visual Design', 'Accessibility (WCAG)'],
    icon: 'Palette',
  },
];

const initialSkills: SkillItem[] = [
  { id: 'sk-1', name: 'TypeScript', category: 'technical', domain: 'Web Development', priority: 'high' },
  { id: 'sk-2', name: 'React', category: 'technical', domain: 'Web Development', priority: 'high' },
  { id: 'sk-3', name: 'Node.js', category: 'technical', domain: 'Web Development', priority: 'high' },
  { id: 'sk-4', name: 'Tailwind CSS', category: 'technical', domain: 'Web Development', priority: 'medium' },
  { id: 'sk-5', name: 'Python', category: 'technical', domain: 'Software Development', priority: 'high' },
  { id: 'sk-6', name: 'Docker', category: 'tool', domain: 'Cloud Computing & DevOps', priority: 'high' },
  { id: 'sk-7', name: 'AWS', category: 'technical', domain: 'Cloud Computing & DevOps', priority: 'high' },
  { id: 'sk-8', name: 'Kubernetes', category: 'tool', domain: 'Cloud Computing & DevOps', priority: 'high' },
  { id: 'sk-9', name: 'SQL & Database Design', category: 'technical', domain: 'Data Science & Analytics', priority: 'high' },
  { id: 'sk-10', name: 'Machine Learning', category: 'technical', domain: 'Data Science & Analytics', priority: 'high' },
  { id: 'sk-11', name: 'Problem Solving & Critical Thinking', category: 'soft', domain: 'Software Development', priority: 'high' },
  { id: 'sk-12', name: 'Cross-functional Collaboration', category: 'soft', domain: 'Web Development', priority: 'medium' },
  { id: 'sk-13', name: 'Agile & Scrum Methodology', category: 'soft', domain: 'Software Development', priority: 'medium' },
  { id: 'sk-14', name: 'Figma', category: 'tool', domain: 'UI/UX Design', priority: 'high' },
  { id: 'sk-15', name: 'Git & Version Control', category: 'tool', domain: 'Software Development', priority: 'high' },
];

const initialTemplates: ResumeTemplate[] = [
  {
    id: 'tmpl-freshstart',
    name: 'FreshStart',
    description: 'Clean, modern entry-level and student layout prioritizing education, technical projects, and core competencies.',
    targetRole: 'Junior Developers & Graduates',
    tier: 'free',
    price: 0,
    status: 'published',
    layoutStyle: 'clean-classic',
    accentColor: '#2563eb', // Blue
    fontFamily: 'Inter',
    tags: ['Entry-Level', 'ATS-Optimized', 'Single-Column', 'Student'],
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'tmpl-techbasic',
    name: 'TechBasic',
    description: 'Streamlined developer template with terminal-inspired clarity, prominent skill tagging, and GitHub highlights.',
    targetRole: 'Software & Web Engineers',
    tier: 'free',
    price: 0,
    status: 'published',
    layoutStyle: 'tech-minimal',
    accentColor: '#059669', // Emerald
    fontFamily: 'JetBrains Mono',
    tags: ['Engineers', 'Code Focus', 'Fast Parser', 'Clean'],
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'tmpl-careeredge',
    name: 'CareerEdge',
    description: 'Impact-driven mid-senior format with quantified metric callouts, leadership bullet styling, and clean visual separators.',
    targetRole: 'Mid-Level & Senior Professionals',
    tier: 'premium',
    price: 299,
    status: 'published',
    layoutStyle: 'modern-compact',
    accentColor: '#7c3aed', // Purple/Violet
    fontFamily: 'Plus Jakarta Sans',
    tags: ['High ATS Match', 'Metrics Driven', 'Polished Header'],
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'tmpl-devpro',
    name: 'DevPro',
    description: 'Architect-grade template featuring technical stack matrices, system design achievements, and repository badges.',
    targetRole: 'Senior Developers & Leads',
    tier: 'premium',
    price: 499,
    status: 'published',
    layoutStyle: 'creative-grid',
    accentColor: '#3b82f6', // Bright Blue
    fontFamily: 'Plus Jakarta Sans',
    tags: ['Full-Stack', 'Cloud Ready', 'System Architecture'],
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'tmpl-eliteexec',
    name: 'EliteExecutive',
    description: 'Prestige executive layout emphasizing organizational leadership, revenue growth, board presentations, and strategic vision.',
    targetRole: 'Tech Leads, Directors & CTOs',
    tier: 'premium',
    price: 799,
    status: 'published',
    layoutStyle: 'executive-dual',
    accentColor: '#0f172a', // Slate Navy
    fontFamily: 'Plus Jakarta Sans',
    tags: ['Executive', 'Leadership', 'Strategic Growth'],
    updatedAt: new Date().toISOString(),
  },
];

class Database {
  private data: DatabaseSchema;

  constructor() {
    this.data = this.load();
  }

  private load(): DatabaseSchema {
    if (fs.existsSync(DB_FILE)) {
      try {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        return JSON.parse(raw);
      } catch (err) {
        console.error('Error reading database, creating fresh one:', err);
      }
    }

    const defaultDb: DatabaseSchema = {
      users: [
        {
          id: 'user-admin',
          name: 'ResuNova Admin',
          email: 'admin@resunova.ai',
          passwordHash: hashPassword('Admin@123'),
          role: 'admin',
          plan: 'premium',
          createdAt: new Date().toISOString(),
        },
        {
          id: 'user-iqra',
          name: 'Iqra',
          email: 'iqra@resunova.ai',
          passwordHash: hashPassword('User@123'),
          role: 'user',
          plan: 'premium',
          createdAt: new Date().toISOString(),
        },
      ],
      resumes: [
        {
          id: 'res-iqra-1',
          userId: 'user-iqra',
          fileName: 'Iqra_Resume.pdf',
          internalFileName: 'iqra-resume.pdf',
          fileSize: 142850,
          fileType: 'application/pdf',
          extractedText: 'Iqra\nFull-Stack Developer\niqra@resunova.ai\nExperience at NovaTech Solutions...',
          extractedData: {
            fullName: 'Iqra',
            email: 'iqra@resunova.ai',
            phone: '+1 (555) 349-8291',
            location: 'San Francisco, CA',
            education: [{ degree: 'B.S. in Computer Science', institution: 'University', year: '2020-2024' }],
            colleges: ['University'],
            technicalSkills: ['TypeScript', 'React', 'Node.js', 'PostgreSQL', 'Docker', 'GraphQL', 'AWS', 'Tailwind CSS'],
            softSkills: ['Problem Solving', 'Leadership', 'Agile Collaboration'],
            workExperience: [{ role: 'Senior Software Engineer', company: 'NovaTech Solutions', duration: '2022 - Present', description: 'Scaled microservices to 12M monthly requests.' }],
            internships: [],
            projects: [{ title: 'ResuNova ATS Intelligence', description: 'Engineered automated ATS diagnostics platform.', technologies: ['React', 'TypeScript', 'Node.js'] }],
            certifications: ['AWS Certified Solutions Architect'],
            achievements: ['Won 1st Place at Open Innovation Hackathon'],
            languages: ['English'],
            relevantJobDomains: ['Web Development', 'Software Development'],
            missingSections: [],
          },
          uploadedAt: new Date(Date.now() - 86400000 * 2).toISOString(),
        },
      ],
      domains: initialDomains,
      skills: initialSkills,
      reports: [
        {
          id: 'rep-iqra-1',
          userId: 'user-iqra',
          resumeId: 'res-iqra-1',
          resumeFileName: 'Iqra_Resume.pdf',
          jobDomain: 'Web Development',
          jobRole: 'Full-Stack Engineer',
          jobDescription: 'Senior full-stack role requiring React, TypeScript, Node.js, and CI/CD pipelines.',
          atsScore: 88,
          scoreBreakdown: {
            keywordMatch: 85,
            skillsMatch: 92,
            experienceRelevance: 90,
            educationRelevance: 88,
            resumeStructure: 95,
            readability: 90,
          },
          matchedSkills: ['React', 'TypeScript', 'Node.js', 'PostgreSQL', 'Docker', 'GraphQL', 'AWS', 'Tailwind CSS'],
          missingSkills: {
            highPriority: ['Kubernetes Orchestration', 'Micro-frontends'],
            mediumPriority: ['Redis Caching'],
            lowPriority: ['WebSockets'],
          },
          matchedKeywords: ['TypeScript', 'React', 'Node.js', 'API Design', 'PostgreSQL', 'Testing'],
          missingKeywords: ['Kubernetes', 'Terraform', 'Observability'],
          structureChecks: [
            { label: 'Contact Credentials', passed: true, note: 'Email and phone formatted accurately' },
            { label: 'Heading Semantics', passed: true, note: 'Standard industry headings detected' },
            { label: 'Experience Chronology', passed: true, note: 'Reverse chronological order followed' },
            { label: 'Skills Segmentation', passed: true, note: 'Clear technical breakdown present' },
            { label: 'Education Section', passed: true, note: 'Degree and university indexed' },
            { label: 'File Parseability', passed: true, note: 'Single column ATS-optimized typography' },
          ],
          suggestions: [
            'Quantify project outcomes with more business metrics (e.g., "Reduced latency by 32%").',
            'Incorporate cloud orchestration keywords like "Kubernetes" in system deployment bullets.',
            'Maintain single-column text layout for seamless parsing across legacy enterprise ATS portals.',
          ],
          strengths: [
            'High skill alignment in core modern web technologies (React, Node.js, TypeScript).',
            'Solid documented leadership and microservice architecture experience.',
          ],
          createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
        },
        {
          id: 'rep-iqra-2',
          userId: 'user-iqra',
          resumeId: 'res-iqra-1',
          resumeFileName: 'Iqra_Resume.pdf',
          jobDomain: 'Cloud Computing & DevOps',
          jobRole: 'Platform Engineer',
          jobDescription: 'Platform engineering role focused on AWS, Kubernetes, Terraform, and CI/CD.',
          atsScore: 80,
          scoreBreakdown: {
            keywordMatch: 75,
            skillsMatch: 82,
            experienceRelevance: 85,
            educationRelevance: 88,
            resumeStructure: 95,
            readability: 88,
          },
          matchedSkills: ['Docker', 'AWS', 'Linux', 'Node.js', 'Git'],
          missingSkills: {
            highPriority: ['Terraform', 'Kubernetes'],
            mediumPriority: ['Prometheus', 'Grafana'],
            lowPriority: ['Ansible'],
          },
          matchedKeywords: ['AWS', 'Docker', 'Linux', 'Git', 'CI/CD'],
          missingKeywords: ['Terraform', 'Kubernetes', 'Helm'],
          structureChecks: [
            { label: 'Contact Credentials', passed: true, note: 'Valid details present' },
            { label: 'Clear Headings', passed: true, note: 'Industry standard sections' },
            { label: 'Infrastructure Experience', passed: true, note: 'Cloud deployment projects documented' },
          ],
          suggestions: [
            'Highlight Infrastructure-as-Code examples utilizing Terraform or CloudFormation.',
            'Add monitoring and observability tools like Prometheus to your technical skills matrix.',
          ],
          strengths: [
            'Solid containerization foundation with Docker and AWS cloud deployments.',
          ],
          createdAt: new Date(Date.now() - 86400000).toISOString(),
        },
      ],
      templates: initialTemplates,
      drafts: [
        {
          id: 'drf-iqra-1',
          userId: 'user-iqra',
          templateId: 'tmpl-careeredge',
          title: 'CareerEdge - Senior Full Stack Draft',
          data: {
            fullName: 'Iqra',
            jobTitle: 'Senior Full-Stack & Cloud Engineer',
            email: 'iqra@resunova.ai',
            phone: '+1 (555) 349-8291',
            location: 'San Francisco, CA',
            website: 'github.com/iqra-dev',
            summary: 'Senior Full-Stack Developer with expertise in scalable microservices and cloud tooling.',
            experience: [
              {
                role: 'Senior Software Engineer',
                company: 'NovaTech Solutions',
                startDate: '2022',
                endDate: 'Present',
                bullets: ['Architected microservices handling 12M monthly requests.', 'Accelerated web vitals by 38%.'],
              },
            ],
            education: [{ degree: 'B.S. in Computer Science', institution: 'University', year: '2020 - 2024' }],
            projects: [{ name: 'ResuNova ATS Engine', technologies: 'React, TypeScript, Node.js', description: 'ATS analysis platform' }],
            skills: { technical: ['TypeScript', 'React', 'Node.js', 'Docker', 'AWS'], soft: ['Leadership', 'Problem Solving'], tools: ['Git', 'Postman'] },
          },
          updatedAt: new Date().toISOString(),
        },
      ],
      entitlements: [
        { userId: 'user-iqra', templateId: 'tmpl-careeredge', purchasedAt: new Date().toISOString() },
      ],
      chatMessages: [],
    };

    this.save(defaultDb);
    return defaultDb;
  }

  public save(dataToSave?: DatabaseSchema) {
    if (dataToSave) {
      this.data = dataToSave;
    }
    fs.writeFileSync(DB_FILE, JSON.stringify(this.data, null, 2), 'utf-8');
  }

  public get<K extends keyof DatabaseSchema>(table: K): DatabaseSchema[K] {
    return this.data[table];
  }

  // --- Users ---
  public findUserById(id: string): User | undefined {
    return this.data.users.find((u) => u.id === id);
  }

  public findUserByEmail(email: string): User | undefined {
    return this.data.users.find((u) => u.email.toLowerCase() === email.toLowerCase());
  }

  public createUser(user: Omit<User, 'id' | 'createdAt'>): User {
    const newUser: User = {
      ...user,
      id: 'usr_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      createdAt: new Date().toISOString(),
    };
    this.data.users.push(newUser);
    this.save();
    return newUser;
  }

  public updateUser(id: string, updates: Partial<User>): User | undefined {
    const user = this.findUserById(id);
    if (!user) return undefined;
    Object.assign(user, updates);
    this.save();
    return user;
  }

  public deleteUser(id: string): boolean {
    const index = this.data.users.findIndex((u) => u.id === id);
    if (index === -1) return false;
    this.data.users.splice(index, 1);
    // Cleanup user's resumes and reports
    this.data.resumes = this.data.resumes.filter((r) => r.userId !== id);
    this.data.reports = this.data.reports.filter((r) => r.userId !== id);
    this.data.drafts = this.data.drafts.filter((d) => d.userId !== id);
    this.save();
    return true;
  }

  // --- Resumes ---
  public addResume(resume: Omit<ResumeFile, 'id' | 'uploadedAt'>): ResumeFile {
    const newResume: ResumeFile = {
      ...resume,
      id: 'res_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      uploadedAt: new Date().toISOString(),
    };
    this.data.resumes.push(newResume);
    this.save();
    return newResume;
  }

  public getResume(id: string): ResumeFile | undefined {
    return this.data.resumes.find((r) => r.id === id);
  }

  public getUserResumes(userId: string): ResumeFile[] {
    return this.data.resumes
      .filter((r) => r.userId === userId)
      .sort((a, b) => new Date(b.uploadedAt).getTime() - new Date(a.uploadedAt).getTime());
  }

  public updateResumeExtractedData(id: string, data: ExtractedResumeData): ResumeFile | undefined {
    const resume = this.getResume(id);
    if (!resume) return undefined;
    resume.extractedData = data;
    this.save();
    return resume;
  }

  // --- Analysis Reports ---
  public addReport(report: Omit<AnalysisReport, 'id' | 'createdAt'>): AnalysisReport {
    const newReport: AnalysisReport = {
      ...report,
      id: 'rep_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      createdAt: new Date().toISOString(),
    };
    this.data.reports.push(newReport);
    this.save();
    return newReport;
  }

  public getReport(id: string): AnalysisReport | undefined {
    return this.data.reports.find((r) => r.id === id);
  }

  public getUserReports(userId: string): AnalysisReport[] {
    return this.data.reports
      .filter((r) => r.userId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  public getAllReports(): AnalysisReport[] {
    return [...this.data.reports].sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  public deleteReport(id: string, userId: string, isAdmin = false): boolean {
    const index = this.data.reports.findIndex(
      (r) => r.id === id && (isAdmin || r.userId === userId)
    );
    if (index === -1) return false;
    this.data.reports.splice(index, 1);
    this.save();
    return true;
  }

  // --- Domains & Skills ---
  public addDomain(domain: Omit<JobDomain, 'id'>): JobDomain {
    const newDomain: JobDomain = {
      ...domain,
      id: 'dom_' + Date.now(),
      isCustom: true,
    };
    this.data.domains.push(newDomain);
    this.save();
    return newDomain;
  }

  public updateDomain(id: string, updates: Partial<JobDomain>): JobDomain | undefined {
    const domain = this.data.domains.find((d) => d.id === id);
    if (!domain) return undefined;
    Object.assign(domain, updates);
    this.save();
    return domain;
  }

  public deleteDomain(id: string): boolean {
    const idx = this.data.domains.findIndex((d) => d.id === id);
    if (idx === -1) return false;
    this.data.domains.splice(idx, 1);
    this.save();
    return true;
  }

  public addSkill(skill: Omit<SkillItem, 'id'>): SkillItem {
    const newSkill: SkillItem = {
      ...skill,
      id: 'sk_' + Date.now(),
    };
    this.data.skills.push(newSkill);
    this.save();
    return newSkill;
  }

  public updateSkill(id: string, updates: Partial<SkillItem>): SkillItem | undefined {
    const skill = this.data.skills.find((s) => s.id === id);
    if (!skill) return undefined;
    Object.assign(skill, updates);
    this.save();
    return skill;
  }

  public deleteSkill(id: string): boolean {
    const idx = this.data.skills.findIndex((s) => s.id === id);
    if (idx === -1) return false;
    this.data.skills.splice(idx, 1);
    this.save();
    return true;
  }

  // --- Templates & Drafts ---
  public addTemplate(template: Omit<ResumeTemplate, 'id' | 'updatedAt'>): ResumeTemplate {
    const newTemplate: ResumeTemplate = {
      ...template,
      id: 'tmpl_' + Date.now(),
      updatedAt: new Date().toISOString(),
    };
    this.data.templates.push(newTemplate);
    this.save();
    return newTemplate;
  }

  public updateTemplate(id: string, updates: Partial<ResumeTemplate>): ResumeTemplate | undefined {
    const tmpl = this.data.templates.find((t) => t.id === id);
    if (!tmpl) return undefined;
    Object.assign(tmpl, updates, { updatedAt: new Date().toISOString() });
    this.save();
    return tmpl;
  }

  public deleteTemplate(id: string): boolean {
    const idx = this.data.templates.findIndex((t) => t.id === id);
    if (idx === -1) return false;
    this.data.templates.splice(idx, 1);
    this.save();
    return true;
  }

  public addEntitlement(userId: string, templateId: string) {
    const exists = this.data.entitlements.some(
      (e) => e.userId === userId && e.templateId === templateId
    );
    if (!exists) {
      this.data.entitlements.push({
        userId,
        templateId,
        purchasedAt: new Date().toISOString(),
      });
      this.save();
    }
  }

  public hasTemplateAccess(userId: string, template: ResumeTemplate, userRole: string): boolean {
    if (userRole === 'admin') return true;
    if (template.tier === 'free') return true;
    return this.data.entitlements.some(
      (e) => e.userId === userId && e.templateId === template.id
    );
  }

  public saveDraft(draft: Omit<ResumeDraft, 'id' | 'updatedAt'>): ResumeDraft {
    const existing = this.data.drafts.find(
      (d) => d.userId === draft.userId && d.templateId === draft.templateId
    );
    if (existing) {
      existing.title = draft.title;
      existing.data = draft.data;
      existing.updatedAt = new Date().toISOString();
      this.save();
      return existing;
    }
    const newDraft: ResumeDraft = {
      ...draft,
      id: 'drf_' + Date.now(),
      updatedAt: new Date().toISOString(),
    };
    this.data.drafts.push(newDraft);
    this.save();
    return newDraft;
  }

  public getUserDrafts(userId: string): ResumeDraft[] {
    return this.data.drafts.filter((d) => d.userId === userId);
  }

  // --- Chat ---
  public addChatMessage(msg: Omit<ChatMessage, 'id' | 'timestamp'>): ChatMessage {
    const newMsg: ChatMessage = {
      ...msg,
      id: 'msg_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      timestamp: new Date().toISOString(),
    };
    this.data.chatMessages.push(newMsg);
    // Keep max 50 recent messages per user
    const userMsgs = this.data.chatMessages.filter((m) => m.userId === msg.userId);
    if (userMsgs.length > 50) {
      const oldestId = userMsgs[0].id;
      this.data.chatMessages = this.data.chatMessages.filter((m) => m.id !== oldestId);
    }
    this.save();
    return newMsg;
  }

  public getUserChat(userId: string): ChatMessage[] {
    return this.data.chatMessages.filter((m) => m.userId === userId);
  }

  public clearUserChat(userId: string) {
    this.data.chatMessages = this.data.chatMessages.filter((m) => m.userId !== userId);
    this.save();
  }
}

export const db = new Database();
