import fs from 'fs';
import path from 'path';
import * as pdfParsePkg from 'pdf-parse';
const pdfParse: any = (pdfParsePkg as any).default || pdfParsePkg;
import mammoth from 'mammoth';
import { ai } from './config.ts';
import { ExtractedResumeData, JobDomain } from './db.ts';

// Extract raw text from uploaded file
export async function extractRawTextFromFile(filePath: string, originalName: string): Promise<string> {
  const ext = path.extname(originalName).toLowerCase();
  const fileBuffer = fs.readFileSync(filePath);

  if (ext === '.pdf') {
    try {
      const data = await pdfParse(fileBuffer);
      if (data && data.text && data.text.trim().length > 0) {
        return data.text.trim();
      }
    } catch (err: any) {
      console.warn('pdf-parse failed, attempting fallback text read:', err.message);
    }
    // Fallback if pdf has simple text stream or error
    const raw = fileBuffer.toString('utf-8').replace(/[^\x20-\x7E\n\r\t]/g, ' ');
    if (raw.trim().length > 50) return raw.trim();
    throw new Error('Unable to extract text from PDF. The file may be an image scan or corrupted.');
  }

  if (ext === '.docx') {
    try {
      const result = await mammoth.extractRawText({ buffer: fileBuffer });
      if (result && result.value && result.value.trim().length > 0) {
        return result.value.trim();
      }
    } catch (err: any) {
      console.warn('mammoth docx extraction error:', err.message);
    }
    throw new Error('Unable to extract text from DOCX document.');
  }

  if (ext === '.txt') {
    return fileBuffer.toString('utf-8');
  }

  throw new Error(`Unsupported file extension: ${ext}`);
}

// Fallback Rule-Based Extractor (ensures offline/non-AI resilience)
export function ruleBasedExtractResume(text: string): ExtractedResumeData {
  const lines = text.split('\n').map((l) => l.trim()).filter(Boolean);

  // Email regex
  const emailMatch = text.match(/([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9_-]+)/);
  const email = emailMatch ? emailMatch[1] : 'Not detected';

  // Phone regex
  const phoneMatch = text.match(/(\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}/);
  const phone = phoneMatch ? phoneMatch[0] : 'Not detected';

  // Name heuristic: First non-empty line without special characters
  let fullName = 'Not detected';
  for (const line of lines.slice(0, 5)) {
    if (!line.includes('@') && !line.includes('http') && line.length < 50 && /^[A-Za-z\s.'-]+$/.test(line)) {
      fullName = line;
      break;
    }
  }

  // Location heuristic
  const locationMatch = text.match(/\b([A-Z][a-zA-Z]+(?:\s[A-Z][a-zA-Z]+)?,\s*(?:[A-Z]{2}|[A-Za-z]+))\b/);
  const location = locationMatch ? locationMatch[1] : 'Not detected';

  // Skills dictionary
  const techSkillsDict = [
    'JavaScript', 'TypeScript', 'Python', 'Java', 'C++', 'C#', 'React', 'Angular', 'Vue.js',
    'Node.js', 'Express', 'Next.js', 'Tailwind CSS', 'HTML5', 'CSS3', 'SQL', 'PostgreSQL',
    'MySQL', 'MongoDB', 'Redis', 'Docker', 'Kubernetes', 'AWS', 'Azure', 'GCP', 'Git',
    'Linux', 'GraphQL', 'REST API', 'Pandas', 'NumPy', 'TensorFlow', 'PyTorch', 'Figma'
  ];
  const detectedTech = techSkillsDict.filter((s) => new RegExp(`\\b${s.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&')}\\b`, 'i').test(text));

  const softSkillsDict = [
    'Communication', 'Leadership', 'Problem Solving', 'Teamwork', 'Agile', 'Scrum',
    'Critical Thinking', 'Time Management', 'Adaptability', 'Mentorship'
  ];
  const detectedSoft = softSkillsDict.filter((s) => new RegExp(`\\b${s}\\b`, 'i').test(text));

  // Education detection
  const education: Array<{ degree: string; institution: string; year?: string }> = [];
  const degreeKeywords = ['Bachelor', 'Master', 'B.Tech', 'B.S.', 'M.S.', 'B.E.', 'PhD', 'Associate'];
  for (const line of lines) {
    for (const deg of degreeKeywords) {
      if (line.toLowerCase().includes(deg.toLowerCase())) {
        education.push({ degree: deg, institution: line.replace(deg, '').trim() || 'University' });
        break;
      }
    }
  }

  const colleges: string[] = [];
  const univKeywords = ['University', 'College', 'Institute', 'Academy', 'Polytechnic'];
  for (const line of lines) {
    if (univKeywords.some((u) => line.includes(u)) && line.length < 80) {
      colleges.push(line);
    }
  }

  // Work experience & Projects detection
  const workExperience: Array<{ role: string; company: string; duration?: string; description?: string }> = [];
  const projects: Array<{ title: string; description: string }> = [];

  // Check missing sections
  const missingSections: string[] = [];
  if (detectedTech.length === 0) missingSections.push('Technical Skills');
  if (workExperience.length === 0 && !text.toLowerCase().includes('experience')) missingSections.push('Work Experience');
  if (education.length === 0 && colleges.length === 0) missingSections.push('Education');
  if (!text.toLowerCase().includes('project')) missingSections.push('Projects');
  if (!text.toLowerCase().includes('certificat')) missingSections.push('Certifications');

  return {
    fullName,
    email,
    phone,
    location,
    education: education.length > 0 ? education : [{ degree: 'Degree not specified', institution: colleges[0] || 'Not detected' }],
    colleges: Array.from(new Set(colleges)),
    technicalSkills: detectedTech.length > 0 ? detectedTech : ['Basic Computer Skills'],
    softSkills: detectedSoft.length > 0 ? detectedSoft : ['Collaboration', 'Communication'],
    workExperience,
    internships: [],
    projects,
    certifications: [],
    achievements: [],
    languages: ['English'],
    relevantJobDomains: ['Software Development', 'Web Development'],
    missingSections,
  };
}

// AI-Powered Resume Information Extraction using Gemini 3.8 Flash
export async function extractResumeWithAI(rawText: string): Promise<ExtractedResumeData> {
  const fallback = ruleBasedExtractResume(rawText);

  if (!process.env.GEMINI_API_KEY) {
    return fallback;
  }

  try {
    const prompt = `You are an expert ATS and HR resume extraction system.
Extract structured information from the following resume text.
Rules:
- Do not hallucinate or invent fake names, phone numbers, or skills.
- If an item is not found, output "Not detected" or an empty array.
- Identify:
  1. Full Name
  2. Email Address
  3. Phone Number
  4. Location (City, State/Country)
  5. Education items (degree, institution, year, grade)
  6. Colleges / Universities
  7. Technical Skills (categorized list of actual technical tools, languages, frameworks)
  8. Soft Skills
  9. Work Experience (role, company, duration, description)
  10. Internships (role, company, duration, description)
  11. Projects (title, description, technologies)
  12. Certifications
  13. Achievements
  14. Languages
  15. Relevant Job Domains (e.g. Software Development, Web Development, Data Science, etc.)
  16. Missing or Incomplete Sections

Return ONLY valid JSON matching this schema:
{
  "fullName": "...",
  "email": "...",
  "phone": "...",
  "location": "...",
  "education": [{"degree": "...", "institution": "...", "year": "...", "grade": "..."}],
  "colleges": ["..."],
  "technicalSkills": ["..."],
  "softSkills": ["..."],
  "workExperience": [{"role": "...", "company": "...", "duration": "...", "description": "..."}],
  "internships": [{"role": "...", "company": "...", "duration": "...", "description": "..."}],
  "projects": [{"title": "...", "description": "...", "technologies": ["..."]}],
  "certifications": ["..."],
  "achievements": ["..."],
  "languages": ["..."],
  "relevantJobDomains": ["..."],
  "missingSections": ["..."]
}

Resume Text:
${rawText.slice(0, 15000)}
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    if (response.text) {
      const parsed = JSON.parse(response.text);
      return {
        fullName: parsed.fullName || fallback.fullName,
        email: parsed.email || fallback.email,
        phone: parsed.phone || fallback.phone,
        location: parsed.location || fallback.location,
        education: Array.isArray(parsed.education) && parsed.education.length > 0 ? parsed.education : fallback.education,
        colleges: Array.isArray(parsed.colleges) && parsed.colleges.length > 0 ? parsed.colleges : fallback.colleges,
        technicalSkills: Array.isArray(parsed.technicalSkills) && parsed.technicalSkills.length > 0 ? parsed.technicalSkills : fallback.technicalSkills,
        softSkills: Array.isArray(parsed.softSkills) && parsed.softSkills.length > 0 ? parsed.softSkills : fallback.softSkills,
        workExperience: Array.isArray(parsed.workExperience) ? parsed.workExperience : fallback.workExperience,
        internships: Array.isArray(parsed.internships) ? parsed.internships : fallback.internships,
        projects: Array.isArray(parsed.projects) ? parsed.projects : fallback.projects,
        certifications: Array.isArray(parsed.certifications) ? parsed.certifications : fallback.certifications,
        achievements: Array.isArray(parsed.achievements) ? parsed.achievements : fallback.achievements,
        languages: Array.isArray(parsed.languages) ? parsed.languages : fallback.languages,
        relevantJobDomains: Array.isArray(parsed.relevantJobDomains) && parsed.relevantJobDomains.length > 0 ? parsed.relevantJobDomains : fallback.relevantJobDomains,
        missingSections: Array.isArray(parsed.missingSections) ? parsed.missingSections : fallback.missingSections,
      };
    }
  } catch (err: any) {
    console.error('Gemini resume extraction error:', err.message);
  }

  return fallback;
}

// Generate comprehensive ATS Analysis
export async function performATSAnalysis({
  resumeText,
  extractedData,
  domain,
  role,
  jobDescription,
  domainData,
}: {
  resumeText: string;
  extractedData: ExtractedResumeData;
  domain: string;
  role: string;
  jobDescription?: string;
  domainData?: JobDomain;
}): Promise<{
  atsScore: number;
  scoreBreakdown: {
    keywordMatch: number;
    skillsMatch: number;
    experienceRelevance: number;
    educationRelevance: number;
    resumeStructure: number;
    readability: number;
  };
  matchedSkills: string[];
  missingSkills: {
    highPriority: string[];
    mediumPriority: string[];
    lowPriority: string[];
  };
  matchedKeywords: string[];
  missingKeywords: string[];
  structureChecks: Array<{ label: string; passed: boolean; note: string }>;
  suggestions: string[];
  strengths: string[];
}> {
  // Deterministic baseline calculation based on ResumeLens formula
  const recommendedDomainSkills = domainData?.recommendedSkills || [
    'TypeScript', 'React', 'Node.js', 'SQL', 'Git', 'Problem Solving', 'REST APIs', 'Cloud'
  ];

  const userSkillsSet = new Set(
    [
      ...extractedData.technicalSkills.map((s) => s.toLowerCase()),
      ...extractedData.softSkills.map((s) => s.toLowerCase()),
    ]
  );

  const matchedSkills: string[] = [];
  const missingHigh: string[] = [];
  const missingMedium: string[] = [];
  const missingLow: string[] = [];

  recommendedDomainSkills.forEach((skill, idx) => {
    if (userSkillsSet.has(skill.toLowerCase()) || resumeText.toLowerCase().includes(skill.toLowerCase())) {
      matchedSkills.push(skill);
    } else {
      if (idx < 3) missingHigh.push(skill);
      else if (idx < 7) missingMedium.push(skill);
      else missingLow.push(skill);
    }
  });

  // Structure checks
  const structureChecks = [
    {
      label: 'Contact Information',
      passed: extractedData.email !== 'Not detected' && extractedData.phone !== 'Not detected',
      note: extractedData.email !== 'Not detected' ? 'Valid email and phone present' : 'Missing contact phone or email',
    },
    {
      label: 'Clear Section Headings',
      passed: resumeText.toLowerCase().includes('experience') || resumeText.toLowerCase().includes('project'),
      note: 'Standard industry headings detected',
    },
    {
      label: 'Work Experience / Projects',
      passed: (extractedData.workExperience.length > 0 || extractedData.projects.length > 0),
      note: `${extractedData.workExperience.length} roles, ${extractedData.projects.length} projects documented`,
    },
    {
      label: 'Education Section',
      passed: extractedData.education.length > 0 && extractedData.education[0].degree !== 'Not detected',
      note: 'Degree and institution identified',
    },
    {
      label: 'Skills Categorization',
      passed: extractedData.technicalSkills.length >= 3,
      note: `${extractedData.technicalSkills.length} technical competencies indexed`,
    },
    {
      label: 'ATS Parseable Typography',
      passed: !resumeText.includes('') && resumeText.length > 200,
      note: 'Standard UTF-8 character encoding and consistent line breaks',
    },
  ];

  // Base scores
  const passedStructureCount = structureChecks.filter((c) => c.passed).length;
  const structureScore = Math.round((passedStructureCount / structureChecks.length) * 100);

  const skillsMatchRate = recommendedDomainSkills.length > 0
    ? matchedSkills.length / recommendedDomainSkills.length
    : 0.7;
  const skillsScore = Math.min(100, Math.round(skillsMatchRate * 100));

  const experienceScore = extractedData.workExperience.length > 0
    ? Math.min(100, 70 + extractedData.workExperience.length * 10)
    : extractedData.projects.length > 0 ? 75 : 50;

  const educationScore = extractedData.education.length > 0 ? 88 : 60;
  const readabilityScore = Math.min(100, Math.max(65, 100 - (extractedData.missingSections.length * 10)));

  // If Job Description provided, extract keywords
  let keywordScore = 75;
  const matchedKeywords: string[] = [...matchedSkills];
  const missingKeywords: string[] = [...missingHigh];

  if (jobDescription && jobDescription.trim().length > 20) {
    const jdWords = jobDescription
      .toLowerCase()
      .replace(/[^a-z0-9\s]/g, ' ')
      .split(/\s+/)
      .filter((w) => w.length > 4);
    const uniqueJdWords = Array.from(new Set(jdWords)).slice(0, 15);
    const resumeLower = resumeText.toLowerCase();

    const matchedJd = uniqueJdWords.filter((w) => resumeLower.includes(w));
    const missingJd = uniqueJdWords.filter((w) => !resumeLower.includes(w));

    matchedJd.forEach((w) => matchedKeywords.push(w.charAt(0).toUpperCase() + w.slice(1)));
    missingJd.slice(0, 6).forEach((w) => missingKeywords.push(w.charAt(0).toUpperCase() + w.slice(1)));

    keywordScore = Math.min(100, Math.round((matchedJd.length / Math.max(1, uniqueJdWords.length)) * 100));
  }

  // Final weighted formula (40% keywords, 25% skills, 15% structure, 10% exp/edu, 10% readability)
  const weightedATS = Math.round(
    keywordScore * 0.35 +
    skillsScore * 0.30 +
    structureScore * 0.15 +
    experienceScore * 0.10 +
    readabilityScore * 0.10
  );

  const initialSuggestions = [
    `Incorporate top domain keywords like "${missingHigh.slice(0, 3).join(', ')}" in your experience bullet points.`,
    'Quantify project outcomes with real business metrics (e.g., "Reduced latency by 32%", "Scaled to 10k users").',
    'Ensure standard section titles like "Work Experience", "Technical Skills", and "Education" are preserved for ATS scanners.',
    'Add links to verified portfolios, live GitHub repositories, or deployed demos.',
  ];

  const initialStrengths = [
    `Strong alignment in core tools: ${matchedSkills.slice(0, 4).join(', ') || 'General fundamentals'}.`,
    'Clear and easily extractable contact credentials and education records.',
    'Well-formed chronological project and career timeline.',
  ];

  // If Gemini is available, enhance with deep contextual suggestions
  if (process.env.GEMINI_API_KEY) {
    try {
      const prompt = `You are a Principal Talent Acquisition Architect & ATS Evaluation Engine.
Analyze this candidate's resume for the role: "${role}" in the domain "${domain}".

Target Job Description:
${jobDescription || 'Standard requirements for ' + role}

Candidate Extracted Resume:
${JSON.stringify(extractedData, null, 2)}

Provide detailed ATS suggestions and missing skills breakdown.
Return ONLY valid JSON matching this exact structure:
{
  "atsScore": ${weightedATS},
  "keywordMatch": ${keywordScore},
  "skillsMatch": ${skillsScore},
  "experienceRelevance": ${experienceScore},
  "educationRelevance": ${educationScore},
  "resumeStructure": ${structureScore},
  "readability": ${readabilityScore},
  "missingHighPriority": ["..."],
  "missingMediumPriority": ["..."],
  "missingLowPriority": ["..."],
  "matchedSkills": ["..."],
  "suggestions": ["...", "...", "..."],
  "strengths": ["...", "..."]
}`;

      const aiResponse = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: { responseMimeType: 'application/json' },
      });

      if (aiResponse.text) {
        const res = JSON.parse(aiResponse.text);
        return {
          atsScore: Math.min(100, Math.max(10, Math.round(res.atsScore || weightedATS))),
          scoreBreakdown: {
            keywordMatch: res.keywordMatch || keywordScore,
            skillsMatch: res.skillsMatch || skillsScore,
            experienceRelevance: res.experienceRelevance || experienceScore,
            educationRelevance: res.educationRelevance || educationScore,
            resumeStructure: res.resumeStructure || structureScore,
            readability: res.readability || readabilityScore,
          },
          matchedSkills: Array.isArray(res.matchedSkills) && res.matchedSkills.length > 0 ? res.matchedSkills : matchedSkills,
          missingSkills: {
            highPriority: Array.isArray(res.missingHighPriority) && res.missingHighPriority.length > 0 ? res.missingHighPriority : missingHigh,
            mediumPriority: Array.isArray(res.missingMediumPriority) && res.missingMediumPriority.length > 0 ? res.missingMediumPriority : missingMedium,
            lowPriority: Array.isArray(res.missingLowPriority) && res.missingLowPriority.length > 0 ? res.missingLowPriority : missingLow,
          },
          matchedKeywords: Array.from(new Set(matchedKeywords)).slice(0, 10),
          missingKeywords: Array.from(new Set(missingKeywords)).slice(0, 10),
          structureChecks,
          suggestions: Array.isArray(res.suggestions) && res.suggestions.length > 0 ? res.suggestions : initialSuggestions,
          strengths: Array.isArray(res.strengths) && res.strengths.length > 0 ? res.strengths : initialStrengths,
        };
      }
    } catch (err: any) {
      console.warn('Gemini ATS scoring fallback to deterministic metrics:', err.message);
    }
  }

  return {
    atsScore: weightedATS,
    scoreBreakdown: {
      keywordMatch: keywordScore,
      skillsMatch: skillsScore,
      experienceRelevance: experienceScore,
      educationRelevance: educationScore,
      resumeStructure: structureScore,
      readability: readabilityScore,
    },
    matchedSkills: matchedSkills.length > 0 ? matchedSkills : ['General Problem Solving'],
    missingSkills: {
      highPriority: missingHigh.length > 0 ? missingHigh : ['System Architecture', 'CI/CD Pipelines'],
      mediumPriority: missingMedium.length > 0 ? missingMedium : ['Automated Testing'],
      lowPriority: missingLow.length > 0 ? missingLow : ['Performance Benchmarking'],
    },
    matchedKeywords: Array.from(new Set(matchedKeywords)).slice(0, 10),
    missingKeywords: Array.from(new Set(missingKeywords)).slice(0, 10),
    structureChecks,
    suggestions: initialSuggestions,
    strengths: initialStrengths,
  };
}

// Generate Interactive Interview Questions
export async function generateInterviewPrep({
  role,
  domain,
  skills,
  projects,
}: {
  role: string;
  domain: string;
  skills: string[];
  projects: any[];
}): Promise<{
  technicalQuestions: Array<{ question: string; sampleAnswer: string; tips: string }>;
  hrQuestions: Array<{ question: string; sampleAnswer: string; tips: string }>;
  projectQuestions: Array<{ question: string; sampleAnswer: string; tips: string }>;
  skillQuestions: Array<{ question: string; sampleAnswer: string; tips: string }>;
  generalTips: string[];
}> {
  const defaultPrep = {
    technicalQuestions: [
      {
        question: `How do you handle state management and performance optimization in modern ${role} applications?`,
        sampleAnswer: `I implement localized state whenever possible to prevent unnecessary re-renders, leverage memoization (e.g. useMemo/useCallback), and utilize caching layers like React Query or Redis for async server state.`,
        tips: `Focus on architectural trade-offs, scalability, and measurable performance gains.`,
      },
      {
        question: `Explain how you design resilient APIs or services that gracefully handle network latency and failures.`,
        sampleAnswer: `I utilize exponential backoff retries, circuit breakers, idempotency keys for mutations, and graceful degradation with cached data.`,
        tips: `Mention status codes, timeout thresholds, and monitoring.`,
      },
    ],
    hrQuestions: [
      {
        question: `Tell me about a time you encountered a tight deadline or conflicting requirements from stakeholders.`,
        sampleAnswer: `I used the STAR method: identified the critical path, organized a rapid scoping session with product managers to descope non-essential items, and delivered the core MVP on time with zero regressions.`,
        tips: `Use the STAR format (Situation, Task, Action, Result) with quantified impact.`,
      },
      {
        question: `Why are you interested in advancing your career in the ${domain} domain?`,
        sampleAnswer: `I am deeply energized by solving complex user-facing challenges in ${domain}, and continuous improvement in this space drives my engineering philosophy.`,
        tips: `Connect your personal projects and recent learning directly to the role.`,
      },
    ],
    projectQuestions: [
      {
        question: `Walk me through the architecture of your most impactful project (${projects[0]?.title || 'Featured Project'}). What was the hardest challenge?`,
        sampleAnswer: `The system required high-throughput data processing. The biggest bottleneck was database connection pooling, which we resolved by implementing connection multiplexing and asynchronous background job queues.`,
        tips: `Highlight the technical decisions you personally made, not just the team's work.`,
      },
    ],
    skillQuestions: [
      {
        question: `You list ${skills[0] || 'Modern Technologies'} as a core skill. Can you explain a complex problem you resolved using it?`,
        sampleAnswer: `I used it to refactor a legacy module, improving test coverage by 40% and eliminating intermittent concurrency issues.`,
        tips: `Be ready to explain edge cases, internal workings, and memory or execution characteristics.`,
      },
    ],
    generalTips: [
      'Speak in active verbs and take ownership of your engineering outcomes.',
      'Practice pausing for 2-3 seconds to structure your thoughts before answering complex system design questions.',
      'Always prepare 3 thoughtful questions for the interviewers about team culture and technical roadmaps.',
    ],
  };

  if (process.env.GEMINI_API_KEY) {
    try {
      const prompt = `You are a Senior Principal Engineering Interviewer.
Generate high-caliber, realistic interview preparation questions tailored for a candidate applying for "${role}" in the "${domain}" domain.

Candidate's Skills: ${skills.slice(0, 10).join(', ')}
Candidate's Projects: ${projects.map((p) => p.title || p).slice(0, 3).join(', ')}

Return ONLY valid JSON matching this schema:
{
  "technicalQuestions": [{"question": "...", "sampleAnswer": "...", "tips": "..."}],
  "hrQuestions": [{"question": "...", "sampleAnswer": "...", "tips": "..."}],
  "projectQuestions": [{"question": "...", "sampleAnswer": "...", "tips": "..."}],
  "skillQuestions": [{"question": "...", "sampleAnswer": "...", "tips": "..."}],
  "generalTips": ["...", "...", "..."]
}
Include at least 3 technical, 3 HR, 2 project-specific, and 2 skill-specific questions.`;

      const res = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: { responseMimeType: 'application/json' },
      });

      if (res.text) {
        return JSON.parse(res.text);
      }
    } catch (err: any) {
      console.warn('Gemini interview prep fallback:', err.message);
    }
  }

  return defaultPrep;
}
