import express, { Request, Response, NextFunction } from 'express';
import { db, hashPassword, User, ResumeTemplate } from './db.ts';
import { upload, ai } from './config.ts';
import {
  extractRawTextFromFile,
  extractResumeWithAI,
  performATSAnalysis,
  generateInterviewPrep,
} from './parser.ts';

const router = express.Router();

// Helper: Extract user from Authorization Bearer token (base64 userId) or fallback to active demo session
function authenticate(req: Request): User | null {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.substring(7);
    try {
      const decoded = Buffer.from(token, 'base64').toString('utf-8');
      const [userId] = decoded.split(':');
      if (userId) {
        const user = db.findUserById(userId);
        if (user) return user;
      }
    } catch {
      // ignore
    }
  }

  // Fallback check header 'x-user-id'
  const customUserId = req.headers['x-user-id'] as string;
  if (customUserId) {
    const user = db.findUserById(customUserId);
    if (user) return user;
  }

  return null;
}

function requireAuth(req: Request, res: Response, next: NextFunction) {
  const user = authenticate(req);
  if (!user) {
    return res.status(401).json({ error: 'Authentication required. Please sign in.' });
  }
  (req as any).user = user;
  next();
}

function requireAdmin(req: Request, res: Response, next: NextFunction) {
  const user = authenticate(req);
  if (!user) {
    return res.status(401).json({ error: 'Authentication required.' });
  }
  if (user.role !== 'admin') {
    return res.status(403).json({ error: 'Access denied. Administrator privileges required.' });
  }
  (req as any).user = user;
  next();
}

function generateToken(user: User): string {
  return Buffer.from(`${user.id}:${Date.now()}`).toString('base64');
}

// ==========================================
// AUTHENTICATION ROUTES
// ==========================================
router.post('/auth/register', (req: Request, res: Response) => {
  try {
    const { name, email, password } = req.body;
    if (!name || !email || !password) {
      return res.status(400).json({ error: 'Name, email, and password are required.' });
    }
    if (password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters long.' });
    }
    const existing = db.findUserByEmail(email);
    if (existing) {
      return res.status(409).json({ error: 'An account with this email address already exists.' });
    }

    const newUser = db.createUser({
      name: name.trim(),
      email: email.trim().toLowerCase(),
      passwordHash: hashPassword(password),
      role: 'user',
      plan: 'free',
    });

    const token = generateToken(newUser);
    const { passwordHash, ...userSafe } = newUser;
    return res.status(201).json({ user: userSafe, token });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Registration failed.' });
  }
});

router.post('/auth/login', (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required.' });
    }
    const user = db.findUserByEmail(email);
    if (!user || user.passwordHash !== hashPassword(password)) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    const token = generateToken(user);
    const { passwordHash, ...userSafe } = user;
    return res.json({ user: userSafe, token });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Login failed.' });
  }
});

router.get('/auth/me', requireAuth, (req: Request, res: Response) => {
  const user = (req as any).user as User;
  const { passwordHash, ...userSafe } = user;
  return res.json({ user: userSafe });
});

router.post('/auth/update-profile', requireAuth, (req: Request, res: Response) => {
  try {
    const user = (req as any).user as User;
    const { name, email, currentPassword, newPassword } = req.body;

    const updates: Partial<User> = {};
    if (name) updates.name = name.trim();
    if (email && email.toLowerCase() !== user.email.toLowerCase()) {
      const existing = db.findUserByEmail(email);
      if (existing) return res.status(409).json({ error: 'Email already in use.' });
      updates.email = email.trim().toLowerCase();
    }

    if (newPassword) {
      if (!currentPassword || hashPassword(currentPassword) !== user.passwordHash) {
        return res.status(400).json({ error: 'Current password is incorrect.' });
      }
      if (newPassword.length < 6) {
        return res.status(400).json({ error: 'New password must be at least 6 characters.' });
      }
      updates.passwordHash = hashPassword(newPassword);
    }

    const updated = db.updateUser(user.id, updates);
    if (!updated) return res.status(404).json({ error: 'User not found.' });

    const { passwordHash, ...userSafe } = updated;
    return res.json({ user: userSafe, message: 'Profile updated successfully.' });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

router.post('/auth/upgrade-plan', requireAuth, (req: Request, res: Response) => {
  try {
    const user = (req as any).user as User;
    const updated = db.updateUser(user.id, { plan: 'premium' });
    if (!updated) return res.status(404).json({ error: 'User not found.' });
    const { passwordHash, ...userSafe } = updated;
    return res.json({ user: userSafe, message: 'Upgraded to Premium plan successfully!' });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// ==========================================
// RESUME UPLOAD & PARSING ROUTES
// ==========================================
router.post('/resume/upload', requireAuth, upload.single('resume'), async (req: Request, res: Response) => {
  try {
    const user = (req as any).user as User;
    if (!req.file) {
      return res.status(400).json({ error: 'No resume file uploaded.' });
    }

    const filePath = req.file.path;
    const originalName = req.file.originalname;
    const fileSize = req.file.size;
    const fileType = req.file.mimetype;

    // 1. Extract raw text from PDF/DOCX
    const rawText = await extractRawTextFromFile(filePath, originalName);

    // 2. Automatically detect and extract all 15 structured fields
    const extractedData = await extractResumeWithAI(rawText);

    // 3. Persist resume file record
    const resume = db.addResume({
      userId: user.id,
      fileName: originalName,
      internalFileName: req.file.filename,
      fileSize,
      fileType,
      extractedText: rawText,
      extractedData,
    });

    return res.status(201).json({
      message: 'Resume uploaded and analyzed successfully.',
      resume,
      extractedData,
    });
  } catch (err: any) {
    console.error('Resume upload error:', err);
    return res.status(500).json({ error: err.message || 'Failed to process resume file.' });
  }
});

router.post('/resume/:id/update-extracted', requireAuth, (req: Request, res: Response) => {
  try {
    const user = (req as any).user as User;
    const { id } = req.params;
    const resume = db.getResume(id);
    if (!resume) return res.status(404).json({ error: 'Resume not found.' });
    if (resume.userId !== user.id && user.role !== 'admin') {
      return res.status(403).json({ error: 'Unauthorized access to resume.' });
    }

    const updated = db.updateResumeExtractedData(id, req.body.extractedData);
    return res.json({ resume: updated, message: 'Detected details updated.' });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

router.get('/resume/my-resumes', requireAuth, (req: Request, res: Response) => {
  const user = (req as any).user as User;
  const resumes = db.getUserResumes(user.id);
  return res.json({ resumes });
});

// ==========================================
// RESUME ANALYSIS (ATS & DOMAIN MATCH)
// ==========================================
router.post('/resume/analyze', requireAuth, async (req: Request, res: Response) => {
  try {
    const user = (req as any).user as User;
    const { resumeId, domain, role, jobDescription, extractedDataOverride } = req.body;

    if (!resumeId || !domain || !role) {
      return res.status(400).json({ error: 'Resume, domain, and job role are required.' });
    }

    const resume = db.getResume(resumeId);
    if (!resume) return res.status(404).json({ error: 'Resume not found.' });
    if (resume.userId !== user.id && user.role !== 'admin') {
      return res.status(403).json({ error: 'Unauthorized.' });
    }

    const domains = db.get('domains');
    const domainData = domains.find(
      (d) => d.name.toLowerCase() === domain.toLowerCase() || d.id === domain
    );

    const extractedData = extractedDataOverride || resume.extractedData || {
      fullName: 'Candidate',
      email: 'Not detected',
      phone: 'Not detected',
      location: 'Not detected',
      education: [],
      colleges: [],
      technicalSkills: [],
      softSkills: [],
      workExperience: [],
      internships: [],
      projects: [],
      certifications: [],
      achievements: [],
      languages: [],
      relevantJobDomains: [domain],
      missingSections: [],
    };

    // Run ATS Analysis
    const analysisResult = await performATSAnalysis({
      resumeText: resume.extractedText,
      extractedData,
      domain,
      role,
      jobDescription,
      domainData,
    });

    // Save report to database
    const savedReport = db.addReport({
      userId: user.id,
      resumeId: resume.id,
      resumeFileName: resume.fileName,
      jobDomain: domain,
      jobRole: role,
      jobDescription,
      atsScore: analysisResult.atsScore,
      scoreBreakdown: analysisResult.scoreBreakdown,
      matchedSkills: analysisResult.matchedSkills,
      missingSkills: analysisResult.missingSkills,
      matchedKeywords: analysisResult.matchedKeywords,
      missingKeywords: analysisResult.missingKeywords,
      structureChecks: analysisResult.structureChecks,
      suggestions: analysisResult.suggestions,
      strengths: analysisResult.strengths,
    });

    return res.status(201).json({ report: savedReport });
  } catch (err: any) {
    console.error('Analysis error:', err);
    return res.status(500).json({ error: err.message || 'Analysis generation failed.' });
  }
});

// ==========================================
// HISTORY & REPORTS
// ==========================================
router.get('/history', requireAuth, (req: Request, res: Response) => {
  const user = (req as any).user as User;
  const reports = db.getUserReports(user.id);
  return res.json({ reports });
});

router.get('/history/:id', requireAuth, (req: Request, res: Response) => {
  const user = (req as any).user as User;
  const { id } = req.params;
  const report = db.getReport(id);
  if (!report) return res.status(404).json({ error: 'Report not found.' });
  if (report.userId !== user.id && user.role !== 'admin') {
    return res.status(403).json({ error: 'Unauthorized.' });
  }
  return res.json({ report });
});

router.delete('/history/:id', requireAuth, (req: Request, res: Response) => {
  const user = (req as any).user as User;
  const { id } = req.params;
  const success = db.deleteReport(id, user.id, user.role === 'admin');
  if (!success) return res.status(404).json({ error: 'Report not found or unauthorized.' });
  return res.json({ message: 'Report deleted successfully.' });
});

router.get('/history/compare/:id1/:id2', requireAuth, (req: Request, res: Response) => {
  const user = (req as any).user as User;
  const { id1, id2 } = req.params;
  const rep1 = db.getReport(id1);
  const rep2 = db.getReport(id2);
  if (!rep1 || !rep2) return res.status(404).json({ error: 'One or both reports were not found.' });
  if ((rep1.userId !== user.id || rep2.userId !== user.id) && user.role !== 'admin') {
    return res.status(403).json({ error: 'Unauthorized.' });
  }
  return res.json({ report1: rep1, report2: rep2 });
});

// ==========================================
// INTERVIEW PREPARATION
// ==========================================
router.post('/interview/prep', requireAuth, async (req: Request, res: Response) => {
  try {
    const { role, domain, skills, projects } = req.body;
    if (!role || !domain) {
      return res.status(400).json({ error: 'Target role and domain are required.' });
    }
    const prep = await generateInterviewPrep({
      role,
      domain,
      skills: Array.isArray(skills) ? skills : [],
      projects: Array.isArray(projects) ? projects : [],
    });
    return res.json(prep);
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Failed to generate interview prep.' });
  }
});

router.post('/interview/evaluate-answer', requireAuth, async (req: Request, res: Response) => {
  try {
    const { question, userAnswer, role } = req.body;
    if (!question || !userAnswer) {
      return res.status(400).json({ error: 'Question and answer are required.' });
    }

    if (!process.env.GEMINI_API_KEY) {
      return res.json({
        rating: 8,
        verdict: 'Good response with clear structure.',
        feedback: 'You covered the key technical points. Consider adding a specific metric or lesson learned.',
        strengths: ['Direct answer', 'Mentions relevant tools'],
        improvements: ['Include STAR methodology', 'Quantify team or performance impact'],
      });
    }

    const prompt = `You are an elite interview coach evaluating a candidate's answer for the role of ${role || 'Software Engineer'}.
Question: "${question}"
Candidate's Answer: "${userAnswer}"

Evaluate their response. Give an objective rating from 1 to 10.
Return ONLY valid JSON matching this schema:
{
  "rating": 8,
  "verdict": "Concise headline assessment",
  "feedback": "constructive 2-3 sentence evaluation",
  "strengths": ["...", "..."],
  "improvements": ["...", "..."]
}`;

    const aiRes = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: { responseMimeType: 'application/json' },
    });

    if (aiRes.text) {
      return res.json(JSON.parse(aiRes.text));
    }

    return res.json({
      rating: 7,
      verdict: 'Solid answer with practical examples.',
      feedback: 'Good technical understanding displayed.',
      strengths: ['Clear terminology'],
      improvements: ['State business outcomes'],
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Evaluation failed.' });
  }
});

// ==========================================
// RESUME TEMPLATES (SHARED ADMIN & USER)
// ==========================================
router.get('/templates', (req: Request, res: Response) => {
  const user = authenticate(req);
  const allTemplates = db.get('templates');

  // If Admin, return all (published, draft, unpublished)
  if (user && user.role === 'admin') {
    return res.json({
      templates: allTemplates.map((t) => ({ ...t, isUnlocked: true })),
    });
  }

  // If User or guest, return only published templates with unlocked flags
  const published = allTemplates.filter((t) => t.status === 'published');
  const enriched = published.map((t) => ({
    ...t,
    isUnlocked: user ? db.hasTemplateAccess(user.id, t, user.role) : t.tier === 'free',
  }));

  return res.json({ templates: enriched });
});

router.get('/templates/:id', (req: Request, res: Response) => {
  const user = authenticate(req);
  const { id } = req.params;
  const tmpl = db.get('templates').find((t) => t.id === id);
  if (!tmpl) return res.status(404).json({ error: 'Template not found.' });

  const isUnlocked = user ? db.hasTemplateAccess(user.id, tmpl, user.role) : tmpl.tier === 'free';
  return res.json({ template: { ...tmpl, isUnlocked } });
});

router.post('/templates/:id/purchase', requireAuth, (req: Request, res: Response) => {
  try {
    const user = (req as any).user as User;
    const { id } = req.params;
    const tmpl = db.get('templates').find((t) => t.id === id);
    if (!tmpl) return res.status(404).json({ error: 'Template not found.' });

    // Grant entitlement in database
    db.addEntitlement(user.id, id);
    return res.json({ message: `Successfully unlocked ${tmpl.name}!`, templateId: id, isUnlocked: true });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

router.post('/templates/:id/draft', requireAuth, (req: Request, res: Response) => {
  try {
    const user = (req as any).user as User;
    const { id } = req.params;
    const { title, data } = req.body;
    const draft = db.saveDraft({
      userId: user.id,
      templateId: id,
      title: title || 'My Resume Draft',
      data,
    });
    return res.json({ draft, message: 'Draft saved successfully.' });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

router.get('/templates/:id/draft', requireAuth, (req: Request, res: Response) => {
  const user = (req as any).user as User;
  const { id } = req.params;
  const drafts = db.getUserDrafts(user.id);
  const draft = drafts.find((d) => d.templateId === id);
  return res.json({ draft: draft || null });
});

router.get('/templates/drafts/all', requireAuth, (req: Request, res: Response) => {
  const user = (req as any).user as User;
  const drafts = db.getUserDrafts(user.id);
  return res.json({ drafts });
});

// ==========================================
// RESUNOVA AI ASSISTANT CHATBOT (USER ONLY)
// ==========================================
router.post('/chat', requireAuth, async (req: Request, res: Response) => {
  try {
    const user = (req as any).user as User;
    const { message, context } = req.body;

    if (!message || !message.trim()) {
      return res.status(400).json({ error: 'Message is required.' });
    }

    // Save user message in DB
    db.addChatMessage({
      userId: user.id,
      role: 'user',
      content: message,
    });

    let assistantReply = `I'd love to help improve your resume and boost your ATS score! For best results, ensure your technical achievements are quantifiable (e.g. "Improved database query latency by 45% using indexed views"). Feel free to ask me for domain-specific keywords or interview practice!`;

    if (process.env.GEMINI_API_KEY) {
      try {
        const systemPrompt = `You are "ResuNova AI Assistant", a friendly, senior career advisor, ATS optimization specialist, and interview coach.
The user is ${user.name} (Plan: ${user.plan}).
${context ? `Active Resume / Analysis Context: ${JSON.stringify(context)}` : ''}

Guidance:
- Give concise, actionable advice for resume bullet points, ATS keywords, missing skills, career growth, or technical interview questions.
- Use clean formatting, bullet points, and high-impact phrasing.
- Be encouraging, precise, and professional.`;

        const chatRes = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: `${systemPrompt}\n\nUser Question: ${message}`,
        });

        if (chatRes.text) {
          assistantReply = chatRes.text.trim();
        }
      } catch (err: any) {
        console.warn('Gemini chat fallback:', err.message);
      }
    }

    // Save assistant reply in DB
    const savedAssistantMsg = db.addChatMessage({
      userId: user.id,
      role: 'assistant',
      content: assistantReply,
    });

    return res.json({ reply: assistantReply, messageId: savedAssistantMsg.id });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Chat service encountered an error.' });
  }
});

router.get('/chat/history', requireAuth, (req: Request, res: Response) => {
  const user = (req as any).user as User;
  const messages = db.getUserChat(user.id);
  return res.json({ messages });
});

router.delete('/chat/clear', requireAuth, (req: Request, res: Response) => {
  const user = (req as any).user as User;
  db.clearUserChat(user.id);
  return res.json({ message: 'Chat history cleared.' });
});

// ==========================================
// ADMIN DASHBOARD & MANAGEMENT (PROTECTED)
// ==========================================
router.get('/admin/overview', requireAdmin, (_req: Request, res: Response) => {
  const users = db.get('users');
  const resumes = db.get('resumes');
  const domains = db.get('domains');
  const skills = db.get('skills');
  const reports = db.get('reports');

  const totalUsers = users.length;
  const totalResumes = resumes.length;
  const totalAnalyses = reports.length;
  const totalDomains = domains.length;
  const totalSkills = skills.length;

  const avgScore = totalAnalyses > 0
    ? Math.round(reports.reduce((acc, r) => acc + r.atsScore, 0) / totalAnalyses)
    : 78;

  // Domain popularity
  const domainCounts: Record<string, number> = {};
  reports.forEach((r) => {
    domainCounts[r.jobDomain] = (domainCounts[r.jobDomain] || 0) + 1;
  });

  const popularDomains = Object.entries(domainCounts)
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 5);

  return res.json({
    totalUsers,
    totalResumes,
    totalAnalyses,
    totalDomains,
    totalSkills,
    avgScore,
    popularDomains,
    recentReports: reports.slice(0, 6),
    recentUsers: users.slice(-5).map(({ passwordHash, ...u }) => u),
  });
});

router.get('/admin/users', requireAdmin, (_req: Request, res: Response) => {
  const users = db.get('users').map(({ passwordHash, ...u }) => {
    const userReports = db.getUserReports(u.id);
    const userResumes = db.getUserResumes(u.id);
    return {
      ...u,
      resumesCount: userResumes.length,
      analysesCount: userReports.length,
      avgAts: userReports.length > 0
        ? Math.round(userReports.reduce((a, b) => a + b.atsScore, 0) / userReports.length)
        : null,
    };
  });
  return res.json({ users });
});

router.put('/admin/users/:id/role', requireAdmin, (req: Request, res: Response) => {
  const { id } = req.params;
  const { role } = req.body;
  if (role !== 'user' && role !== 'admin') {
    return res.status(400).json({ error: 'Role must be user or admin.' });
  }
  const updated = db.updateUser(id, { role });
  if (!updated) return res.status(404).json({ error: 'User not found.' });
  const { passwordHash, ...safe } = updated;
  return res.json({ user: safe, message: `Role updated to ${role}.` });
});

router.delete('/admin/users/:id', requireAdmin, (req: Request, res: Response) => {
  const { id } = req.params;
  const currentUser = (req as any).user as User;
  if (currentUser.id === id) {
    return res.status(400).json({ error: 'Cannot delete your own administrator account.' });
  }
  const success = db.deleteUser(id);
  if (!success) return res.status(404).json({ error: 'User not found.' });
  return res.json({ message: 'User and all related records deleted.' });
});

// Domains CRUD
router.get('/admin/domains', (_req: Request, res: Response) => {
  const domains = db.get('domains');
  return res.json({ domains });
});

router.post('/admin/domains', requireAdmin, (req: Request, res: Response) => {
  const { name, description, roles, recommendedSkills, icon } = req.body;
  if (!name) return res.status(400).json({ error: 'Domain name is required.' });
  const newDomain = db.addDomain({
    name,
    description: description || '',
    roles: Array.isArray(roles) ? roles : [],
    recommendedSkills: Array.isArray(recommendedSkills) ? recommendedSkills : [],
    icon: icon || 'Briefcase',
  });
  return res.status(201).json({ domain: newDomain });
});

router.put('/admin/domains/:id', requireAdmin, (req: Request, res: Response) => {
  const { id } = req.params;
  const updated = db.updateDomain(id, req.body);
  if (!updated) return res.status(404).json({ error: 'Domain not found.' });
  return res.json({ domain: updated });
});

router.delete('/admin/domains/:id', requireAdmin, (req: Request, res: Response) => {
  const { id } = req.params;
  const success = db.deleteDomain(id);
  if (!success) return res.status(404).json({ error: 'Domain not found.' });
  return res.json({ message: 'Domain deleted.' });
});

// Skills CRUD
router.get('/admin/skills', (_req: Request, res: Response) => {
  const skills = db.get('skills');
  return res.json({ skills });
});

router.post('/admin/skills', requireAdmin, (req: Request, res: Response) => {
  const { name, category, domain, priority } = req.body;
  if (!name || !domain) return res.status(400).json({ error: 'Name and domain are required.' });
  const newSkill = db.addSkill({
    name,
    category: category || 'technical',
    domain,
    priority: priority || 'high',
  });
  return res.status(201).json({ skill: newSkill });
});

router.put('/admin/skills/:id', requireAdmin, (req: Request, res: Response) => {
  const { id } = req.params;
  const updated = db.updateSkill(id, req.body);
  if (!updated) return res.status(404).json({ error: 'Skill not found.' });
  return res.json({ skill: updated });
});

router.delete('/admin/skills/:id', requireAdmin, (req: Request, res: Response) => {
  const { id } = req.params;
  const success = db.deleteSkill(id);
  if (!success) return res.status(404).json({ error: 'Skill not found.' });
  return res.json({ message: 'Skill deleted.' });
});

// Admin Templates Management (CRUD, publish, unpublish, duplicate, delete)
router.get('/admin/templates', requireAdmin, (_req: Request, res: Response) => {
  const templates = db.get('templates');
  return res.json({ templates });
});

router.post('/admin/templates', requireAdmin, (req: Request, res: Response) => {
  const { name, description, targetRole, tier, price, status, layoutStyle, accentColor, fontFamily, tags } = req.body;
  if (!name) return res.status(400).json({ error: 'Template name is required.' });
  const newTemplate = db.addTemplate({
    name,
    description: description || '',
    targetRole: targetRole || 'All Roles',
    tier: tier || 'free',
    price: Number(price) || 0,
    status: status || 'draft',
    layoutStyle: layoutStyle || 'clean-classic',
    accentColor: accentColor || '#7c3aed',
    fontFamily: fontFamily || 'Plus Jakarta Sans',
    tags: Array.isArray(tags) ? tags : ['Modern', 'ATS-Friendly'],
  });
  return res.status(201).json({ template: newTemplate });
});

router.put('/admin/templates/:id', requireAdmin, (req: Request, res: Response) => {
  const { id } = req.params;
  const updated = db.updateTemplate(id, req.body);
  if (!updated) return res.status(404).json({ error: 'Template not found.' });
  return res.json({ template: updated, message: 'Template updated successfully.' });
});

router.post('/admin/templates/:id/duplicate', requireAdmin, (req: Request, res: Response) => {
  const { id } = req.params;
  const original = db.get('templates').find((t) => t.id === id);
  if (!original) return res.status(404).json({ error: 'Template not found.' });

  const duplicate = db.addTemplate({
    ...original,
    name: `${original.name} (Copy)`,
    status: 'draft',
  });
  return res.status(201).json({ template: duplicate, message: 'Template duplicated.' });
});

router.delete('/admin/templates/:id', requireAdmin, (req: Request, res: Response) => {
  const { id } = req.params;
  const success = db.deleteTemplate(id);
  if (!success) return res.status(404).json({ error: 'Template not found.' });
  return res.json({ message: 'Template deleted.' });
});

// Admin Analyses View
router.get('/admin/analyses', requireAdmin, (_req: Request, res: Response) => {
  const reports = db.getAllReports();
  const users = db.get('users');
  const enriched = reports.map((r) => {
    const user = users.find((u) => u.id === r.userId);
    return {
      ...r,
      userName: user ? user.name : 'Unknown User',
      userEmail: user ? user.email : 'Unknown',
    };
  });
  return res.json({ reports: enriched });
});

// Admin Analytics
router.get('/admin/analytics', requireAdmin, (_req: Request, res: Response) => {
  const reports = db.getAllReports();
  const users = db.get('users');
  const templates = db.get('templates');

  const scoreBuckets = { '90-100': 0, '80-89': 0, '70-79': 0, '60-69': 0, '<60': 0 };
  reports.forEach((r) => {
    if (r.atsScore >= 90) scoreBuckets['90-100']++;
    else if (r.atsScore >= 80) scoreBuckets['80-89']++;
    else if (r.atsScore >= 70) scoreBuckets['70-79']++;
    else if (r.atsScore >= 60) scoreBuckets['60-69']++;
    else scoreBuckets['<60']++;
  });

  return res.json({
    totalUsers: users.length,
    premiumUsers: users.filter((u) => u.plan === 'premium').length,
    totalAnalyses: reports.length,
    totalTemplates: templates.length,
    publishedTemplates: templates.filter((t) => t.status === 'published').length,
    scoreBuckets,
  });
});

export default router;
