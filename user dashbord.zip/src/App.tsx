import React, { useState } from 'react';
import { ToastProvider, useToast } from './context/ToastContext';
import { Sidebar, NavItemKey } from './components/layout/Sidebar';
import { Topbar } from './components/layout/Topbar';
import { DashboardOverview } from './views/DashboardOverview';
import { UserManagementView } from './views/UserManagementView';
import { JobDomainsView } from './views/JobDomainsView';
import { SkillsManagementView } from './views/SkillsManagementView';
import { ResumeAnalysisView } from './views/ResumeAnalysisView';
import { ResumeTemplatesView } from './views/ResumeTemplatesView';
import { ReportsAnalyticsView } from './views/ReportsAnalyticsView';
import { AdminProfileView } from './views/AdminProfileView';
import { LoginView } from './views/LoginView';
import { FlaskSchemaModal } from './components/common/FlaskSchemaModal';
import { ResuNovaStore } from './services/storage';
import { User, ResumeAnalysis } from './types';

function DashboardApp() {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(true);
  const [currentTab, setCurrentTab] = useState<NavItemKey>('dashboard');
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const [isFlaskModalOpen, setIsFlaskModalOpen] = useState(false);

  // Cross-view deep linking state
  const [targetAnalysis, setTargetAnalysis] = useState<ResumeAnalysis | null>(null);
  const [targetUser, setTargetUser] = useState<User | null>(null);
  const [targetDomainId, setTargetDomainId] = useState<string | null>(null);

  const toast = useToast();

  const handleRefreshData = () => {
    ResuNovaStore.init();
    toast.success('Database Synchronized', 'All MySQL entity tables reloaded from storage engine.');
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    toast.info('Session Ended', 'Logged out of ResuNova Administration.');
  };

  const handleViewUser = (user: User) => {
    setTargetUser(user);
    setCurrentTab('users');
  };

  const handleViewAnalysis = (analysis: ResumeAnalysis) => {
    setTargetAnalysis(analysis);
    setCurrentTab('analyses');
  };

  const handleSelectSearchResult = (result: import('./types').SearchResult) => {
    setCurrentTab(result.targetTab);
    if (result.targetTab === 'analyses' && result.itemData) {
      setTargetAnalysis(result.itemData);
    } else if (result.targetTab === 'users' && result.itemData) {
      setTargetUser(result.itemData);
    } else if (result.targetTab === 'domains' && result.itemData) {
      setTargetDomainId(result.itemData.id);
    }
  };

  if (!isAuthenticated) {
    return <LoginView onLoginSuccess={() => setIsAuthenticated(true)} />;
  }

  return (
    <div className="flex min-h-screen bg-[#F7F8FC] text-[#1F2937]">
      {/* Persistent Left Sidebar */}
      <Sidebar
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        isCollapsed={isSidebarCollapsed}
        onToggleCollapse={() => setIsSidebarCollapsed(prev => !prev)}
        isMobileOpen={isMobileSidebarOpen}
        onCloseMobile={() => setIsMobileSidebarOpen(false)}
        onLogout={handleLogout}
        onOpenFlaskModal={() => setIsFlaskModalOpen(true)}
      />

      {/* Main Content Viewport */}
      <div className="flex-1 flex flex-col min-w-0 min-h-screen overflow-x-hidden">
        {/* Topbar with Page Title, Search, Notifications, Profile */}
        <Topbar
          currentTab={currentTab}
          onSelectTab={setCurrentTab}
          onOpenMobileSidebar={() => setIsMobileSidebarOpen(true)}
          onRefreshData={handleRefreshData}
          onLogout={handleLogout}
          onOpenFlaskModal={() => setIsFlaskModalOpen(true)}
          onSelectSearchResult={handleSelectSearchResult}
        />

        {/* Content Workspace */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8">
          {currentTab === 'dashboard' && (
            <DashboardOverview
              onNavigate={setCurrentTab}
              onViewUser={handleViewUser}
              onViewAnalysis={handleViewAnalysis}
            />
          )}

          {currentTab === 'users' && (
            <UserManagementView
              initialSelectedUser={targetUser}
              onClearInitialUser={() => setTargetUser(null)}
              onInspectAnalysis={handleViewAnalysis}
            />
          )}

          {currentTab === 'domains' && (
            <JobDomainsView
              initialDomainId={targetDomainId}
              onClearInitialDomain={() => setTargetDomainId(null)}
            />
          )}

          {currentTab === 'skills' && <SkillsManagementView />}

          {currentTab === 'analyses' && (
            <ResumeAnalysisView
              initialSelectedAnalysis={targetAnalysis}
              onClearInitialSelection={() => setTargetAnalysis(null)}
            />
          )}

          {currentTab === 'templates' && <ResumeTemplatesView />}

          {currentTab === 'reports' && <ReportsAnalyticsView />}

          {currentTab === 'profile' && (
            <AdminProfileView
              onLogout={handleLogout}
              onOpenFlaskModal={() => setIsFlaskModalOpen(true)}
            />
          )}
        </main>
      </div>

      {/* Flask REST API & MySQL Database Architecture Modal */}
      <FlaskSchemaModal
        isOpen={isFlaskModalOpen}
        onClose={() => setIsFlaskModalOpen(false)}
      />
    </div>
  );
}

export default function App() {
  return (
    <ToastProvider>
      <DashboardApp />
    </ToastProvider>
  );
}
