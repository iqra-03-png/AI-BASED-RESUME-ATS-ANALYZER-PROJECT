export type RoleLevel = 'Junior' | 'Mid' | 'Senior' | 'Lead';
export type SkillImportance = 'High' | 'Medium' | 'Low';
export type QuestionCategory = 'Technical' | 'HR' | 'Behavioral' | 'Situational';
export type AnalysisStatus = 'Completed' | 'Processing' | 'Failed';

export interface User {
  id: string;
  name: string;
  email: string;
  role: string;
  status: 'active' | 'inactive';
  registrationDate: string;
  resumesAnalyzed: number;
  lastActive: string;
  avatar: string;
  university?: string;
}

export interface JobDomain {
  id: string;
  name: string;
  slug: string;
  description: string;
  rolesCount: number;
  skillsCount: number;
  active: boolean;
  iconName: string;
  createdAt: string;
}

export interface RoleSkillRequirement {
  skillId: string;
  skillName: string;
  importance: SkillImportance;
  weight: number; // 1.0 to 3.0
}

export interface JobRole {
  id: string;
  domainId: string;
  domainName: string;
  title: string;
  description: string;
  level: RoleLevel;
  requiredSkills: RoleSkillRequirement[];
  status: 'active' | 'inactive';
  updatedAt: string;
}

export interface Skill {
  id: string;
  name: string;
  category: 'Technical' | 'Soft Skills' | 'Framework' | 'Database' | 'Cloud' | 'DevOps' | 'Tooling';
  description: string;
  domainIds: string[];
  importance: SkillImportance;
  weight: number; // e.g. 1.0 to 3.0
  rolesUsingCount: number;
  createdAt: string;
}

export interface MatchedSkill {
  name: string;
  weight: number;
  foundContext: string;
}

export interface MissingSkill {
  name: string;
  weight: number;
  importance: SkillImportance;
  recommendation: string;
}

export interface ScoreBreakdown {
  skillMatch: number;      // max 40
  keywordDensity: number;  // max 25
  sectionStructure: number;// max 20
  formatting: number;      // max 15
}

export interface ResumeAnalysis {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  jobDomainId: string;
  jobDomainName: string;
  jobRoleId: string;
  jobRoleTitle: string;
  atsScore: number; // 0 - 100
  status: AnalysisStatus;
  analysisDate: string;
  processingTimeMs: number;
  fileName: string;
  fileSizeKb: number;
  matchedSkills: MatchedSkill[];
  missingSkills: MissingSkill[];
  scoreBreakdown: ScoreBreakdown;
  summaryFeedback: string;
  failureReason?: string;
}

export interface InterviewQuestion {
  id: string;
  question: string;
  sampleAnswer: string;
  category: QuestionCategory;
  domainId: string; // 'all' or specific domain id
  domainName: string;
  roleId?: string;
  roleTitle?: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  status: 'active' | 'inactive';
  createdAt: string;
}

export interface EducationItem {
  id: string;
  institution: string;
  degree: string;
  field: string;
  startYear: string;
  endYear: string;
  score: string;
}

export interface ExperienceItem {
  id: string;
  company: string;
  role: string;
  location: string;
  startDate: string;
  endDate: string;
  bullets: string[];
}

export interface ProjectItem {
  id: string;
  title: string;
  techStack: string;
  link?: string;
  bullets: string[];
}

export interface CertificationItem {
  id: string;
  name: string;
  issuer: string;
  year: string;
}

export interface AchievementItem {
  id: string;
  title: string;
  description: string;
  metric?: string;
}

export interface ResumeFormData {
  fullName: string;
  title: string;
  email: string;
  phone: string;
  location: string;
  linkedin: string;
  github: string;
  portfolio: string;
  summary: string;
  education: EducationItem[];
  technicalSkills: string[];
  softSkills: string[];
  programmingLanguages: string[];
  experience: ExperienceItem[];
  internships: ExperienceItem[];
  projects: ProjectItem[];
  certifications: CertificationItem[];
  achievements: AchievementItem[];
}

export type TemplateStatus = 'Draft' | 'Published' | 'Unpublished';
export type TemplateLayout = 'single-column' | 'two-column';

export interface ResumeTemplateSections {
  summary: boolean;
  education: boolean;
  skills: boolean;
  projects: boolean;
  experience: boolean;
  certifications: boolean;
  achievements: boolean;
}

export interface ResumeTemplate {
  id: string;
  title: string;
  category: string;
  domainId: string;
  domainName: string;
  description: string;
  downloadsCount: number;
  status: TemplateStatus | 'active' | 'inactive';
  uploadDate: string;
  format: 'DOCX' | 'PDF' | 'LATEX';
  accentColor: string;
  themeFont?: 'sans' | 'serif' | 'mono';
  tier: 'free' | 'premium';
  priceInr: number;
  intendedUser: string;
  intendedRoles?: string[];
  layout?: TemplateLayout;
  enabledSections?: ResumeTemplateSections;
  features: string[];
  templateKey: 'fresh-start' | 'tech-basic' | 'career-edge' | 'dev-pro' | 'elite-executive' | 'custom-single' | 'custom-two' | string;
  previewSnippet: {
    name: string;
    targetRole: string;
    summary: string;
    skillsSample: string[];
    experienceSample: string;
  };
  purchasesCount?: number;
  savedResumesCount?: number;
  isArchived?: boolean;
}

export interface AuditLog {
  id: string;
  adminName: string;
  action: string;
  targetType: string;
  targetName: string;
  timestamp: string;
  ipAddress: string;
  status: 'Success' | 'Warning' | 'Failed';
}

export interface AdminProfile {
  id: string;
  name: string;
  email: string;
  role: string;
  avatar: string;
  lastLogin: string;
  twoFactorEnabled: boolean;
  sessionTimeoutMinutes: number;
  department: string;
}

export interface DashboardStats {
  totalUsers: number;
  totalResumesAnalyzed: number;
  totalDomains: number;
  totalSkills: number;
  totalQuestions: number;
  totalTemplates: number;
  averageAtsScore: number;
  userGrowthPct: number;
  resumeGrowthPct: number;
  atsScoreChangePct: number;
}

export type SearchCategory = 'User' | 'Resume Analysis' | 'Job Domain' | 'Skill' | 'Interview Question' | 'Resume Template';

export interface SearchResult {
  id: string;
  title: string;
  subtitle: string;
  category: SearchCategory;
  targetTab: 'users' | 'analyses' | 'domains' | 'skills' | 'templates';
  itemData?: any;
}
