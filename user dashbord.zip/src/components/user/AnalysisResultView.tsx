import React from 'react';
import {
  FileText,
  Download,
  Share2,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  Sparkles,
  Info,
  Clock,
  Briefcase,
  Layers,
  Award,
  ChevronRight,
  ShieldCheck,
  TrendingUp,
} from 'lucide-react';
import { AnalysisReport } from '../../types';
import { CircularScore } from '../common/CircularScore';

interface AnalysisResultViewProps {
  report: AnalysisReport;
  onNavigate: (view: string, extraData?: any) => void;
  onNewAnalysis: () => void;
}

export const AnalysisResultView: React.FC<AnalysisResultViewProps> = ({
  report,
  onNavigate,
  onNewAnalysis,
}) => {
  const handlePrintReport = () => {
    window.print();
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8 animate-fadeIn pb-16">
      {/* Top action header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-violet-600 bg-violet-50 px-2.5 py-1 rounded-full border border-violet-100">
            ATS Diagnostic Report
          </span>
          <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight mt-1.5">
            {report.jobRole} Analysis
          </h2>
          <p className="text-xs text-slate-500">
            Target Domain: <strong className="text-slate-800">{report.jobDomain}</strong> • Evaluated on{' '}
            {new Date(report.createdAt).toLocaleDateString()}
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={handlePrintReport}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 rounded-xl shadow-xs transition-colors"
          >
            <Download className="w-4 h-4 text-slate-500" />
            <span>Download Report</span>
          </button>

          <button
            onClick={() => onNavigate('user-interview', { domain: report.jobDomain, role: report.jobRole, skills: report.matchedSkills })}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 rounded-xl shadow-xs transition-colors"
          >
            <Award className="w-4 h-4" />
            <span>Prepare for Interview</span>
          </button>

          <button
            onClick={onNewAnalysis}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-violet-600 hover:text-violet-800 bg-violet-50 hover:bg-violet-100 rounded-xl transition-colors"
          >
            <span>Scan Another</span>
          </button>
        </div>
      </div>

      {/* Main Score & Component Breakdown Card */}
      <div className="p-6 sm:p-8 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Circular Score Visualizer */}
          <div className="lg:col-span-4 flex flex-col items-center justify-center p-4 bg-slate-50/70 rounded-2xl border border-slate-100">
            <CircularScore score={report.atsScore} size={150} strokeWidth={12} />
            <p className="mt-3 text-xs text-slate-500 text-center max-w-[210px]">
              Estimated compatibility score based on keyword match, skills density, and format parsing.
            </p>
          </div>

          {/* 6 Sub-Component Progress Bars */}
          <div className="lg:col-span-8 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold uppercase tracking-wider text-slate-500">
                Detailed Evaluation Components
              </h3>
              <span className="text-xs text-slate-400">Total Weighted Contribution</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Keyword Match */}
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/60">
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="font-semibold text-slate-700">Keyword Match (35%)</span>
                  <span className="font-bold text-slate-900">{report.scoreBreakdown.keywordMatch}%</span>
                </div>
                <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-violet-600 rounded-full transition-all duration-700"
                    style={{ width: `${report.scoreBreakdown.keywordMatch}%` }}
                  />
                </div>
              </div>

              {/* Skills Match */}
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/60">
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="font-semibold text-slate-700">Skills Match (30%)</span>
                  <span className="font-bold text-slate-900">{report.scoreBreakdown.skillsMatch}%</span>
                </div>
                <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-indigo-600 rounded-full transition-all duration-700"
                    style={{ width: `${report.scoreBreakdown.skillsMatch}%` }}
                  />
                </div>
              </div>

              {/* Resume Structure */}
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/60">
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="font-semibold text-slate-700">Structure & Headings (15%)</span>
                  <span className="font-bold text-slate-900">{report.scoreBreakdown.resumeStructure}%</span>
                </div>
                <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-emerald-500 rounded-full transition-all duration-700"
                    style={{ width: `${report.scoreBreakdown.resumeStructure}%` }}
                  />
                </div>
              </div>

              {/* Experience Relevance */}
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/60">
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="font-semibold text-slate-700">Experience Relevance (10%)</span>
                  <span className="font-bold text-slate-900">{report.scoreBreakdown.experienceRelevance}%</span>
                </div>
                <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-blue-500 rounded-full transition-all duration-700"
                    style={{ width: `${report.scoreBreakdown.experienceRelevance}%` }}
                  />
                </div>
              </div>

              {/* Education Relevance */}
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/60">
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="font-semibold text-slate-700">Education Alignment</span>
                  <span className="font-bold text-slate-900">{report.scoreBreakdown.educationRelevance}%</span>
                </div>
                <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-teal-500 rounded-full transition-all duration-700"
                    style={{ width: `${report.scoreBreakdown.educationRelevance}%` }}
                  />
                </div>
              </div>

              {/* Readability */}
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/60">
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="font-semibold text-slate-700">Parser Readability (10%)</span>
                  <span className="font-bold text-slate-900">{report.scoreBreakdown.readability}%</span>
                </div>
                <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-sky-500 rounded-full transition-all duration-700"
                    style={{ width: `${report.scoreBreakdown.readability}%` }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Disclaimer Note */}
        <div className="mt-6 pt-4 border-t border-slate-100 flex items-start gap-2.5 text-[11px] text-slate-400">
          <Info className="w-4 h-4 shrink-0 text-slate-400 mt-0.5" />
          <span>
            <strong>Educational ATS Compatibility Note:</strong> This score is a simulated algorithmic diagnostic computed against industry job requirements and standard parser guidelines. It is not an official score from an employer's proprietary ATS and not a guarantee of selection.
          </span>
        </div>
      </div>

      {/* FEATURE 2: SKILL MATCH & MISSING SKILLS CATEGORIZED BY PRIORITY */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Present / Matched Skills */}
        <div className="p-6 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-slate-900 flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-500" />
              <span>Skills Already Present ({report.matchedSkills.length})</span>
            </h3>
            <span className="text-xs font-semibold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
              Validated
            </span>
          </div>

          <p className="text-xs text-slate-500">
            These keywords and competencies were successfully identified in your resume document:
          </p>

          <div className="flex flex-wrap gap-2">
            {report.matchedSkills.map((skill, idx) => (
              <span
                key={idx}
                className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200/60"
              >
                <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                <span>{skill}</span>
              </span>
            ))}
          </div>
        </div>

        {/* Missing Skills (High, Medium, Low Priority) */}
        <div className="p-6 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-slate-900 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-amber-500" />
              <span>Missing Skill Gaps</span>
            </h3>
            <span className="text-xs font-semibold text-amber-600 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200">
              Prioritized
            </span>
          </div>

          <p className="text-xs text-slate-500">
            Adding these domain requirements will increase your resume's searchability by recruiters:
          </p>

          <div className="space-y-3">
            {/* High Priority */}
            {report.missingSkills.highPriority.length > 0 && (
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-rose-600 flex items-center gap-1 mb-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
                  High Priority (Must Include)
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {report.missingSkills.highPriority.map((s, i) => (
                    <span
                      key={i}
                      className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-rose-50 text-rose-700 border border-rose-200"
                    >
                      + {s}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Medium Priority */}
            {report.missingSkills.mediumPriority.length > 0 && (
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-amber-600 flex items-center gap-1 mb-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                  Medium Priority (Recommended)
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {report.missingSkills.mediumPriority.map((s, i) => (
                    <span
                      key={i}
                      className="px-2.5 py-1 rounded-lg text-xs font-medium bg-amber-50 text-amber-800 border border-amber-200"
                    >
                      + {s}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Low Priority */}
            {report.missingSkills.lowPriority.length > 0 && (
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1 mb-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-slate-400" />
                  Low Priority (Bonus Competencies)
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {report.missingSkills.lowPriority.map((s, i) => (
                    <span
                      key={i}
                      className="px-2 py-0.5 rounded-md text-[11px] font-medium bg-slate-100 text-slate-600"
                    >
                      {s}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Structure Integrity Checks */}
      <div className="p-6 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-4">
        <h3 className="font-bold text-slate-900 flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-indigo-600" />
          <span>ATS Parser & Structure Checks</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {report.structureChecks.map((check, idx) => (
            <div
              key={idx}
              className={`p-3.5 rounded-xl border ${
                check.passed
                  ? 'bg-emerald-50/40 border-emerald-200'
                  : 'bg-rose-50/40 border-rose-200'
              }`}
            >
              <div className="flex items-center gap-2">
                {check.passed ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                ) : (
                  <AlertTriangle className="w-4 h-4 text-rose-500 shrink-0" />
                )}
                <span className="text-xs font-bold text-slate-900">{check.label}</span>
              </div>
              <p className="text-[11px] text-slate-600 mt-1 pl-6">{check.note}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Actionable Improvement Suggestions */}
      <div className="p-6 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-4">
        <h3 className="font-bold text-slate-900 flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-violet-600" />
          <span>Strategic Improvement Suggestions</span>
        </h3>

        <div className="space-y-2.5">
          {report.suggestions.map((sug, i) => (
            <div key={i} className="flex items-start gap-3 p-3.5 rounded-xl bg-violet-50/40 border border-violet-100 text-xs">
              <span className="w-5 h-5 rounded-full bg-violet-600 text-white flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
                {i + 1}
              </span>
              <p className="text-slate-800 leading-relaxed font-medium">{sug}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
