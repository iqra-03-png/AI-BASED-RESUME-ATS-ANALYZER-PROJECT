import React, { useState, useEffect, useRef } from 'react';
import {
  Sparkles,
  Send,
  Trash2,
  Bot,
  User as UserIcon,
  Lightbulb,
  FileText,
  Award,
  Layers,
  ArrowRight,
} from 'lucide-react';
import { api } from '../../services/api';
import { ChatMessage, AnalysisReport } from '../../types';

interface AIAssistantPageViewProps {
  latestReport?: AnalysisReport | null;
  onNavigate: (view: string, extraData?: any) => void;
}

export const AIAssistantPageView: React.FC<AIAssistantPageViewProps> = ({
  latestReport,
  onNavigate,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    async function loadChat() {
      try {
        const res = await api.getChatHistory();
        if (res.messages && res.messages.length > 0) {
          setMessages(res.messages);
        } else {
          setMessages([
            {
              id: 'init-main',
              userId: 'sys',
              role: 'assistant',
              content:
                "👋 Hello! I am your **ResuNova AI Career Assistant**.\n\nI specialize in Applicant Tracking System (ATS) optimization, resume writing, missing skill strategies, and technical interview prep.\n\nChoose a quick prompt below or type any question about your resume, career path, or target job description!",
              timestamp: new Date().toISOString(),
            },
          ]);
        }
      } catch (err) {
        console.error('Failed to load chat history:', err);
      }
    }
    loadChat();
  }, []);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async (customPrompt?: string) => {
    const textToSend = customPrompt || input;
    if (!textToSend.trim() || loading) return;

    const userMsg: ChatMessage = {
      id: 'local-' + Date.now(),
      userId: 'current',
      role: 'user',
      content: textToSend.trim(),
      timestamp: new Date().toISOString(),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!customPrompt) setInput('');
    setLoading(true);

    try {
      const context = latestReport
        ? {
            role: latestReport.jobRole,
            domain: latestReport.jobDomain,
            atsScore: latestReport.atsScore,
            missingSkills: latestReport.missingSkills?.highPriority || [],
          }
        : undefined;

      const res = await api.sendChatMessage(textToSend.trim(), context);

      const aiMsg: ChatMessage = {
        id: res.messageId || 'ai-' + Date.now(),
        userId: 'assistant',
        role: 'assistant',
        content: res.reply,
        timestamp: new Date().toISOString(),
      };

      setMessages((prev) => [...prev, aiMsg]);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          id: 'err-' + Date.now(),
          userId: 'assistant',
          role: 'assistant',
          content: 'Unable to connect to AI assistant. Please try again in a moment.',
          timestamp: new Date().toISOString(),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleClear = async () => {
    try {
      await api.clearChat();
      setMessages([
        {
          id: 'init-cleared',
          userId: 'sys',
          role: 'assistant',
          content: 'Conversation history cleared. What would you like to work on next?',
          timestamp: new Date().toISOString(),
        },
      ]);
    } catch (err) {
      console.error('Failed to clear chat:', err);
    }
  };

  const starterPrompts = [
    {
      title: 'ATS Score Explanation',
      desc: 'Understand why resumes get rejected and how to reach 90%+ match score.',
      prompt: 'Can you explain how ATS parsers evaluate keyword density and how I can reach a 90%+ match score?',
    },
    {
      title: 'Improve Project Descriptions',
      desc: 'Rewrite bullet points using action verbs and quantified impact metrics.',
      prompt: 'Help me rewrite a software engineering project bullet point using the STAR format and metric quantification.',
    },
    {
      title: 'Missing Skill Strategy',
      desc: 'Get a recommended study roadmap for high-priority missing technical tools.',
      prompt: 'What are the best frameworks and architectures to learn if I am missing cloud deployment competencies?',
    },
    {
      title: 'Interview Practice Questions',
      desc: 'Generate tricky behavioral and system design interview questions.',
      prompt: 'Give me 2 challenging technical interview questions with sample structured answers for a Full-Stack Developer role.',
    },
  ];

  return (
    <div className="max-w-5xl mx-auto space-y-6 animate-fadeIn pb-16">
      {/* Top Banner */}
      <div className="p-6 sm:p-8 rounded-2xl bg-gradient-to-r from-[#0a0f1d] via-[#131b31] to-[#1e1b4b] text-white shadow-xl border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-violet-500/20 text-violet-300 border border-violet-500/30 text-xs font-semibold mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI Career & Resume Intelligence</span>
          </div>
          <h2 className="text-2xl font-bold tracking-tight">
            ResuNova AI Assistant
          </h2>
          <p className="text-xs text-slate-300 mt-1 max-w-xl">
            Real-time guidance on ATS compatibility, resume tailoring, high-impact bullet rewriting, and interview readiness.
          </p>
        </div>

        <button
          onClick={handleClear}
          className="self-start md:self-auto inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold bg-white/10 hover:bg-white/20 text-slate-200 border border-white/20 transition-colors"
        >
          <Trash2 className="w-3.5 h-3.5" />
          <span>Clear History</span>
        </button>
      </div>

      {/* Starter Prompts Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {starterPrompts.map((item, idx) => (
          <button
            key={idx}
            onClick={() => handleSend(item.prompt)}
            className="p-4 rounded-2xl bg-white border border-slate-200/80 hover:border-violet-300 hover:shadow-md transition-all text-left flex flex-col justify-between group"
          >
            <div>
              <div className="p-2 rounded-lg bg-violet-50 text-violet-600 w-fit group-hover:bg-violet-600 group-hover:text-white transition-colors mb-2">
                <Lightbulb className="w-4 h-4" />
              </div>
              <h4 className="font-bold text-xs text-slate-900 group-hover:text-violet-600 transition-colors">
                {item.title}
              </h4>
              <p className="text-[11px] text-slate-500 mt-1 line-clamp-2">
                {item.desc}
              </p>
            </div>
            <span className="text-[10px] font-semibold text-violet-600 mt-3 flex items-center gap-1">
              <span>Ask Assistant</span>
              <ArrowRight className="w-3 h-3" />
            </span>
          </button>
        ))}
      </div>

      {/* Main Conversation Window */}
      <div className="rounded-2xl bg-white border border-slate-200/80 shadow-xs flex flex-col h-[520px] overflow-hidden">
        {/* Messages */}
        <div className="flex-1 p-6 overflow-y-auto space-y-4 bg-slate-50/50 text-xs">
          {messages.map((m) => {
            const isAssistant = m.role === 'assistant';
            return (
              <div
                key={m.id}
                className={`flex items-start gap-3 ${isAssistant ? '' : 'flex-row-reverse'}`}
              >
                <div
                  className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs shrink-0 ${
                    isAssistant
                      ? 'bg-violet-100 text-violet-700'
                      : 'bg-slate-900 text-white'
                  }`}
                >
                  {isAssistant ? <Sparkles className="w-4 h-4" /> : <UserIcon className="w-4 h-4" />}
                </div>

                <div
                  className={`p-4 rounded-2xl max-w-[80%] leading-relaxed ${
                    isAssistant
                      ? 'bg-white text-slate-800 border border-slate-200/80 shadow-xs'
                      : 'bg-violet-600 text-white rounded-br-xs'
                  }`}
                >
                  <p className="whitespace-pre-line">{m.content}</p>
                  <span
                    className={`block text-[10px] mt-2 ${
                      isAssistant ? 'text-slate-400' : 'text-violet-200 text-right'
                    }`}
                  >
                    {new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              </div>
            );
          })}

          {loading && (
            <div className="flex items-center gap-2 text-xs text-violet-600 p-2 font-medium">
              <Sparkles className="w-4 h-4 animate-spin text-violet-600" />
              <span>ResuNova AI Assistant is analyzing your query...</span>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Form */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="p-4 bg-white border-t border-slate-200 flex items-center gap-3"
        >
          <input
            type="text"
            placeholder="Type your question or paste resume bullet points for improvement..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            className="flex-1 px-4 py-3 text-xs border border-slate-200 rounded-xl focus:border-violet-500 focus:outline-hidden"
          />
          <button
            type="submit"
            disabled={!input.trim() || loading}
            className={`px-5 py-3 rounded-xl font-bold text-xs text-white transition-all flex items-center gap-2 ${
              input.trim() && !loading
                ? 'bg-violet-600 hover:bg-violet-700 shadow-md shadow-violet-600/20'
                : 'bg-slate-200 text-slate-400 cursor-not-allowed'
            }`}
          >
            <span>Send</span>
            <Send className="w-3.5 h-3.5" />
          </button>
        </form>
      </div>
    </div>
  );
};
