import React, { useState, useEffect, useRef } from 'react';
import {
  UploadCloud,
  FileText,
  CheckCircle,
  AlertCircle,
  RefreshCw,
  Trash2,
  Edit3,
  Briefcase,
  ChevronRight,
  ArrowRight,
  Sparkles,
  Info,
  Code,
  GraduationCap,
  Award,
  Layers,
  MapPin,
  Mail,
  Phone,
  FileCheck,
} from 'lucide-react';
import { api } from '../../services/api';
import { JobDomain, ResumeFile, ExtractedResumeData, AnalysisReport } from '../../types';

interface ResumeUploadFlowProps {
  onAnalysisComplete: (report: AnalysisReport) => void;
}

type Step = 'upload' | 'extracting' | 'review' | 'analyzing';

export const ResumeUploadFlow: React.FC<ResumeUploadFlowProps> = ({ onAnalysisComplete }) => {
  const [step, setStep] = useState<Step>('upload');
  const [file, setFile] = useState<File | null>(null);
  const [dragActive, setDragActive] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [statusMessage, setStatusMessage] = useState<string>('Uploading Resume...');

  // Data returned from upload
  const [resumeRecord, setResumeRecord] = useState<ResumeFile | null>(null);
  const [extractedData, setExtractedData] = useState<ExtractedResumeData | null>(null);

  // Domains & roles
  const [domains, setDomains] = useState<JobDomain[]>([]);
  const [selectedDomain, setSelectedDomain] = useState<string>('');
  const [selectedRole, setSelectedRole] = useState<string>('');
  const [jobDescription, setJobDescription] = useState<string>('');

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Load available job domains
  useEffect(() => {
    async function loadDomains() {
      try {
        const res = await api.getAdminDomains();
        setDomains(res.domains || []);
        if (res.domains && res.domains.length > 0) {
          setSelectedDomain(res.domains[0].name);
          if (res.domains[0].roles.length > 0) {
            setSelectedRole(res.domains[0].roles[0]);
          }
        }
      } catch (err) {
        console.error('Failed to load domains:', err);
      }
    }
    loadDomains();
  }, []);

  // Update selected role when domain changes
  const handleDomainChange = (domainName: string) => {
    setSelectedDomain(domainName);
    const found = domains.find((d) => d.name === domainName);
    if (found && found.roles.length > 0) {
      setSelectedRole(found.roles[0]);
    } else {
      setSelectedRole('');
    }
  };

  // Drag and drop handlers
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const validateAndSetFile = (selectedFile: File) => {
    setErrorMsg(null);
    const validExts = ['.pdf', '.docx', '.txt'];
    const ext = selectedFile.name.substring(selectedFile.name.lastIndexOf('.')).toLowerCase();

    if (!validExts.includes(ext)) {
      setErrorMsg('Invalid file format. Please upload a PDF (.pdf) or Word (.docx) resume.');
      return;
    }

    if (selectedFile.size > 10 * 1024 * 1024) {
      setErrorMsg('File exceeds 10MB limit. Please upload a smaller resume.');
      return;
    }

    setFile(selectedFile);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      validateAndSetFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      validateAndSetFile(e.target.files[0]);
    }
  };

  // Upload and Extract flow
  const handleStartExtraction = async () => {
    if (!file) return;
    setStep('extracting');
    setErrorMsg(null);

    try {
      // Step status updates
      setStatusMessage('Uploading Resume...');
      await new Promise((r) => setTimeout(r, 600));

      setStatusMessage('Reading Resume Structure...');
      await new Promise((r) => setTimeout(r, 600));

      setStatusMessage('Extracting Information & Detecting Skills...');
      const res = await api.uploadResume(file);

      setResumeRecord(res.resume);
      setExtractedData(res.extractedData);

      // Pre-select domain if detected in resume
      if (res.extractedData.relevantJobDomains?.length > 0) {
        const detectedDom = res.extractedData.relevantJobDomains[0];
        const match = domains.find((d) => d.name.toLowerCase().includes(detectedDom.toLowerCase()));
        if (match) {
          setSelectedDomain(match.name);
          if (match.roles.length > 0) setSelectedRole(match.roles[0]);
        }
      }

      setStatusMessage('Analysis Completed.');
      await new Promise((r) => setTimeout(r, 400));
      setStep('review');
    } catch (err: any) {
      console.error('Extraction failure:', err);
      setErrorMsg(err.message || 'Failed to extract resume details.');
      setStep('upload');
    }
  };

  // Run final ATS analysis
  const handleRunAnalysis = async () => {
    if (!resumeRecord || !selectedDomain || !selectedRole) {
      setErrorMsg('Please select a target job domain and job role.');
      return;
    }

    setStep('analyzing');
    setErrorMsg(null);
    setStatusMessage('Analyzing ATS Match Score & Keyword Density...');

    try {
      const res = await api.analyzeResume({
        resumeId: resumeRecord.id,
        domain: selectedDomain,
        role: selectedRole,
        jobDescription: jobDescription.trim() || undefined,
        extractedDataOverride: extractedData || undefined,
      });

      onAnalysisComplete(res.report);
    } catch (err: any) {
      console.error('Analysis error:', err);
      setErrorMsg(err.message || 'Failed to generate ATS analysis.');
      setStep('review');
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8 animate-fadeIn pb-12">
      {/* Workflow Step Tracker */}
      <div className="flex items-center justify-between max-w-2xl mx-auto px-4 py-3 bg-white rounded-2xl border border-slate-200/80 shadow-xs">
        <div className="flex items-center gap-2">
          <div
            className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ${
              step === 'upload'
                ? 'bg-violet-600 text-white'
                : 'bg-emerald-100 text-emerald-700'
            }`}
          >
            {step === 'upload' ? '1' : <CheckCircle className="w-4 h-4" />}
          </div>
          <span className="text-xs font-semibold text-slate-800">1. Upload File</span>
        </div>

        <ChevronRight className="w-4 h-4 text-slate-300" />

        <div className="flex items-center gap-2">
          <div
            className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ${
              step === 'extracting'
                ? 'bg-violet-600 text-white animate-pulse'
                : step === 'review' || step === 'analyzing'
                ? 'bg-emerald-100 text-emerald-700'
                : 'bg-slate-100 text-slate-400'
            }`}
          >
            {step === 'review' || step === 'analyzing' ? <CheckCircle className="w-4 h-4" /> : '2'}
          </div>
          <span className="text-xs font-semibold text-slate-800">2. Review Detection</span>
        </div>

        <ChevronRight className="w-4 h-4 text-slate-300" />

        <div className="flex items-center gap-2">
          <div
            className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ${
              step === 'analyzing'
                ? 'bg-violet-600 text-white animate-pulse'
                : 'bg-slate-100 text-slate-400'
            }`}
          >
            3
          </div>
          <span className="text-xs font-semibold text-slate-800">3. ATS Diagnostics</span>
        </div>
      </div>

      {errorMsg && (
        <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-medium flex items-center gap-2.5">
          <AlertCircle className="w-4 h-4 shrink-0 text-rose-500" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* STEP 1: UPLOAD & VALIDATION */}
      {step === 'upload' && (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-6 sm:p-8 space-y-6">
          <div className="text-center max-w-lg mx-auto space-y-2">
            <h2 className="text-2xl font-bold text-slate-900 tracking-tight">
              Upload Your Resume
            </h2>
            <p className="text-xs sm:text-sm text-slate-500">
              Drag and drop your resume file. Our system securely parses PDF and DOCX documents and detects 15 critical hiring data points.
            </p>
          </div>

          {/* Drag & Drop Zone */}
          <div
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`relative flex flex-col items-center justify-center p-8 sm:p-12 border-2 border-dashed rounded-2xl cursor-pointer transition-all ${
              dragActive
                ? 'border-violet-500 bg-violet-50/60 scale-[1.01]'
                : file
                ? 'border-emerald-400 bg-emerald-50/20'
                : 'border-slate-300 hover:border-violet-400 hover:bg-slate-50/60'
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept=".pdf,.docx,.txt"
              onChange={handleFileInput}
              className="hidden"
            />

            {file ? (
              <div className="flex flex-col items-center text-center space-y-3">
                <div className="w-16 h-16 rounded-2xl bg-emerald-100 text-emerald-600 flex items-center justify-center shadow-xs">
                  <FileCheck className="w-8 h-8" />
                </div>
                <div>
                  <p className="text-sm font-bold text-slate-900">{file.name}</p>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {(file.size / (1024 * 1024)).toFixed(2)} MB • Ready for parsing
                  </p>
                </div>
                <div className="flex items-center gap-2 pt-2">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      fileInputRef.current?.click();
                    }}
                    className="text-xs font-semibold text-violet-600 hover:text-violet-700 bg-violet-50 px-3 py-1.5 rounded-lg"
                  >
                    Replace File
                  </button>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setFile(null);
                    }}
                    className="text-xs font-semibold text-rose-600 hover:text-rose-700 bg-rose-50 px-3 py-1.5 rounded-lg flex items-center gap-1"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Remove</span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center text-center space-y-3">
                <div className="w-16 h-16 rounded-2xl bg-violet-50 text-violet-600 flex items-center justify-center">
                  <UploadCloud className="w-8 h-8" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-slate-800">
                    <span className="text-violet-600 font-bold hover:underline">Click to browse</span> or drag and drop your file here
                  </p>
                  <p className="text-xs text-slate-400 mt-1">
                    Supports text-based PDF and DOCX documents (Up to 10MB)
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Action button */}
          <div className="flex justify-end pt-2">
            <button
              disabled={!file}
              onClick={handleStartExtraction}
              className={`inline-flex items-center gap-2 px-6 py-3 rounded-xl font-semibold text-sm transition-all ${
                file
                  ? 'bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white shadow-md shadow-violet-600/30'
                  : 'bg-slate-100 text-slate-400 cursor-not-allowed'
              }`}
            >
              <span>Extract & Detect Information</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 2: EXTRACTING PROGRESS */}
      {step === 'extracting' && (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-12 text-center space-y-6">
          <div className="relative w-20 h-20 mx-auto">
            <div className="absolute inset-0 rounded-full border-4 border-violet-100 animate-ping opacity-30" />
            <div className="w-20 h-20 rounded-full border-4 border-violet-600 border-t-transparent animate-spin flex items-center justify-center">
              <Sparkles className="w-6 h-6 text-violet-600" />
            </div>
          </div>

          <div className="space-y-2">
            <h3 className="text-xl font-bold text-slate-900 tracking-tight">
              Processing Document
            </h3>
            <p className="text-sm font-medium text-violet-600 animate-pulse">
              {statusMessage}
            </p>
            <p className="text-xs text-slate-400 max-w-sm mx-auto">
              Scanning candidate contact credentials, technical competencies, education degrees, and project history...
            </p>
          </div>
        </div>
      )}

      {/* STEP 3: REVIEW DETECTED INFORMATION & SELECT DOMAIN */}
      {step === 'review' && extractedData && (
        <div className="space-y-6">
          {/* Detected Summary Banner */}
          <div className="p-6 rounded-2xl bg-white border border-slate-200/80 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="p-1 rounded bg-emerald-100 text-emerald-700">
                  <CheckCircle className="w-4 h-4" />
                </span>
                <h3 className="text-lg font-bold text-slate-900">
                  Resume Information Extracted
                </h3>
              </div>
              <p className="text-xs text-slate-500 mt-1">
                Please review and correct the detected details if necessary before running the ATS analysis.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  setStep('upload');
                  setFile(null);
                }}
                className="text-xs font-semibold text-slate-600 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 px-3.5 py-2 rounded-xl transition-colors"
              >
                Upload Different Resume
              </button>
            </div>
          </div>

          {/* Missing Sections Notice if any */}
          {extractedData.missingSections && extractedData.missingSections.length > 0 && (
            <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 flex items-start gap-3">
              <Info className="w-4 h-4 text-amber-600 mt-0.5 shrink-0" />
              <div>
                <p className="text-xs font-bold text-amber-900">
                  Potentially Missing Resume Sections Detected:
                </p>
                <p className="text-xs text-amber-800 mt-0.5">
                  The parser could not locate standard sections for:{' '}
                  <span className="font-semibold">{extractedData.missingSections.join(', ')}</span>.
                  Adding these to your resume draft will boost your ATS compatibility score.
                </p>
              </div>
            </div>
          )}

          {/* 15 Extracted Information Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Card 1: Contact & Personal Info */}
            <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-violet-600" />
                  <span>Personal & Contact Credentials</span>
                </h4>
              </div>

              <div className="space-y-3 text-xs">
                <div>
                  <label className="text-slate-400 font-medium">Full Name</label>
                  <input
                    type="text"
                    value={extractedData.fullName}
                    onChange={(e) => setExtractedData({ ...extractedData, fullName: e.target.value })}
                    className="w-full mt-1 px-3 py-2 border border-slate-200 rounded-lg text-slate-900 font-semibold focus:border-violet-500 focus:outline-hidden"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-slate-400 font-medium">Email Address</label>
                    <input
                      type="email"
                      value={extractedData.email}
                      onChange={(e) => setExtractedData({ ...extractedData, email: e.target.value })}
                      className="w-full mt-1 px-3 py-2 border border-slate-200 rounded-lg text-slate-800 focus:border-violet-500 focus:outline-hidden"
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 font-medium">Phone Number</label>
                    <input
                      type="text"
                      value={extractedData.phone}
                      onChange={(e) => setExtractedData({ ...extractedData, phone: e.target.value })}
                      className="w-full mt-1 px-3 py-2 border border-slate-200 rounded-lg text-slate-800 focus:border-violet-500 focus:outline-hidden"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-slate-400 font-medium">Location</label>
                  <input
                    type="text"
                    value={extractedData.location}
                    onChange={(e) => setExtractedData({ ...extractedData, location: e.target.value })}
                    className="w-full mt-1 px-3 py-2 border border-slate-200 rounded-lg text-slate-800 focus:border-violet-500 focus:outline-hidden"
                  />
                </div>
              </div>
            </div>

            {/* Card 2: Education & College */}
            <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                  <GraduationCap className="w-3.5 h-3.5 text-violet-600" />
                  <span>Education, Degrees & Colleges</span>
                </h4>
              </div>

              <div className="space-y-3 text-xs">
                {extractedData.education && extractedData.education.length > 0 ? (
                  extractedData.education.map((edu, idx) => (
                    <div key={idx} className="p-2.5 rounded-xl bg-slate-50 border border-slate-200/60">
                      <p className="font-bold text-slate-900">{edu.degree}</p>
                      <p className="text-slate-600">{edu.institution}</p>
                      {(edu.year || edu.grade) && (
                        <p className="text-[11px] text-slate-400 mt-0.5">
                          {edu.year} {edu.grade ? `• ${edu.grade}` : ''}
                        </p>
                      )}
                    </div>
                  ))
                ) : (
                  <p className="text-slate-400 italic">No formal education detected</p>
                )}

                {extractedData.colleges?.length > 0 && (
                  <div>
                    <label className="text-slate-400 font-medium">Detected Institutions</label>
                    <div className="flex flex-wrap gap-1.5 mt-1">
                      {extractedData.colleges.map((c, i) => (
                        <span key={i} className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 text-[11px]">
                          {c}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Card 3: Technical Skills */}
            <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                  <Code className="w-3.5 h-3.5 text-violet-600" />
                  <span>Technical Skills ({extractedData.technicalSkills.length})</span>
                </h4>
              </div>

              <div className="flex flex-wrap gap-1.5">
                {extractedData.technicalSkills.length > 0 ? (
                  extractedData.technicalSkills.map((skill, idx) => (
                    <span
                      key={idx}
                      className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-violet-50 text-violet-700 border border-violet-100"
                    >
                      {skill}
                    </span>
                  ))
                ) : (
                  <span className="text-slate-400 text-xs italic">No technical skills detected</span>
                )}
              </div>
            </div>

            {/* Card 4: Soft Skills & Languages */}
            <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                  <Award className="w-3.5 h-3.5 text-violet-600" />
                  <span>Soft Skills & Languages</span>
                </h4>
              </div>

              <div className="space-y-3 text-xs">
                <div>
                  <label className="text-slate-400 font-medium">Soft Competencies</label>
                  <div className="flex flex-wrap gap-1.5 mt-1">
                    {extractedData.softSkills.map((s, i) => (
                      <span key={i} className="px-2.5 py-1 rounded-lg text-xs font-medium bg-indigo-50 text-indigo-700 border border-indigo-100">
                        {s}
                      </span>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="text-slate-400 font-medium">Languages</label>
                  <div className="flex flex-wrap gap-1.5 mt-1">
                    {extractedData.languages?.map((lang, i) => (
                      <span key={i} className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 text-xs font-medium">
                        {lang}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Card 5: Work Experience & Internships */}
            <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-4 md:col-span-2">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                  <Briefcase className="w-3.5 h-3.5 text-violet-600" />
                  <span>Experience & Projects Timeline</span>
                </h4>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                <div>
                  <p className="font-semibold text-slate-700 mb-2">Work Experience & Internships</p>
                  {extractedData.workExperience.length > 0 || extractedData.internships.length > 0 ? (
                    <div className="space-y-2">
                      {[...extractedData.workExperience, ...extractedData.internships].map((item, i) => (
                        <div key={i} className="p-3 rounded-xl bg-slate-50 border border-slate-200/60">
                          <p className="font-bold text-slate-900">{item.role}</p>
                          <p className="text-slate-600">{item.company} {item.duration ? `• ${item.duration}` : ''}</p>
                          {item.description && <p className="text-slate-500 mt-1 line-clamp-2">{item.description}</p>}
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-slate-400 italic">No formal roles detected in resume</p>
                  )}
                </div>

                <div>
                  <p className="font-semibold text-slate-700 mb-2">Projects & Certifications</p>
                  {extractedData.projects.length > 0 ? (
                    <div className="space-y-2">
                      {extractedData.projects.map((proj, i) => (
                        <div key={i} className="p-3 rounded-xl bg-slate-50 border border-slate-200/60">
                          <p className="font-bold text-slate-900">{proj.title}</p>
                          <p className="text-slate-500 mt-1 line-clamp-2">{proj.description}</p>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-slate-400 italic">No projects explicitly detected</p>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Target Job Domain & Description Section */}
          <div className="p-6 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-5">
            <div>
              <h3 className="text-lg font-bold text-slate-900">
                Target Role & Job Domain Selection
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                ResuNova compares your detected skills against the target criteria configured by administrators.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-semibold text-slate-700">Target Job Domain *</label>
                <select
                  value={selectedDomain}
                  onChange={(e) => handleDomainChange(e.target.value)}
                  className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-xs font-semibold text-slate-900 focus:border-violet-500 focus:outline-hidden"
                >
                  {domains.map((d) => (
                    <option key={d.id} value={d.name}>
                      {d.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700">Specific Job Role *</label>
                <select
                  value={selectedRole}
                  onChange={(e) => setSelectedRole(e.target.value)}
                  className="w-full mt-1.5 px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-xs font-semibold text-slate-900 focus:border-violet-500 focus:outline-hidden"
                >
                  {domains
                    .find((d) => d.name === selectedDomain)
                    ?.roles.map((r, i) => (
                      <option key={i} value={r}>
                        {r}
                      </option>
                    ))}
                </select>
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700">
                Job Description (Optional but Recommended)
              </label>
              <textarea
                rows={4}
                value={jobDescription}
                onChange={(e) => setJobDescription(e.target.value)}
                placeholder="Paste the employer's job description here to calculate precise keyword matching and recruiter keyword coverage..."
                className="w-full mt-1.5 p-3 rounded-xl border border-slate-300 text-xs text-slate-800 placeholder:text-slate-400 focus:border-violet-500 focus:outline-hidden"
              />
            </div>

            <div className="flex items-center justify-between pt-2">
              <span className="text-xs text-slate-500">
                Ready to evaluate: <strong className="text-slate-900">{selectedRole}</strong> in <strong className="text-slate-900">{selectedDomain}</strong>
              </span>

              <button
                onClick={handleRunAnalysis}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-sm bg-gradient-to-r from-violet-600 via-indigo-600 to-blue-600 hover:from-violet-500 hover:to-blue-500 text-white shadow-lg shadow-violet-600/30 transition-all hover:scale-[1.02]"
              >
                <Sparkles className="w-4 h-4" />
                <span>Analyze Resume Now</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* STEP 4: ANALYZING LOADING STATE */}
      {step === 'analyzing' && (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-16 text-center space-y-6">
          <div className="relative w-24 h-24 mx-auto">
            <div className="absolute inset-0 rounded-full border-4 border-violet-100 animate-ping opacity-40" />
            <div className="w-24 h-24 rounded-full border-4 border-violet-600 border-t-transparent animate-spin flex items-center justify-center">
              <Sparkles className="w-8 h-8 text-violet-600" />
            </div>
          </div>

          <div className="space-y-2">
            <h3 className="text-2xl font-bold text-slate-900 tracking-tight">
              Generating ATS Diagnostic Report
            </h3>
            <p className="text-sm font-semibold text-violet-600 animate-pulse">
              Calculating weighted compatibility score for {selectedRole}...
            </p>
            <p className="text-xs text-slate-400 max-w-md mx-auto">
              Analyzing technical skill matches, identifying high-priority keyword gaps, verifying layout readability, and constructing custom interview questions.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
