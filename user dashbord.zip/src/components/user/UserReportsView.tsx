import React, { useEffect, useState } from 'react';
import {
  TrendingUp,
  BarChart2,
  Download,
  CheckCircle2,
  AlertTriangle,
  Award,
  Layers,
  Clock,
  Sparkles,
} from 'lucide-react';
import { api } from '../../services/api';
import { AnalysisReport } from '../../types';
import { CircularScore } from '../common/CircularScore';

export const UserReportsView: React.FC = () => {
  const [reports, setReports] = useState<AnalysisReport[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    async function loadReports() {
      try {
        const res = await api.getHistory();
        setReports(res.reports || []);
      } catch (err) {
        console.error('Failed to load reports:', err);
      } finally {
        setLoading(false);
      }
    }
    loadReports();
  }, []);

  const totalScans = reports.length;
  const avgScore = totalScans > 0
    ? Math.round(reports.reduce((acc, r) => acc + r.atsScore, 0) / totalScans)
    : 0;

  const highestScore = totalScans > 0
    ? Math.max(...reports.map((r) => r.atsScore))
    : 0;

  // Aggregate missing skills
  const missingSkillsMap: Record<string, number> = {};
  reports.forEach((r) => {
    r.missingSkills?.highPriority?.forEach((s) => {
      missingSkillsMap[s] = (missingSkillsMap[s] || 0) + 1;
    });
  });

  const topMissingSkills = Object.entries(missingSkillsMap)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 8);

  return (
    <div className="space-y-8 animate-fadeIn pb-16">
      {/* Header Banner */}
      <div className="p-6 sm:p-8 rounded-2xl bg-gradient-to-r from-slate-900 via-indigo-950 to-violet-950 text-white shadow-xl border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-violet-500/20 text-violet-300 border border-violet-500/30 text-xs font-semibold mb-2">
            <TrendingUp className="w-3.5 h-3.5" />
            <span>Applicant Competency Analytics</span>
          </span>
          <h2 className="text-2xl font-bold tracking-tight">
            Your ATS Progress & Competency Reports
          </h2>
          <p className="text-xs text-slate-300 mt-1">
            Aggregated diagnostics across {totalScans} resume analysis scans.
          </p>
        </div>

        <button
          onClick={() => window.print()}
          className="self-start sm:self-auto inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold border border-white/20 transition-colors"
        >
          <Download className="w-4 h-4" />
          <span>Print Summary Report</span>
        </button>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
            Total Scans Completed
          </span>
          <p className="text-3xl font-extrabold text-slate-900 mt-2">{totalScans}</p>
          <p className="text-xs text-slate-400 mt-1">Saved in persistent database</p>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
            Average ATS Compatibility
          </span>
          <p className="text-3xl font-extrabold text-violet-600 mt-2">{avgScore}%</p>
          <p className="text-xs text-slate-400 mt-1">Across all target roles</p>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
            Highest Achieved ATS Score
          </span>
          <p className="text-3xl font-extrabold text-emerald-600 mt-2">{highestScore}%</p>
          <p className="text-xs text-slate-400 mt-1">Peak keyword compatibility</p>
        </div>
      </div>

      {/* Historical Score Progression */}
      <div className="p-6 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-4">
        <h3 className="font-bold text-slate-900 flex items-center gap-2">
          <BarChart2 className="w-5 h-5 text-violet-600" />
          <span>Historical ATS Score Progression</span>
        </h3>

        {reports.length > 0 ? (
          <div className="space-y-3 pt-2">
            {reports.map((rep, idx) => (
              <div
                key={rep.id}
                className="p-4 rounded-xl bg-slate-50 border border-slate-200/60 flex items-center justify-between"
              >
                <div>
                  <p className="font-bold text-slate-900 text-xs">
                    {rep.jobRole} ({rep.jobDomain})
                  </p>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    File: <span className="font-mono">{rep.resumeFileName}</span> • Scanned{' '}
                    {new Date(rep.createdAt).toLocaleDateString()}
                  </p>
                </div>

                <div className="flex items-center gap-4">
                  <div className="w-32 hidden sm:block h-2 bg-slate-200 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${
                        rep.atsScore >= 80 ? 'bg-emerald-500' : rep.atsScore >= 70 ? 'bg-violet-600' : 'bg-amber-500'
                      }`}
                      style={{ width: `${rep.atsScore}%` }}
                    />
                  </div>
                  <span
                    className={`font-extrabold text-sm px-2.5 py-1 rounded-full ${
                      rep.atsScore >= 80
                        ? 'bg-emerald-50 text-emerald-700'
                        : rep.atsScore >= 70
                        ? 'bg-violet-50 text-violet-700'
                        : 'bg-amber-50 text-amber-700'
                    }`}
                  >
                    {rep.atsScore}%
                  </span>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="py-12 text-center text-slate-400">
            <Clock className="w-8 h-8 mx-auto opacity-30 mb-2" />
            <p className="text-xs font-semibold">No historical scan records available yet</p>
          </div>
        )}
      </div>

      {/* Aggregate Missing Skills Across Scans */}
      <div className="p-6 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-4">
        <h3 className="font-bold text-slate-900 flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-amber-500" />
          <span>Most Frequent Missing Skills Across Your Target Roles</span>
        </h3>
        <p className="text-xs text-slate-500">
          Focusing your continuous learning and project portfolio on these competencies will deliver the fastest ATS score gains:
        </p>

        {topMissingSkills.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2">
            {topMissingSkills.map(([skill, count], i) => (
              <div
                key={i}
                className="p-3.5 rounded-xl bg-amber-50/40 border border-amber-200 flex items-center justify-between"
              >
                <span className="font-bold text-slate-900 text-xs">{skill}</span>
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-amber-100 text-amber-800">
                  Missing in {count} {count === 1 ? 'scan' : 'scans'}
                </span>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-4 rounded-xl bg-slate-50 text-center text-xs text-slate-400">
            Run resume scans to identify recurring skill bottlenecks.
          </div>
        )}
      </div>
    </div>
  );
};
