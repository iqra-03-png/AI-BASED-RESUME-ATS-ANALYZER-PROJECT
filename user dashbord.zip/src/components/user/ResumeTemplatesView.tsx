import React, { useState, useEffect } from 'react';
import {
  Layers,
  Sparkles,
  Lock,
  Unlock,
  Check,
  Search,
  Eye,
  Edit3,
  ExternalLink,
  ShieldCheck,
  Zap,
} from 'lucide-react';
import { api } from '../../services/api';
import { ResumeTemplate } from '../../types';
import { ResumeBuilderModal } from '../templates/ResumeBuilderModal';
import { sampleResumeData, ResumeTemplateRenderer } from '../templates/ResumeTemplateRenderer';

export const ResumeTemplatesView: React.FC = () => {
  const [templates, setTemplates] = useState<ResumeTemplate[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [filterTier, setFilterTier] = useState<'all' | 'free' | 'premium'>('all');

  // Active builder template
  const [activeBuilderTemplate, setActiveBuilderTemplate] = useState<ResumeTemplate | null>(null);

  // Quick preview modal
  const [previewTemplate, setPreviewTemplate] = useState<ResumeTemplate | null>(null);

  // Unlocking status
  const [unlockingId, setUnlockingId] = useState<string | null>(null);

  const loadTemplates = async () => {
    setLoading(true);
    try {
      const res = await api.getTemplates();
      setTemplates(res.templates || []);
    } catch (err) {
      console.error('Failed to load templates:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadTemplates();
  }, []);

  const handleUnlock = async (tmpl: ResumeTemplate) => {
    setUnlockingId(tmpl.id);
    try {
      await api.purchaseTemplate(tmpl.id);
      await loadTemplates();
    } catch (err) {
      console.error('Failed to unlock template:', err);
    } finally {
      setUnlockingId(null);
    }
  };

  const filtered = templates.filter((t) => {
    const matchesSearch =
      t.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.targetRole.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesTier = filterTier === 'all' || t.tier === filterTier;
    return matchesSearch && matchesTier;
  });

  return (
    <div className="space-y-8 animate-fadeIn pb-16">
      {/* Top Banner */}
      <div className="p-6 sm:p-8 rounded-2xl bg-gradient-to-r from-slate-900 via-indigo-950 to-violet-950 text-white shadow-xl border border-slate-800">
        <div className="max-w-2xl space-y-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-violet-500/20 text-violet-300 border border-violet-500/30 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Shared Dynamic Templates Catalogue</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            ATS-Friendly Resume Templates
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            Every template is engineered for 100% parseability by modern Applicant Tracking Systems. Edit in real time, save persistent drafts, and export clean PDFs.
          </p>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search templates by role, focus, or style..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-xl text-xs focus:border-violet-500 focus:outline-hidden"
          />
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setFilterTier('all')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-colors ${
              filterTier === 'all'
                ? 'bg-violet-600 text-white'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            All Tiers ({templates.length})
          </button>
          <button
            onClick={() => setFilterTier('free')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-colors ${
              filterTier === 'free'
                ? 'bg-violet-600 text-white'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Free
          </button>
          <button
            onClick={() => setFilterTier('premium')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-colors ${
              filterTier === 'premium'
                ? 'bg-violet-600 text-white'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Premium
          </button>
        </div>
      </div>

      {/* Templates Grid */}
      {loading ? (
        <div className="py-24 text-center text-slate-400 space-y-2">
          <Layers className="w-8 h-8 animate-spin mx-auto text-violet-500" />
          <p className="text-xs font-medium">Loading templates catalogue...</p>
        </div>
      ) : filtered.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((tmpl) => {
            const isFree = tmpl.tier === 'free';
            const isUnlocked = isFree || tmpl.isUnlocked;

            return (
              <div
                key={tmpl.id}
                className="rounded-2xl bg-white border border-slate-200/80 shadow-xs hover:shadow-lg transition-all flex flex-col justify-between overflow-hidden group"
              >
                <div>
                  {/* Miniature Live Template Preview Canvas */}
                  <div className="relative h-60 bg-slate-100 overflow-hidden border-b border-slate-100 flex items-start justify-center p-2 cursor-pointer"
                       onClick={() => setPreviewTemplate(tmpl)}>
                    <div className="w-[420px] origin-top scale-[0.38] pointer-events-none rounded shadow-sm bg-white">
                      <ResumeTemplateRenderer template={tmpl} data={sampleResumeData} />
                    </div>

                    <div className="absolute inset-0 bg-slate-900/10 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setPreviewTemplate(tmpl);
                        }}
                        className="px-3 py-1.5 rounded-lg bg-white/90 backdrop-blur-xs text-xs font-bold text-slate-900 shadow hover:bg-white flex items-center gap-1.5"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>Quick Preview</span>
                      </button>
                    </div>

                    {/* Tier badge */}
                    <div className="absolute top-3 left-3">
                      <span
                        className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-extrabold uppercase shadow-xs ${
                          isFree
                            ? 'bg-emerald-500 text-white'
                            : 'bg-gradient-to-r from-violet-600 to-indigo-600 text-white'
                        }`}
                      >
                        {isFree ? 'Free' : `Premium • ₹${tmpl.price}`}
                      </span>
                    </div>

                    {/* Unlocked status badge */}
                    <div className="absolute top-3 right-3">
                      {isUnlocked ? (
                        <span className="p-1 rounded-full bg-emerald-100 text-emerald-700 shadow-xs" title="Unlocked & Ready">
                          <Check className="w-3.5 h-3.5" />
                        </span>
                      ) : (
                        <span className="p-1 rounded-full bg-slate-900/70 text-slate-200 shadow-xs" title="Requires entitlement">
                          <Lock className="w-3.5 h-3.5" />
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Metadata */}
                  <div className="p-5 space-y-2">
                    <div className="flex items-center justify-between">
                      <h3 className="font-extrabold text-slate-900 text-base">{tmpl.name}</h3>
                      <span className="text-[11px] font-semibold text-slate-400 font-mono">
                        {tmpl.layoutStyle}
                      </span>
                    </div>

                    <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                      {tmpl.description}
                    </p>

                    <div className="pt-1">
                      <span className="text-[11px] font-semibold text-slate-400">Target Audience:</span>
                      <p className="text-xs font-medium text-slate-700">{tmpl.targetRole}</p>
                    </div>

                    {/* Tags */}
                    <div className="flex flex-wrap gap-1 pt-1">
                      {tmpl.tags?.map((tag, i) => (
                        <span
                          key={i}
                          className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-100 text-slate-600"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="p-5 pt-0">
                  {isUnlocked ? (
                    <button
                      onClick={() => setActiveBuilderTemplate(tmpl)}
                      className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl font-bold text-xs bg-slate-900 hover:bg-slate-800 text-white shadow-xs transition-colors cursor-pointer"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span>Use & Edit Template</span>
                    </button>
                  ) : (
                    <button
                      onClick={() => handleUnlock(tmpl)}
                      disabled={unlockingId === tmpl.id}
                      className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl font-bold text-xs bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white shadow-md shadow-violet-600/25 transition-all cursor-pointer"
                    >
                      <Zap className="w-3.5 h-3.5" />
                      <span>{unlockingId === tmpl.id ? 'Unlocking...' : `Unlock Template (₹${tmpl.price})`}</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="py-20 text-center text-slate-400 space-y-2">
          <Layers className="w-10 h-10 mx-auto opacity-30" />
          <p className="text-sm font-semibold text-slate-600">No matching templates found</p>
        </div>
      )}

      {/* Full Preview Modal */}
      {previewTemplate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
          <div className="max-w-3xl w-full bg-white rounded-2xl p-6 shadow-2xl border border-slate-200 space-y-4 my-8">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-lg font-bold text-slate-900">{previewTemplate.name}</h3>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase ${
                      previewTemplate.tier === 'free'
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-violet-100 text-violet-800'
                    }`}
                  >
                    {previewTemplate.tier === 'free' ? 'Free' : `₹${previewTemplate.price} INR`}
                  </span>
                </div>
                <p className="text-xs text-slate-500">{previewTemplate.targetRole}</p>
              </div>
              <button
                onClick={() => setPreviewTemplate(null)}
                className="text-xs font-semibold px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 cursor-pointer"
              >
                Close
              </button>
            </div>

            <div className="border border-slate-200 rounded-lg overflow-hidden bg-slate-100 p-4 flex justify-center">
              <div className="w-full max-w-xl bg-white shadow">
                <ResumeTemplateRenderer template={previewTemplate} data={sampleResumeData} />
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <button
                onClick={() => {
                  const t = previewTemplate;
                  setPreviewTemplate(null);
                  setActiveBuilderTemplate(t);
                }}
                className="px-5 py-2.5 rounded-xl bg-violet-600 hover:bg-violet-700 text-white text-xs font-semibold shadow-xs transition-colors cursor-pointer"
              >
                Open in Resume Builder
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Interactive Builder Modal */}
      {activeBuilderTemplate && (
        <ResumeBuilderModal
          template={activeBuilderTemplate}
          onClose={() => setActiveBuilderTemplate(null)}
        />
      )}
    </div>
  );
};
