import React, { useEffect, useState } from 'react';
import {
  FileText,
  UploadCloud,
  Layers,
  Award,
  TrendingUp,
  ArrowRight,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  ExternalLink,
  Target,
  FileCheck,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';
import { AnalysisReport, ResumeFile, ResumeDraft } from '../../types';
import { CircularScore } from '../common/CircularScore';

interface UserDashboardViewProps {
  onNavigate: (view: string, extraData?: any) => void;
}

export const UserDashboardView: React.FC<UserDashboardViewProps> = ({ onNavigate }) => {
  const { user } = useAuth();
  const [reports, setReports] = useState<AnalysisReport[]>([]);
  const [resumes, setResumes] = useState<ResumeFile[]>([]);
  const [drafts, setDrafts] = useState<ResumeDraft[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    async function loadUserData() {
      setLoading(true);
      try {
        const [repRes, resRes, draftRes] = await Promise.all([
          api.getHistory(),
          api.getMyResumes(),
          api.getAllDrafts(),
        ]);
        setReports(repRes.reports || []);
        setResumes(resRes.resumes || []);
        setDrafts(draftRes.drafts || []);
      } catch (err) {
        console.error('Error loading dashboard stats:', err);
      } finally {
        setLoading(false);
      }
    }
    loadUserData();
  }, []);

  const totalAnalyzed = reports.length;
  const avgAtsScore =
    totalAnalyzed > 0
      ? Math.round(reports.reduce((acc, r) => acc + r.atsScore, 0) / totalAnalyzed)
      : null;
  const savedDraftsCount = drafts.length;
  const currentPlan = user?.plan === 'premium' ? 'Premium' : 'Free';

  const latestReport = reports[0];

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* 5. Welcome Hero Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-[#0a0f1d] via-[#131b31] to-[#1e1b4b] p-6 sm:p-8 text-white shadow-xl border border-slate-800">
        <div className="relative z-10 max-w-2xl space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-violet-500/20 text-violet-300 border border-violet-500/30 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI-Powered Career Intelligence</span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Welcome, {user?.name || 'Applicant'}!
          </h2>
          <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
            Upload your resumes, measure instant ATS keyword compatibility across specialized job domains, detect missing technical skills, and prepare for interviews with precision.
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-3">
            <button
              onClick={() => onNavigate('user-upload')}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-semibold text-sm bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white shadow-lg shadow-violet-600/30 transition-all hover:scale-[1.02] cursor-pointer"
            >
              <UploadCloud className="w-4 h-4" />
              <span>Upload Resume for Analysis</span>
            </button>
            <button
              onClick={() => onNavigate('user-templates')}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl font-semibold text-sm bg-slate-800/80 hover:bg-slate-700/80 text-slate-200 border border-slate-700 transition-colors cursor-pointer"
            >
              <Layers className="w-4 h-4" />
              <span>Browse Resume Templates</span>
            </button>
          </div>
        </div>

        {/* Decorative background glow */}
        <div className="absolute -right-12 -bottom-12 w-80 h-80 rounded-full bg-violet-600/20 blur-3xl pointer-events-none" />
        <div className="absolute right-32 top-0 w-64 h-64 rounded-full bg-blue-600/15 blur-3xl pointer-events-none" />
      </div>

      {/* 6. Four Summary Cards (Clickable & Real Data) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {/* Card 1: Resumes Analyzed -> Clickable to Analysis History */}
        <button
          onClick={() => onNavigate('user-history')}
          className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs hover:border-violet-300 hover:shadow-md transition-all text-left group cursor-pointer"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 group-hover:text-violet-600 transition-colors">
              Resumes Analyzed
            </span>
            <div className="p-2.5 rounded-xl bg-violet-50 text-violet-600 group-hover:bg-violet-600 group-hover:text-white transition-colors">
              <FileText className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4">
            <span className="text-3xl font-extrabold text-slate-900 tracking-tight">
              {loading ? '...' : totalAnalyzed}
            </span>
            <p className="mt-1 text-xs text-slate-500 flex items-center gap-1">
              <span>View scan history</span>
              <ArrowRight className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity text-violet-600" />
            </p>
          </div>
        </button>

        {/* Card 2: Average ATS Match Score -> Clickable to Reports */}
        <button
          onClick={() => onNavigate('user-reports')}
          className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs hover:border-indigo-300 hover:shadow-md transition-all text-left group cursor-pointer"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 group-hover:text-indigo-600 transition-colors">
              Average ATS Score
            </span>
            <div className="p-2.5 rounded-xl bg-indigo-50 text-indigo-600 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
              <TrendingUp className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4">
            <div className="flex items-baseline gap-1">
              <span className="text-3xl font-extrabold text-slate-900 tracking-tight">
                {loading ? '...' : avgAtsScore !== null ? `${avgAtsScore}%` : 'N/A'}
              </span>
              {avgAtsScore !== null && (
                <span className={`text-xs font-semibold ${avgAtsScore >= 75 ? 'text-emerald-600' : 'text-amber-600'}`}>
                  {avgAtsScore >= 75 ? 'Competitive' : 'Optimizing'}
                </span>
              )}
            </div>
            <p className="mt-1 text-xs text-slate-500 flex items-center gap-1">
              <span>View competency reports</span>
              <ArrowRight className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity text-indigo-600" />
            </p>
          </div>
        </button>

        {/* Card 3: Saved Resume Drafts -> Clickable to Templates */}
        <button
          onClick={() => onNavigate('user-templates')}
          className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs hover:border-blue-300 hover:shadow-md transition-all text-left group cursor-pointer"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 group-hover:text-blue-600 transition-colors">
              Saved Drafts
            </span>
            <div className="p-2.5 rounded-xl bg-blue-50 text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-colors">
              <Layers className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4">
            <span className="text-3xl font-extrabold text-slate-900 tracking-tight">
              {loading ? '...' : savedDraftsCount}
            </span>
            <p className="mt-1 text-xs text-slate-500 flex items-center gap-1">
              <span>Open resume templates</span>
              <ArrowRight className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity text-blue-600" />
            </p>
          </div>
        </button>

        {/* Card 4: Current Plan -> Clickable to Profile */}
        <button
          onClick={() => onNavigate('user-profile')}
          className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs hover:border-amber-300 hover:shadow-md transition-all text-left group cursor-pointer"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 group-hover:text-amber-600 transition-colors">
              Current Plan
            </span>
            <div className="p-2.5 rounded-xl bg-amber-50 text-amber-600 group-hover:bg-amber-600 group-hover:text-white transition-colors">
              <Award className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4">
            <span className="text-2xl font-extrabold text-slate-900 tracking-tight">
              {currentPlan}
            </span>
            <p className="mt-1 text-xs text-slate-500 flex items-center gap-1">
              <span>View account settings</span>
              <ArrowRight className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity text-amber-600" />
            </p>
          </div>
        </button>
      </div>

      {/* 7. Quick Actions Grid (All 5 requested cards) */}
      <div className="space-y-4">
        <h3 className="text-lg font-bold text-slate-900">Quick Actions</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          {/* Action 1: Upload Resume */}
          <button
            onClick={() => onNavigate('user-upload')}
            className="flex flex-col justify-between p-5 rounded-2xl bg-white border border-slate-200/80 hover:border-violet-300 hover:shadow-md transition-all text-left group cursor-pointer"
          >
            <div>
              <div className="p-3 rounded-xl bg-violet-50 text-violet-600 group-hover:bg-violet-600 group-hover:text-white transition-colors w-fit mb-3">
                <UploadCloud className="w-6 h-6" />
              </div>
              <h4 className="font-bold text-slate-900 text-sm group-hover:text-violet-600 transition-colors">
                Upload Resume
              </h4>
              <p className="text-xs text-slate-500 mt-1">
                Drop your PDF or DOCX file to extract 15 key resume parameters.
              </p>
            </div>
            <span className="text-xs font-semibold text-violet-600 mt-4 flex items-center gap-1">
              <span>Upload now</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </span>
          </button>

          {/* Action 2: Analyze Resume */}
          <button
            onClick={() => onNavigate('user-upload')}
            className="flex flex-col justify-between p-5 rounded-2xl bg-white border border-slate-200/80 hover:border-indigo-300 hover:shadow-md transition-all text-left group cursor-pointer"
          >
            <div>
              <div className="p-3 rounded-xl bg-indigo-50 text-indigo-600 group-hover:bg-indigo-600 group-hover:text-white transition-colors w-fit mb-3">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <h4 className="font-bold text-slate-900 text-sm group-hover:text-indigo-600 transition-colors">
                Analyze Resume
              </h4>
              <p className="text-xs text-slate-500 mt-1">
                Run ATS evaluation against target job descriptions and roles.
              </p>
            </div>
            <span className="text-xs font-semibold text-indigo-600 mt-4 flex items-center gap-1">
              <span>Start analysis</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </span>
          </button>

          {/* Action 3: Identify Missing Skills */}
          <button
            onClick={() => onNavigate('user-reports')}
            className="flex flex-col justify-between p-5 rounded-2xl bg-white border border-slate-200/80 hover:border-amber-300 hover:shadow-md transition-all text-left group cursor-pointer"
          >
            <div>
              <div className="p-3 rounded-xl bg-amber-50 text-amber-600 group-hover:bg-amber-600 group-hover:text-white transition-colors w-fit mb-3">
                <Target className="w-6 h-6" />
              </div>
              <h4 className="font-bold text-slate-900 text-sm group-hover:text-amber-600 transition-colors">
                Identify Missing Skills
              </h4>
              <p className="text-xs text-slate-500 mt-1">
                Compare detected skills against domain criteria to spot critical gaps.
              </p>
            </div>
            <span className="text-xs font-semibold text-amber-600 mt-4 flex items-center gap-1">
              <span>View skill gaps</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </span>
          </button>

          {/* Action 4: Browse Resume Templates */}
          <button
            onClick={() => onNavigate('user-templates')}
            className="flex flex-col justify-between p-5 rounded-2xl bg-white border border-slate-200/80 hover:border-blue-300 hover:shadow-md transition-all text-left group cursor-pointer"
          >
            <div>
              <div className="p-3 rounded-xl bg-blue-50 text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-colors w-fit mb-3">
                <Layers className="w-6 h-6" />
              </div>
              <h4 className="font-bold text-slate-900 text-sm group-hover:text-blue-600 transition-colors">
                Browse Templates
              </h4>
              <p className="text-xs text-slate-500 mt-1">
                Choose from FreshStart, TechBasic, CareerEdge, DevPro & more.
              </p>
            </div>
            <span className="text-xs font-semibold text-blue-600 mt-4 flex items-center gap-1">
              <span>View templates</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </span>
          </button>

          {/* Action 5: Prepare for Interviews */}
          <button
            onClick={() => onNavigate('user-interview')}
            className="flex flex-col justify-between p-5 rounded-2xl bg-white border border-slate-200/80 hover:border-emerald-300 hover:shadow-md transition-all text-left group cursor-pointer"
          >
            <div>
              <div className="p-3 rounded-xl bg-emerald-50 text-emerald-600 group-hover:bg-emerald-600 group-hover:text-white transition-colors w-fit mb-3">
                <Award className="w-6 h-6" />
              </div>
              <h4 className="font-bold text-slate-900 text-sm group-hover:text-emerald-600 transition-colors">
                Prepare for Interviews
              </h4>
              <p className="text-xs text-slate-500 mt-1">
                Practice technical, HR, and project questions with AI grading.
              </p>
            </div>
            <span className="text-xs font-semibold text-emerald-600 mt-4 flex items-center gap-1">
              <span>Practice questions</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </span>
          </button>
        </div>
      </div>

      {/* 8. Recent Activity (Latest ATS Analysis + Recent Resume Activity) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Latest ATS Analysis Highlight */}
        <div className="lg:col-span-1 p-6 rounded-2xl bg-white border border-slate-200/80 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-slate-900">Latest ATS Analysis</h3>
              {latestReport && (
                <span className="text-xs text-slate-400 flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5" />
                  {new Date(latestReport.createdAt).toLocaleDateString()}
                </span>
              )}
            </div>

            {latestReport ? (
              <div className="space-y-5">
                <div className="py-2">
                  <CircularScore score={latestReport.atsScore} size={130} />
                </div>

                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/60 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-500">Target Role:</span>
                    <span className="font-semibold text-slate-900">{latestReport.jobRole}</span>
                  </div>
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-500">Job Domain:</span>
                    <span className="font-medium text-slate-800">{latestReport.jobDomain}</span>
                  </div>
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-500">Resume File:</span>
                    <span className="font-mono text-[11px] text-violet-700 truncate max-w-[150px]">
                      {latestReport.resumeFileName}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-500">Analysis Date:</span>
                    <span className="text-slate-700">
                      {new Date(latestReport.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <span className="text-xs font-semibold text-slate-700">Top Strengths:</span>
                  <ul className="text-xs text-slate-600 space-y-1">
                    {latestReport.strengths.slice(0, 2).map((s, i) => (
                      <li key={i} className="flex items-start gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 mt-0.5 shrink-0" />
                        <span>{s}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ) : (
              <div className="py-12 text-center space-y-3">
                <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center mx-auto text-slate-400">
                  <FileText className="w-6 h-6" />
                </div>
                <p className="text-sm font-medium text-slate-600">No resumes analyzed yet</p>
                <p className="text-xs text-slate-400 max-w-xs mx-auto">
                  Upload your resume to receive instant ATS compatibility metrics and actionable suggestions.
                </p>
                <button
                  onClick={() => onNavigate('user-upload')}
                  className="mt-2 text-xs font-semibold text-violet-600 hover:text-violet-700 underline cursor-pointer"
                >
                  Upload your first resume
                </button>
              </div>
            )}
          </div>

          {latestReport && (
            <button
              onClick={() => onNavigate('user-history', { openReportId: latestReport.id })}
              className="mt-6 w-full flex items-center justify-center gap-1.5 py-2.5 rounded-xl bg-violet-50 hover:bg-violet-100 text-violet-700 font-semibold text-xs transition-colors cursor-pointer"
            >
              <span>View Full Report</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Recent Resume Activity Table */}
        <div className="lg:col-span-2 p-6 rounded-2xl bg-white border border-slate-200/80 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="font-bold text-slate-900">Recent Resume Activity</h3>
                <p className="text-xs text-slate-500">Your uploaded documents and analysis processing records</p>
              </div>
              <button
                onClick={() => onNavigate('user-history')}
                className="text-xs font-semibold text-violet-600 hover:text-violet-700 flex items-center gap-1 cursor-pointer"
              >
                <span>View All History</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {resumes.length > 0 || reports.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-400 font-medium">
                      <th className="py-3 px-2">Uploaded Resume</th>
                      <th className="py-3 px-2">Target Role</th>
                      <th className="py-3 px-2 text-center">Status</th>
                      <th className="py-3 px-2">Date</th>
                      <th className="py-3 px-2 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {reports.slice(0, 5).map((rep) => (
                      <tr key={rep.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="py-3.5 px-2">
                          <div className="flex items-center gap-2">
                            <FileCheck className="w-4 h-4 text-violet-500 shrink-0" />
                            <span className="font-medium text-slate-900 truncate max-w-[160px]">
                              {rep.resumeFileName}
                            </span>
                          </div>
                        </td>
                        <td className="py-3.5 px-2">
                          <p className="font-semibold text-slate-800">{rep.jobRole}</p>
                          <p className="text-[11px] text-slate-400">{rep.jobDomain}</p>
                        </td>
                        <td className="py-3.5 px-2 text-center">
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-100">
                            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                            <span>Analyzed ({rep.atsScore}%)</span>
                          </span>
                        </td>
                        <td className="py-3.5 px-2 text-slate-500">
                          {new Date(rep.createdAt).toLocaleDateString()}
                        </td>
                        <td className="py-3.5 px-2 text-right">
                          <button
                            onClick={() => onNavigate('user-history', { openReportId: rep.id })}
                            className="text-violet-600 hover:text-violet-800 font-semibold inline-flex items-center gap-1 cursor-pointer"
                          >
                            <span>View</span>
                            <ExternalLink className="w-3 h-3" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="py-16 text-center text-slate-400">
                <Clock className="w-8 h-8 mx-auto mb-2 opacity-40" />
                <p className="text-sm font-semibold text-slate-600">No recent resume activity</p>
                <p className="text-xs text-slate-400 mt-1">
                  Upload your PDF or Word resume above to begin analysis.
                </p>
              </div>
            )}
          </div>

          <div className="mt-4 pt-4 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span>Showing {Math.min(5, reports.length)} of {reports.length} records</span>
            <span className="text-[11px] text-slate-400">Real-time database sync</span>
          </div>
        </div>
      </div>
    </div>
  );
};
