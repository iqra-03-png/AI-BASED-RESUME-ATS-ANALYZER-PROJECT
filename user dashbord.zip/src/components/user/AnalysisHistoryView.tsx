import React, { useEffect, useState } from 'react';
import {
  Clock,
  FileText,
  Trash2,
  ExternalLink,
  GitCompare,
  Download,
  AlertCircle,
  CheckCircle2,
  X,
  Search,
  ChevronRight,
  TrendingUp,
} from 'lucide-react';
import { api } from '../../services/api';
import { AnalysisReport } from '../../types';
import { CircularScore } from '../common/CircularScore';

interface AnalysisHistoryViewProps {
  onSelectReport: (report: AnalysisReport) => void;
  initialReportId?: string;
}

export const AnalysisHistoryView: React.FC<AnalysisHistoryViewProps> = ({
  onSelectReport,
  initialReportId,
}) => {
  const [reports, setReports] = useState<AnalysisReport[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  // Compare mode
  const [compareIds, setCompareIds] = useState<string[]>([]);
  const [compareModalOpen, setCompareModalOpen] = useState<boolean>(false);
  const [compareData, setCompareData] = useState<{ report1: AnalysisReport; report2: AnalysisReport } | null>(null);

  const loadHistory = async () => {
    setLoading(true);
    try {
      const res = await api.getHistory();
      setReports(res.reports || []);

      if (initialReportId) {
        const found = res.reports?.find((r) => r.id === initialReportId);
        if (found) onSelectReport(found);
      }
    } catch (err) {
      console.error('Failed to load history:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadHistory();
  }, []);

  const handleDelete = async (id: string) => {
    try {
      await api.deleteReport(id);
      setReports(reports.filter((r) => r.id !== id));
      setDeleteConfirmId(null);
    } catch (err) {
      console.error('Delete failed:', err);
    }
  };

  const handleToggleCompare = (id: string) => {
    if (compareIds.includes(id)) {
      setCompareIds(compareIds.filter((i) => i !== id));
    } else {
      if (compareIds.length >= 2) {
        setCompareIds([compareIds[1], id]);
      } else {
        setCompareIds([...compareIds, id]);
      }
    }
  };

  const handleOpenCompare = async () => {
    if (compareIds.length !== 2) return;
    try {
      const res = await api.compareReports(compareIds[0], compareIds[1]);
      setCompareData(res);
      setCompareModalOpen(true);
    } catch (err) {
      console.error('Comparison load error:', err);
    }
  };

  const filteredReports = reports.filter(
    (r) =>
      r.resumeFileName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.jobRole.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.jobDomain.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6 animate-fadeIn pb-16">
      {/* Search & Compare Toolbar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search by resume, domain, or role..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-xl text-xs focus:border-violet-500 focus:outline-hidden"
          />
        </div>

        <div className="flex items-center gap-2">
          {compareIds.length > 0 && (
            <button
              onClick={handleOpenCompare}
              disabled={compareIds.length !== 2}
              className={`inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold shadow-xs transition-colors ${
                compareIds.length === 2
                  ? 'bg-violet-600 hover:bg-violet-700 text-white'
                  : 'bg-slate-100 text-slate-400 cursor-not-allowed'
              }`}
            >
              <GitCompare className="w-4 h-4" />
              <span>Compare Selected ({compareIds.length}/2)</span>
            </button>
          )}

          {compareIds.length > 0 && (
            <button
              onClick={() => setCompareIds([])}
              className="text-xs text-slate-500 hover:text-slate-700 px-2.5 py-1.5"
            >
              Clear selection
            </button>
          )}
        </div>
      </div>

      {/* Reports Table Card */}
      <div className="rounded-2xl bg-white border border-slate-200/80 shadow-xs overflow-hidden">
        {loading ? (
          <div className="py-20 text-center text-slate-400 space-y-2">
            <Clock className="w-8 h-8 animate-spin mx-auto text-violet-500" />
            <p className="text-xs font-medium">Loading analysis records from database...</p>
          </div>
        ) : filteredReports.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/70 text-slate-500 font-semibold uppercase tracking-wider text-[11px]">
                  <th className="py-3.5 px-4 w-12 text-center">Compare</th>
                  <th className="py-3.5 px-4">Resume File</th>
                  <th className="py-3.5 px-4">Target Role & Domain</th>
                  <th className="py-3.5 px-4 text-center">ATS Score</th>
                  <th className="py-3.5 px-4">Analysis Date</th>
                  <th className="py-3.5 px-4">Status</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredReports.map((report) => {
                  const isSelected = compareIds.includes(report.id);
                  return (
                    <tr
                      key={report.id}
                      className={`hover:bg-slate-50/80 transition-colors ${
                        isSelected ? 'bg-violet-50/40' : ''
                      }`}
                    >
                      <td className="py-4 px-4 text-center">
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => handleToggleCompare(report.id)}
                          className="w-4 h-4 text-violet-600 rounded border-slate-300 focus:ring-violet-500 cursor-pointer"
                        />
                      </td>
                      <td className="py-4 px-4">
                        <div className="flex items-center gap-2.5">
                          <div className="p-2 rounded-lg bg-violet-50 text-violet-600">
                            <FileText className="w-4 h-4" />
                          </div>
                          <div>
                            <p className="font-semibold text-slate-900 truncate max-w-[180px]">
                              {report.resumeFileName}
                            </p>
                            <p className="text-[10px] text-slate-400 font-mono">
                              ID: {report.id.slice(0, 10)}
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className="py-4 px-4">
                        <p className="font-bold text-slate-800">{report.jobRole}</p>
                        <p className="text-[11px] text-slate-500">{report.jobDomain}</p>
                      </td>
                      <td className="py-4 px-4 text-center">
                        <span
                          className={`inline-flex items-center px-2.5 py-1 rounded-full font-extrabold text-xs ${
                            report.atsScore >= 80
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                              : report.atsScore >= 70
                              ? 'bg-violet-50 text-violet-700 border border-violet-200'
                              : 'bg-amber-50 text-amber-700 border border-amber-200'
                          }`}
                        >
                          {report.atsScore}%
                        </span>
                      </td>
                      <td className="py-4 px-4 text-slate-500">
                        {new Date(report.createdAt).toLocaleDateString()}
                      </td>
                      <td className="py-4 px-4">
                        <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-100">
                          <CheckCircle2 className="w-3 h-3" />
                          <span>Completed</span>
                        </span>
                      </td>
                      <td className="py-4 px-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => onSelectReport(report)}
                            className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold text-violet-700 bg-violet-50 hover:bg-violet-100 transition-colors"
                          >
                            <span>View Report</span>
                            <ExternalLink className="w-3 h-3" />
                          </button>

                          <button
                            onClick={() => setDeleteConfirmId(report.id)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                            title="Delete this analysis"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="py-16 text-center text-slate-400 space-y-2">
            <Clock className="w-10 h-10 mx-auto opacity-30" />
            <p className="text-sm font-semibold text-slate-600">No matching reports found</p>
            <p className="text-xs text-slate-400">
              Uploaded and analyzed resumes will persist here securely.
            </p>
          </div>
        )}
      </div>

      {/* Confirmation Dialog for Deletion */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="max-w-md w-full bg-white rounded-2xl p-6 shadow-2xl border border-slate-200 space-y-4 animate-scaleUp">
            <div className="flex items-center gap-3">
              <div className="p-3 rounded-full bg-rose-100 text-rose-600">
                <AlertCircle className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-base font-bold text-slate-900">Confirm Deletion</h4>
                <p className="text-xs text-slate-500">
                  Are you sure you want to permanently delete this resume analysis report?
                </p>
              </div>
            </div>

            <p className="text-xs text-slate-600 bg-slate-50 p-3 rounded-xl border border-slate-100">
              This action cannot be undone. Any comparisons or interview prep tied directly to this report will be affected.
            </p>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setDeleteConfirmId(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
              >
                Cancel
              </button>
              <button
                onClick={() => handleDelete(deleteConfirmId)}
                className="px-4 py-2 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-xl shadow-xs"
              >
                Delete Record
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Side-by-Side Comparison Modal */}
      {compareModalOpen && compareData && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
          <div className="max-w-4xl w-full bg-white rounded-2xl p-6 sm:p-8 shadow-2xl border border-slate-200 space-y-6 my-8 animate-scaleUp">
            <div className="flex items-center justify-between border-b border-slate-200 pb-4">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-violet-100 text-violet-700">
                  <GitCompare className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-slate-900">
                    Side-by-Side Resume Analysis Comparison
                  </h3>
                  <p className="text-xs text-slate-500">
                    Compare ATS match metrics across two resume iterations or role targets
                  </p>
                </div>
              </div>
              <button
                onClick={() => setCompareModalOpen(false)}
                className="p-2 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Comparison Grid */}
            <div className="grid grid-cols-2 gap-6">
              {/* Report 1 */}
              <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-4">
                <div className="border-b border-slate-200 pb-2">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-violet-600">
                    Version A
                  </span>
                  <h4 className="font-bold text-slate-900 text-sm mt-0.5 truncate">
                    {compareData.report1.resumeFileName}
                  </h4>
                  <p className="text-xs text-slate-500">
                    {compareData.report1.jobRole} ({compareData.report1.jobDomain})
                  </p>
                </div>

                <div className="flex justify-center py-2">
                  <CircularScore score={compareData.report1.atsScore} size={110} />
                </div>

                <div className="space-y-2 text-xs">
                  <div className="flex justify-between py-1 border-b border-slate-200/60">
                    <span className="text-slate-500">Keywords Match:</span>
                    <span className="font-bold text-slate-800">
                      {compareData.report1.scoreBreakdown.keywordMatch}%
                    </span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-200/60">
                    <span className="text-slate-500">Skills Density:</span>
                    <span className="font-bold text-slate-800">
                      {compareData.report1.scoreBreakdown.skillsMatch}%
                    </span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-200/60">
                    <span className="text-slate-500">Structure Check:</span>
                    <span className="font-bold text-slate-800">
                      {compareData.report1.scoreBreakdown.resumeStructure}%
                    </span>
                  </div>
                </div>

                <div>
                  <span className="text-[11px] font-bold text-slate-700">Validated Skills:</span>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {compareData.report1.matchedSkills.slice(0, 5).map((s, i) => (
                      <span key={i} className="px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 text-[10px] font-semibold">
                        {s}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Report 2 */}
              <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-4">
                <div className="border-b border-slate-200 pb-2">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-600">
                    Version B
                  </span>
                  <h4 className="font-bold text-slate-900 text-sm mt-0.5 truncate">
                    {compareData.report2.resumeFileName}
                  </h4>
                  <p className="text-xs text-slate-500">
                    {compareData.report2.jobRole} ({compareData.report2.jobDomain})
                  </p>
                </div>

                <div className="flex justify-center py-2">
                  <CircularScore score={compareData.report2.atsScore} size={110} />
                </div>

                <div className="space-y-2 text-xs">
                  <div className="flex justify-between py-1 border-b border-slate-200/60">
                    <span className="text-slate-500">Keywords Match:</span>
                    <span className="font-bold text-slate-800">
                      {compareData.report2.scoreBreakdown.keywordMatch}%
                    </span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-200/60">
                    <span className="text-slate-500">Skills Density:</span>
                    <span className="font-bold text-slate-800">
                      {compareData.report2.scoreBreakdown.skillsMatch}%
                    </span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-200/60">
                    <span className="text-slate-500">Structure Check:</span>
                    <span className="font-bold text-slate-800">
                      {compareData.report2.scoreBreakdown.resumeStructure}%
                    </span>
                  </div>
                </div>

                <div>
                  <span className="text-[11px] font-bold text-slate-700">Validated Skills:</span>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {compareData.report2.matchedSkills.slice(0, 5).map((s, i) => (
                      <span key={i} className="px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 text-[10px] font-semibold">
                        {s}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setCompareModalOpen(false)}
                className="px-5 py-2.5 bg-slate-900 text-white rounded-xl text-xs font-semibold hover:bg-slate-800"
              >
                Close Comparison
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
