import React, { useState, useEffect } from 'react';
import {
  Award,
  BookOpen,
  Code2,
  Users,
  Lightbulb,
  CheckCircle2,
  Send,
  Sparkles,
  ChevronDown,
  ChevronUp,
  RefreshCw,
  Star,
  Info,
} from 'lucide-react';
import { api } from '../../services/api';
import { InterviewPrepData, InterviewQuestionItem } from '../../types';

interface InterviewPrepViewProps {
  initialDomain?: string;
  initialRole?: string;
  initialSkills?: string[];
}

export const InterviewPrepView: React.FC<InterviewPrepViewProps> = ({
  initialDomain = 'Web Development',
  initialRole = 'Full-Stack Developer',
  initialSkills = ['TypeScript', 'React', 'Node.js', 'REST APIs', 'SQL'],
}) => {
  const [domain, setDomain] = useState<string>(initialDomain);
  const [role, setRole] = useState<string>(initialRole);
  const [prepData, setPrepData] = useState<InterviewPrepData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState<'tech' | 'hr' | 'project' | 'skills'>('tech');

  // Expanded answer toggles
  const [expandedAnswers, setExpandedAnswers] = useState<Record<string, boolean>>({});

  // Practice Mode state
  const [practiceQuestion, setPracticeQuestion] = useState<InterviewQuestionItem | null>(null);
  const [userPracticeAnswer, setUserPracticeAnswer] = useState<string>('');
  const [evaluating, setEvaluating] = useState<boolean>(false);
  const [evaluationResult, setEvaluationResult] = useState<any | null>(null);

  const fetchPrep = async () => {
    setLoading(true);
    setEvaluationResult(null);
    setPracticeQuestion(null);
    try {
      const res = await api.getInterviewPrep({
        role,
        domain,
        skills: initialSkills,
        projects: [{ title: 'Production Web Platform' }, { title: 'Microservice API' }],
      });
      setPrepData(res);
    } catch (err) {
      console.error('Failed to load interview prep:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPrep();
  }, [domain, role]);

  const toggleAnswer = (key: string) => {
    setExpandedAnswers((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const handleStartPractice = (q: InterviewQuestionItem) => {
    setPracticeQuestion(q);
    setUserPracticeAnswer('');
    setEvaluationResult(null);
  };

  const handleSubmitPractice = async () => {
    if (!practiceQuestion || !userPracticeAnswer.trim()) return;
    setEvaluating(true);
    try {
      const res = await api.evaluateInterviewAnswer({
        question: practiceQuestion.question,
        userAnswer: userPracticeAnswer,
        role,
      });
      setEvaluationResult(res);
    } catch (err) {
      console.error('Evaluation error:', err);
    } finally {
      setEvaluating(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8 animate-fadeIn pb-16">
      {/* Top Banner */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-indigo-900 via-slate-900 to-violet-900 text-white shadow-xl border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-violet-500/20 text-violet-300 border border-violet-500/30 text-xs font-semibold mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Target Role Simulation</span>
          </div>
          <h2 className="text-2xl font-bold tracking-tight">
            Interview Preparation: {role}
          </h2>
          <p className="text-xs text-slate-300 mt-1">
            Domain: <strong>{domain}</strong> • Practice realistic questions and receive instant AI grading.
          </p>
        </div>

        <button
          onClick={fetchPrep}
          disabled={loading}
          className="self-start md:self-auto inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold bg-white/10 hover:bg-white/20 text-white border border-white/20 transition-colors"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Regenerate Questions</span>
        </button>
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap gap-2 p-1.5 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
        {[
          { id: 'tech', label: 'Technical Questions', icon: Code2, count: prepData?.technicalQuestions.length || 0 },
          { id: 'hr', label: 'HR & Behavioral', icon: Users, count: prepData?.hrQuestions.length || 0 },
          { id: 'project', label: 'Project-Based', icon: BookOpen, count: prepData?.projectQuestions.length || 0 },
          { id: 'skills', label: 'Skill Deep-Dives', icon: Award, count: prepData?.skillQuestions.length || 0 },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex-1 min-w-[150px] flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl text-xs font-bold transition-all ${
                isActive
                  ? 'bg-violet-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
              <span className={`px-2 py-0.5 rounded-full text-[10px] ${isActive ? 'bg-white/20' : 'bg-slate-100 text-slate-600'}`}>
                {tab.count}
              </span>
            </button>
          );
        })}
      </div>

      {loading ? (
        <div className="py-20 text-center text-slate-400 space-y-3">
          <Sparkles className="w-8 h-8 animate-spin mx-auto text-violet-600" />
          <p className="text-sm font-semibold text-slate-700">Synthesizing interview questions...</p>
        </div>
      ) : prepData ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Questions List */}
          <div className="lg:col-span-7 space-y-4">
            {(activeTab === 'tech'
              ? prepData.technicalQuestions
              : activeTab === 'hr'
              ? prepData.hrQuestions
              : activeTab === 'project'
              ? prepData.projectQuestions
              : prepData.skillQuestions
            ).map((item, idx) => {
              const key = `${activeTab}-${idx}`;
              const isExpanded = expandedAnswers[key];
              return (
                <div
                  key={idx}
                  className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-3 transition-all hover:border-violet-200"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-2.5">
                      <span className="w-6 h-6 rounded-lg bg-violet-50 text-violet-700 font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                        {idx + 1}
                      </span>
                      <h4 className="text-sm font-bold text-slate-900 leading-snug">
                        {item.question}
                      </h4>
                    </div>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 text-xs text-slate-600 space-y-1">
                    <span className="font-semibold text-slate-800 flex items-center gap-1">
                      <Lightbulb className="w-3.5 h-3.5 text-amber-500" />
                      Interviewer Tip:
                    </span>
                    <p>{item.tips}</p>
                  </div>

                  {isExpanded && (
                    <div className="p-3.5 rounded-xl bg-violet-50/60 border border-violet-100 text-xs text-slate-700 space-y-1.5 animate-fadeIn">
                      <span className="font-bold text-violet-900">Sample High-Scoring Response:</span>
                      <p className="leading-relaxed">{item.sampleAnswer}</p>
                    </div>
                  )}

                  <div className="flex items-center justify-between pt-1 border-t border-slate-100 text-xs">
                    <button
                      onClick={() => toggleAnswer(key)}
                      className="text-violet-600 hover:text-violet-800 font-semibold inline-flex items-center gap-1"
                    >
                      <span>{isExpanded ? 'Hide Sample Answer' : 'Show Sample Answer'}</span>
                      {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                    </button>

                    <button
                      onClick={() => handleStartPractice(item)}
                      className="px-3 py-1.5 rounded-lg bg-slate-900 text-white font-semibold hover:bg-slate-800 transition-colors"
                    >
                      Practice Answering
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Interactive Practice Workspace */}
          <div className="lg:col-span-5 space-y-6">
            <div className="p-6 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-4 sticky top-24">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <h3 className="font-bold text-slate-900 flex items-center gap-2">
                  <Award className="w-4 h-4 text-violet-600" />
                  <span>Interactive Practice Sandbox</span>
                </h3>
                {practiceQuestion && (
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-violet-50 text-violet-700 uppercase">
                    Active
                  </span>
                )}
              </div>

              {practiceQuestion ? (
                <div className="space-y-4">
                  <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/60">
                    <span className="text-[10px] font-bold text-slate-400 uppercase">Target Question:</span>
                    <p className="text-xs font-bold text-slate-900 mt-1">
                      {practiceQuestion.question}
                    </p>
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-700">
                      Type Your Spoken or Written Response:
                    </label>
                    <textarea
                      rows={5}
                      value={userPracticeAnswer}
                      onChange={(e) => setUserPracticeAnswer(e.target.value)}
                      placeholder="Structure your answer using the STAR format (Situation, Task, Action, Result) with specific technologies and metrics..."
                      className="w-full mt-1.5 p-3 rounded-xl border border-slate-200 text-xs text-slate-800 focus:border-violet-500 focus:outline-hidden"
                    />
                  </div>

                  <button
                    onClick={handleSubmitPractice}
                    disabled={evaluating || !userPracticeAnswer.trim()}
                    className={`w-full py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all ${
                      userPracticeAnswer.trim() && !evaluating
                        ? 'bg-violet-600 hover:bg-violet-700 text-white shadow-md'
                        : 'bg-slate-100 text-slate-400 cursor-not-allowed'
                    }`}
                  >
                    {evaluating ? (
                      <>
                        <Sparkles className="w-4 h-4 animate-spin" />
                        <span>Evaluating Response...</span>
                      </>
                    ) : (
                      <>
                        <Send className="w-3.5 h-3.5" />
                        <span>Get Instant AI Coaching Feedback</span>
                      </>
                    )}
                  </button>

                  {/* Evaluation Result */}
                  {evaluationResult && (
                    <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3 animate-fadeIn">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-slate-700">Coach Rating</span>
                        <div className="flex items-center gap-1 text-amber-500 font-extrabold text-sm">
                          <Star className="w-4 h-4 fill-amber-400 text-amber-500" />
                          <span>{evaluationResult.rating}/10</span>
                        </div>
                      </div>

                      <p className="text-xs font-bold text-slate-900">{evaluationResult.verdict}</p>
                      <p className="text-xs text-slate-600">{evaluationResult.feedback}</p>

                      {evaluationResult.strengths?.length > 0 && (
                        <div>
                          <span className="text-[11px] font-bold text-emerald-700">Strengths:</span>
                          <ul className="text-[11px] text-slate-600 list-disc list-inside mt-0.5 space-y-0.5">
                            {evaluationResult.strengths.map((s: string, i: number) => (
                              <li key={i}>{s}</li>
                            ))}
                          </ul>
                        </div>
                      )}

                      {evaluationResult.improvements?.length > 0 && (
                        <div>
                          <span className="text-[11px] font-bold text-amber-700">Areas to Polish:</span>
                          <ul className="text-[11px] text-slate-600 list-disc list-inside mt-0.5 space-y-0.5">
                            {evaluationResult.improvements.map((imp: string, i: number) => (
                              <li key={i}>{imp}</li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ) : (
                <div className="py-8 text-center text-slate-400 space-y-2">
                  <Award className="w-8 h-8 mx-auto opacity-30 text-violet-500" />
                  <p className="text-xs font-semibold text-slate-700">No question selected</p>
                  <p className="text-xs text-slate-400">
                    Click "Practice Answering" on any question to test your articulation and get structured AI scoring.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
};
