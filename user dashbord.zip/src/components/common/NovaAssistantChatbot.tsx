import React, { useState, useRef, useEffect } from 'react';
import {
  MessageSquare,
  X,
  Send,
  Sparkles,
  Bot,
  User as UserIcon,
  RotateCcw,
  Minimize2,
  HelpCircle,
  TrendingUp,
  Briefcase,
  Zap,
  Info
} from 'lucide-react';
import { ResuNovaStore } from '../../services/storage';

interface ChatMessage {
  id: string;
  sender: 'nova' | 'admin';
  text: string;
  timestamp: string;
  chips?: string[];
}

export const NovaAssistantChatbot: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Preserve conversation in React state
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'msg-init',
      sender: 'nova',
      text: "👋 Hi Admin! I'm Nova, your ResuNova Administrative Copilot. I can query real-time ATS scores, candidate volumes, job domain metrics, and system navigation.",
      timestamp: 'Just now',
      chips: [
        'ATS Score Summary',
        'Top Missing Skills',
        'Job Domain Breakdown',
        'How does ATS scoring work?'
      ]
    }
  ]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isOpen, isTyping]);

  const handleSend = (textToSend?: string) => {
    const query = (textToSend || inputText).trim();
    if (!query) return;

    const userMsg: ChatMessage = {
      id: `usr-${Date.now()}`,
      sender: 'admin',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    if (!textToSend) setInputText('');
    setIsTyping(true);

    // Generate accurate contextual administrative response using ResuNovaStore
    setTimeout(() => {
      const lower = query.toLowerCase();
      let reply = '';
      let suggestedChips: string[] | undefined = undefined;

      const analyses = ResuNovaStore.getAnalyses();
      const users = ResuNovaStore.getUsers();
      const domains = ResuNovaStore.getDomains();
      const skills = ResuNovaStore.getSkills();

      const completed = analyses.filter(a => a.status === 'Completed');
      const validScores = completed.map(a => a.atsScore).filter(s => typeof s === 'number');
      const avgScore = validScores.length > 0 ? Math.round(validScores.reduce((a, b) => a + b, 0) / validScores.length) : 0;

      if (lower.includes('ats score') || lower.includes('average score') || lower.includes('score summary')) {
        reply = `📊 **Current ATS Evaluation Summary:**\n- **Evaluated Resumes:** ${completed.length} completed (${analyses.length - completed.length} failed or pending).\n- **Platform Average ATS Score:** **${avgScore}%**.\n- **Highest Score:** ${Math.max(...validScores, 0)}%.\n- **Lowest Score:** ${Math.min(...validScores, 0)}%.\n\nAll scores are computed by comparing extracted candidate skills, keyword density, and experience against target job domain benchmarks.`;
        suggestedChips = ['Top Missing Skills', 'Job Domain Breakdown'];
      } else if (lower.includes('missing') || lower.includes('skill')) {
        // compute actual missing skills from analyses
        const missingSkillMap: Record<string, number> = {};
        analyses.forEach(a => {
          a.missingSkills?.forEach(s => {
            const skillName = typeof s === 'string' ? s : s.name;
            missingSkillMap[skillName] = (missingSkillMap[skillName] || 0) + 1;
          });
        });
        const topMissing = Object.entries(missingSkillMap)
          .sort((a, b) => b[1] - a[1])
          .slice(0, 4)
          .map(([name, count]) => `• **${name}** (missing in ${count} evaluations)`)
          .join('\n');

        reply = `⚠️ **Top Missing Candidate Skills Identified:**\n${topMissing || 'No missing skills flagged in active analyses.'}\n\nYou can manage keyword requirements and weights in the **Skills Management** tab.`;
        suggestedChips = ['ATS Score Summary', 'Job Domain Breakdown'];
      } else if (lower.includes('domain') || lower.includes('role') || lower.includes('popular')) {
        const domainCounts: Record<string, number> = {};
        analyses.forEach(a => {
          const name = a.jobDomainName || 'General Engineering';
          domainCounts[name] = (domainCounts[name] || 0) + 1;
        });
        const sortedDomains = Object.entries(domainCounts)
          .sort((a, b) => b[1] - a[1])
          .slice(0, 4)
          .map(([name, count]) => `• **${name}**: ${count} analyses requested`)
          .join('\n');

        reply = `💼 **Job Domain Analysis Breakdown:**\nThere are **${domains.length} active career domains** configured.\n\n**Most Active Domains:**\n${sortedDomains}\n\nNavigate to **Job Domains & Roles** to modify target skill sets or add new positions.`;
        suggestedChips = ['ATS Score Summary', 'Top Missing Skills'];
      } else if (lower.includes('how does ats') || lower.includes('scoring') || lower.includes('algorithm')) {
        reply = `⚙️ **ResuNova ATS Scoring Algorithm:**\n1. **Text Parsing & Tokenization:** Candidate resume PDF/DOCX is parsed into sections (Experience, Skills, Education).\n2. **Skill Matching (50% weight):** Extracts hard & soft skills against target job role requirements.\n3. **Domain Relevance (30% weight):** Assesses keyword density, tenure, and job titles.\n4. **Formatting Compliance (20% weight):** Verifies clean parsing, standard fonts, and absence of detached tables or OCR corruption.`;
        suggestedChips = ['ATS Score Summary', 'How to add a role?'];
      } else if (lower.includes('add') || lower.includes('create') || lower.includes('role')) {
        reply = `➕ **Adding a Job Role or Skill:**\n1. Go to **Job Domains & Roles** from the sidebar.\n2. Select a target domain or click **Add New Domain**.\n3. Enter the role title, experience level, and required skills.\n4. Changes will automatically calibrate subsequent ATS evaluations.`;
        suggestedChips = ['ATS Score Summary', 'Job Domain Breakdown'];
      } else {
        reply = `I understand you're inquiring about "${query}". As your administrative assistant, I monitor real-time platform data (${users.length} users, ${analyses.length} resume evaluations across ${domains.length} domains).\n\nFeel free to ask for specific metrics like ATS score distribution, missing skills, or domain statistics!`;
        suggestedChips = ['ATS Score Summary', 'Top Missing Skills', 'Job Domain Breakdown'];
      }

      const novaMsg: ChatMessage = {
        id: `nova-${Date.now()}`,
        sender: 'nova',
        text: reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        chips: suggestedChips
      };

      setMessages(prev => [...prev, novaMsg]);
      setIsTyping(false);
    }, 400);
  };

  const handleClearHistory = () => {
    setMessages([
      {
        id: 'msg-init-reset',
        sender: 'nova',
        text: "Conversation refreshed. How can I assist you with ResuNova platform metrics today?",
        timestamp: 'Just now',
        chips: [
          'ATS Score Summary',
          'Top Missing Skills',
          'Job Domain Breakdown'
        ]
      }
    ]);
  };

  return (
    <>
      {/* Floating Circular Violet Button */}
      <div className="fixed bottom-6 right-6 z-40">
        {!isOpen && (
          <button
            onClick={() => setIsOpen(true)}
            className="group relative flex items-center justify-center w-14 h-14 rounded-full bg-[#6D5DFB] hover:bg-[#5B4BE3] text-white shadow-xl shadow-[#6D5DFB]/30 transition-all duration-200 hover:scale-105 active:scale-95 focus:outline-none focus:ring-4 focus:ring-[#6D5DFB]/30"
            aria-label="Open Nova Assistant"
            title="Open Nova Assistant"
          >
            <Sparkles className="w-6 h-6 animate-pulse" />
            <span className="absolute -top-1 -right-1 flex h-3.5 w-3.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-emerald-500 border-2 border-white"></span>
            </span>
          </button>
        )}
      </div>

      {/* Floating Chat Modal Panel */}
      {isOpen && (
        <div className="fixed bottom-6 right-6 z-50 w-[380px] max-w-[calc(100vw-2rem)] h-[540px] max-h-[calc(100vh-5rem)] bg-white rounded-2xl shadow-2xl border border-slate-200/90 flex flex-col overflow-hidden animate-in fade-in slide-in-from-bottom-5 duration-200">
          {/* Header */}
          <div className="bg-gradient-to-r from-[#111827] via-[#1E1B4B] to-[#111827] text-white px-4 py-3.5 flex items-center justify-between shrink-0 border-b border-slate-800">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-[#6D5DFB] to-[#8B5CF6] flex items-center justify-center shadow-inner">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <h3 className="text-sm font-bold tracking-tight text-white">Nova Assistant</h3>
                  <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-[#6D5DFB]/40 text-purple-200 uppercase tracking-wider">
                    Copilot
                  </span>
                </div>
                <div className="flex items-center gap-1.5 text-[11px] text-emerald-400">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                  <span>Active & Ready</span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-1">
              <button
                onClick={handleClearHistory}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/10 transition-colors"
                title="Reset conversation"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setIsOpen(false)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/10 transition-colors"
                title="Close chat"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Conversation Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3.5 bg-slate-50/60 text-xs">
            {messages.map(msg => (
              <div
                key={msg.id}
                className={`flex flex-col ${msg.sender === 'admin' ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 shadow-xs whitespace-pre-line leading-relaxed ${
                    msg.sender === 'admin'
                      ? 'bg-[#6D5DFB] text-white rounded-br-xs'
                      : 'bg-white text-slate-800 border border-slate-200/80 rounded-bl-xs'
                  }`}
                >
                  {msg.text}
                </div>

                <span className="text-[10px] text-slate-400 mt-1 px-1">
                  {msg.timestamp}
                </span>

                {/* Quick Action Suggestion Chips */}
                {msg.chips && msg.chips.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 mt-2 max-w-[90%]">
                    {msg.chips.map((chip, i) => (
                      <button
                        key={i}
                        onClick={() => handleSend(chip)}
                        className="px-2.5 py-1 text-[11px] font-medium text-[#6D5DFB] bg-[#F1EEFF] hover:bg-[#E8E4FF] rounded-lg border border-[#6D5DFB]/20 transition-colors text-left"
                      >
                        {chip}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            ))}

            {isTyping && (
              <div className="flex items-center gap-1.5 text-slate-400 text-xs px-2 py-1 bg-white rounded-xl border border-slate-100 w-fit">
                <Bot className="w-3.5 h-3.5 text-[#6D5DFB] animate-spin" />
                <span>Nova is analyzing platform data...</span>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Input Footer */}
          <div className="p-3 bg-white border-t border-slate-200/80">
            <form
              onSubmit={e => {
                e.preventDefault();
                handleSend();
              }}
              className="flex items-center gap-2"
            >
              <input
                type="text"
                value={inputText}
                onChange={e => setInputText(e.target.value)}
                placeholder="Ask Nova about ATS scores, domains..."
                className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 placeholder-slate-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB] transition-all"
              />
              <button
                type="submit"
                disabled={!inputText.trim()}
                className="p-2 rounded-xl bg-[#6D5DFB] hover:bg-[#5B4BE3] disabled:opacity-40 disabled:hover:bg-[#6D5DFB] text-white transition-colors shrink-0 shadow-xs"
                title="Send message"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>
            <div className="flex items-center justify-between text-[10px] text-slate-400 mt-2 px-1">
              <span>ResuNova Admin Copilot</span>
              <span>Memory preserved</span>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
