import React, { useState } from 'react';
import { Modal } from './Modal';
import { MYSQL_SCHEMA_SQL, FLASK_SERVER_CODE } from '../../services/flask-api-reference';
import { Copy, Check, Database, Server, Code, FileText } from 'lucide-react';
import { useToast } from '../../context/ToastContext';

interface FlaskSchemaModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const FlaskSchemaModal: React.FC<FlaskSchemaModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'sql' | 'flask' | 'endpoints'>('sql');
  const [copied, setCopied] = useState(false);
  const toast = useToast();

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    toast.success('Copied to Clipboard', `${label} copied successfully.`);
    setTimeout(() => setCopied(false), 2000);
  };

  const endpointsList = [
    { method: 'POST', path: '/api/admin/login', desc: 'Authenticates admin, verifies password hash, returns signed JWT access token', auth: 'Public' },
    { method: 'GET', path: '/api/admin/dashboard/stats', desc: 'Computes real KPI aggregates from users, analyses, and domains tables', auth: 'Bearer JWT' },
    { method: 'GET', path: '/api/admin/users', desc: 'Returns paginated, searchable list of registered users with resume counts', auth: 'Bearer JWT' },
    { method: 'PATCH', path: '/api/admin/users/<id>/toggle-status', desc: 'Safely activates or deactivates candidate account', auth: 'Bearer JWT' },
    { method: 'DELETE', path: '/api/admin/users/<id>', desc: 'Deletes user record and cascades associated resume files safely', auth: 'Bearer JWT' },
    { method: 'GET', path: '/api/admin/domains', desc: 'Retrieves all 8 job domains with role and skill counts', auth: 'Bearer JWT' },
    { method: 'POST', path: '/api/admin/domains', desc: 'Creates new domain and validates unique slug and naming', auth: 'Bearer JWT' },
    { method: 'GET', path: '/api/admin/skills', desc: 'Retrieves normalized skills catalog with importance levels and weights', auth: 'Bearer JWT' },
    { method: 'GET', path: '/api/admin/analyses', desc: 'Lists resume analyses with ATS score breakdown and matched/missing skills', auth: 'Bearer JWT' },
    { method: 'POST', path: '/api/admin/analyses/<id>/retry', desc: 'Triggers fallback OCR and NLP parser re-evaluation for failed resumes', auth: 'Bearer JWT' },
    { method: 'GET', path: '/api/admin/questions', desc: 'Fetches interview questions categorized into Technical, HR, Behavioral, Situational', auth: 'Bearer JWT' },
    { method: 'GET', path: '/api/admin/templates', desc: 'Lists ATS-friendly resume templates with format and download metrics', auth: 'Bearer JWT' },
  ];

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Flask REST API & MySQL Database Architecture"
      subtitle="Complete backend specification, normalized schema, and JWT authentication contract for ResuNova."
      maxWidth="4xl"
      footer={
        <div className="flex items-center justify-between w-full">
          <div className="text-xs text-slate-500 font-mono">
            MySQL 8.0+ InnoDB · Python 3.11+ Flask · PyMySQL · Flask-JWT-Extended
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
          >
            Close
          </button>
        </div>
      }
    >
      <div className="space-y-4">
        {/* Tab switchers */}
        <div className="flex items-center gap-2 p-1 bg-slate-100 rounded-xl">
          <button
            onClick={() => setActiveTab('sql')}
            className={`flex items-center gap-2 px-3 py-2 text-xs font-bold rounded-lg transition-colors ${
              activeTab === 'sql'
                ? 'bg-white text-[#6D5DFB] shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Database className="w-4 h-4" />
            <span>MySQL Schema (schema.sql)</span>
          </button>
          <button
            onClick={() => setActiveTab('flask')}
            className={`flex items-center gap-2 px-3 py-2 text-xs font-bold rounded-lg transition-colors ${
              activeTab === 'flask'
                ? 'bg-white text-[#6D5DFB] shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Server className="w-4 h-4" />
            <span>Flask REST Server (app.py)</span>
          </button>
          <button
            onClick={() => setActiveTab('endpoints')}
            className={`flex items-center gap-2 px-3 py-2 text-xs font-bold rounded-lg transition-colors ${
              activeTab === 'endpoints'
                ? 'bg-white text-[#6D5DFB] shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Code className="w-4 h-4" />
            <span>REST Endpoints Contract (12)</span>
          </button>
        </div>

        {/* Tab Content */}
        {activeTab === 'sql' && (
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-slate-600">
                13 Normalized Tables with Foreign Keys & Constraints
              </span>
              <button
                onClick={() => handleCopy(MYSQL_SCHEMA_SQL, 'MySQL Schema')}
                className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold text-[#6D5DFB] bg-[#F1EEFF] hover:bg-[#E8E4FF] rounded-lg transition-colors"
              >
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>Copy SQL DDL</span>
              </button>
            </div>
            <pre className="p-4 bg-slate-900 text-slate-100 rounded-xl text-xs font-mono overflow-x-auto max-h-[50vh] leading-relaxed border border-slate-800">
              {MYSQL_SCHEMA_SQL}
            </pre>
          </div>
        )}

        {activeTab === 'flask' && (
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-slate-600">
                Python Flask Application with SQLAlchemy & JWT Authentication
              </span>
              <button
                onClick={() => handleCopy(FLASK_SERVER_CODE, 'Flask Code')}
                className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold text-[#6D5DFB] bg-[#F1EEFF] hover:bg-[#E8E4FF] rounded-lg transition-colors"
              >
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>Copy Python Code</span>
              </button>
            </div>
            <pre className="p-4 bg-slate-900 text-slate-100 rounded-xl text-xs font-mono overflow-x-auto max-h-[50vh] leading-relaxed border border-slate-800">
              {FLASK_SERVER_CODE}
            </pre>
          </div>
        )}

        {activeTab === 'endpoints' && (
          <div className="overflow-x-auto max-h-[50vh] border border-slate-200 rounded-xl">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase font-semibold">
                <tr>
                  <th className="py-2.5 px-3">Method</th>
                  <th className="py-2.5 px-3">Endpoint</th>
                  <th className="py-2.5 px-3">Auth</th>
                  <th className="py-2.5 px-3">Description</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {endpointsList.map((ep, i) => (
                  <tr key={i} className="hover:bg-slate-50/80">
                    <td className="py-2 px-3 font-mono font-bold">
                      <span className={`px-1.5 py-0.5 rounded text-[10px] ${
                        ep.method === 'GET' ? 'bg-blue-100 text-blue-700' :
                        ep.method === 'POST' ? 'bg-emerald-100 text-emerald-700' :
                        ep.method === 'PATCH' ? 'bg-amber-100 text-amber-700' :
                        'bg-red-100 text-red-700'
                      }`}>
                        {ep.method}
                      </span>
                    </td>
                    <td className="py-2 px-3 font-mono font-semibold text-[#111827]">
                      {ep.path}
                    </td>
                    <td className="py-2 px-3">
                      <span className="font-mono text-[10px] text-slate-500">
                        {ep.auth}
                      </span>
                    </td>
                    <td className="py-2 px-3 text-slate-600">
                      {ep.desc}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </Modal>
  );
};
