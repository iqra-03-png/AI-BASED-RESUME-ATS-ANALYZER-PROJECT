import React from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface StatCardProps {
  title: string;
  value: string | number;
  changePct?: number;
  changeLabel?: string;
  icon: React.ReactNode;
  iconBgColor?: string;
  accentGlow?: boolean;
  subtext?: string;
  onClick?: () => void;
}

export const StatCard: React.FC<StatCardProps> = ({
  title,
  value,
  changePct,
  changeLabel = 'vs last month',
  icon,
  iconBgColor = 'bg-[#F1EEFF] text-[#6D5DFB]',
  accentGlow = false,
  subtext,
  onClick
}) => {
  const isPositive = (changePct ?? 0) >= 0;

  return (
    <div
      onClick={onClick}
      className={`relative bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs transition-all duration-200 ${
        onClick ? 'cursor-pointer hover:border-[#6D5DFB]/40 hover:shadow-md' : ''
      } ${accentGlow ? 'ring-1 ring-[#6D5DFB]/20 bg-gradient-to-br from-white via-white to-[#F1EEFF]/40' : ''}`}
    >
      <div className="flex items-start justify-between">
        <div className="flex-1 min-w-0 pr-3">
          <p className="text-xs font-semibold text-[#6B7280] uppercase tracking-wider truncate mb-1">
            {title}
          </p>
          <div className="flex items-baseline gap-2">
            <h3 className="text-2xl lg:text-3xl font-extrabold text-[#111827] tracking-tight font-mono tabular-nums">
              {value}
            </h3>
          </div>
        </div>

        <div
          className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${iconBgColor} shadow-xs`}
        >
          {icon}
        </div>
      </div>

      {(changePct !== undefined || subtext) && (
        <div className="mt-3.5 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
          {changePct !== undefined ? (
            <div className="flex items-center gap-1.5">
              <span
                className={`inline-flex items-center gap-0.5 font-bold font-mono tabular-nums ${
                  isPositive ? 'text-[#16A34A]' : 'text-[#DC2626]'
                }`}
              >
                {isPositive ? (
                  <TrendingUp className="w-3.5 h-3.5" />
                ) : (
                  <TrendingDown className="w-3.5 h-3.5" />
                )}
                {isPositive ? `+${changePct}%` : `${changePct}%`}
              </span>
              <span className="text-slate-400">{changeLabel}</span>
            </div>
          ) : (
            <span className="text-slate-400">{subtext}</span>
          )}
        </div>
      )}
    </div>
  );
};
