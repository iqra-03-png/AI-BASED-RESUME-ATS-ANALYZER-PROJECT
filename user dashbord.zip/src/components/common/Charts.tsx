import React, { useState } from 'react';

// 1. Resume Analysis Activity (Area / Line Chart)
interface ActivityPoint {
  date: string;
  count: number;
  completed: number;
  failed: number;
}

interface ActivityAreaChartProps {
  data: ActivityPoint[];
  period: 'daily' | 'weekly' | 'monthly';
  onPeriodChange?: (period: 'daily' | 'weekly' | 'monthly') => void;
}

export const ActivityAreaChart: React.FC<ActivityAreaChartProps> = ({
  data,
  period,
  onPeriodChange
}) => {
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);

  if (!data || data.length === 0) {
    return (
      <div className="h-64 flex flex-col items-center justify-center text-slate-400 text-sm">
        <span>No resume analysis activity recorded yet.</span>
      </div>
    );
  }

  const maxVal = Math.max(...data.map(d => d.count), 10);
  const chartHeight = 180;
  const chartWidth = 580;
  const paddingX = 40;
  const paddingY = 20;
  const usableWidth = chartWidth - paddingX * 2;
  const usableHeight = chartHeight - paddingY * 2;

  const points = data.map((d, i) => {
    const x = paddingX + (i / Math.max(data.length - 1, 1)) * usableWidth;
    const y = paddingY + usableHeight - (d.count / maxVal) * usableHeight;
    return { ...d, x, y };
  });

  // Construct SVG path with smooth cubic beziers
  let pathD = '';
  points.forEach((pt, i) => {
    if (i === 0) {
      pathD += `M ${pt.x} ${pt.y}`;
    } else {
      const prev = points[i - 1];
      const cx1 = prev.x + (pt.x - prev.x) / 2;
      const cy1 = prev.y;
      const cx2 = prev.x + (pt.x - prev.x) / 2;
      const cy2 = pt.y;
      pathD += ` C ${cx1} ${cy1}, ${cx2} ${cy2}, ${pt.x} ${pt.y}`;
    }
  });

  const areaD = `${pathD} L ${points[points.length - 1].x} ${chartHeight - paddingY} L ${points[0].x} ${chartHeight - paddingY} Z`;

  const hoveredItem = hoverIndex !== null ? points[hoverIndex] : null;

  return (
    <div className="w-full">
      {/* Header controls */}
      <div className="flex items-center justify-between mb-4">
        <div>
          <h4 className="text-sm font-bold text-[#111827]">Analysis Volume Over Time</h4>
          <p className="text-xs text-[#6B7280]">Daily scans and NLP evaluation throughput</p>
        </div>
        {onPeriodChange && (
          <div className="flex items-center bg-slate-100 p-1 rounded-lg border border-slate-200/60">
            {(['daily', 'weekly', 'monthly'] as const).map(p => (
              <button
                key={p}
                onClick={() => onPeriodChange(p)}
                className={`px-2.5 py-1 text-xs font-semibold rounded-md capitalize transition-colors ${
                  period === p
                    ? 'bg-white text-[#6D5DFB] shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {p}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* SVG Canvas */}
      <div className="relative w-full overflow-hidden bg-slate-50/50 rounded-xl border border-slate-100 p-2">
        <svg
          viewBox={`0 0 ${chartWidth} ${chartHeight}`}
          className="w-full h-auto overflow-visible"
        >
          <defs>
            <linearGradient id="areaGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#6D5DFB" stopOpacity="0.32" />
              <stop offset="100%" stopColor="#6D5DFB" stopOpacity="0.0" />
            </linearGradient>
            <linearGradient id="lineGradient" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#6D5DFB" />
              <stop offset="100%" stopColor="#8B5CF6" />
            </linearGradient>
          </defs>

          {/* Grid lines */}
          {[0, 0.25, 0.5, 0.75, 1].map((ratio, i) => {
            const y = paddingY + usableHeight * (1 - ratio);
            const val = Math.round(maxVal * ratio);
            return (
              <g key={i}>
                <line
                  x1={paddingX}
                  y1={y}
                  x2={chartWidth - paddingX}
                  y2={y}
                  stroke="#E2E8F0"
                  strokeDasharray="3 3"
                  strokeWidth="1"
                />
                <text
                  x={paddingX - 8}
                  y={y + 3}
                  textAnchor="end"
                  className="text-[10px] fill-slate-400 font-mono tabular-nums"
                >
                  {val}
                </text>
              </g>
            );
          })}

          {/* Area fill */}
          <path d={areaD} fill="url(#areaGradient)" />

          {/* Curve line */}
          <path
            d={pathD}
            fill="none"
            stroke="url(#lineGradient)"
            strokeWidth="2.5"
            strokeLinecap="round"
          />

          {/* Interactive vertical hover marker */}
          {hoveredItem && (
            <line
              x1={hoveredItem.x}
              y1={paddingY}
              x2={hoveredItem.x}
              y2={chartHeight - paddingY}
              stroke="#6D5DFB"
              strokeWidth="1.5"
              strokeDasharray="2 2"
            />
          )}

          {/* Points */}
          {points.map((pt, i) => (
            <g
              key={i}
              className="cursor-pointer"
              onMouseEnter={() => setHoverIndex(i)}
              onMouseLeave={() => setHoverIndex(null)}
            >
              <circle
                cx={pt.x}
                cy={pt.y}
                r={hoverIndex === i ? 6 : 3.5}
                className={`transition-all duration-150 ${
                  hoverIndex === i
                    ? 'fill-[#6D5DFB] stroke-white stroke-2 shadow-md'
                    : 'fill-white stroke-[#6D5DFB] stroke-2'
                }`}
              />
              {/* Invisible larger target for easy hovering */}
              <circle cx={pt.x} cy={pt.y} r={16} fill="transparent" />
              {/* X Axis Labels */}
              <text
                x={pt.x}
                y={chartHeight - 4}
                textAnchor="middle"
                className="text-[10px] fill-slate-400 font-sans"
              >
                {pt.date}
              </text>
            </g>
          ))}
        </svg>

        {/* Hover Tooltip Card */}
        {hoveredItem && (
          <div
            className="absolute top-2 right-4 bg-[#111827] text-white px-3 py-2 rounded-lg text-xs shadow-xl pointer-events-none border border-slate-700 animate-in fade-in zoom-in-95 duration-100"
          >
            <div className="font-semibold text-slate-200 border-b border-slate-800 pb-1 mb-1">
              {hoveredItem.date}
            </div>
            <div className="flex items-center justify-between gap-4">
              <span className="text-slate-400">Total Scans:</span>
              <span className="font-mono tabular-nums font-bold text-white">{hoveredItem.count}</span>
            </div>
            <div className="flex items-center justify-between gap-4 text-[11px] text-[#16A34A]">
              <span>Completed:</span>
              <span className="font-mono tabular-nums">{hoveredItem.completed}</span>
            </div>
            {hoveredItem.failed > 0 && (
              <div className="flex items-center justify-between gap-4 text-[11px] text-[#DC2626]">
                <span>Failed/OCR Error:</span>
                <span className="font-mono tabular-nums">{hoveredItem.failed}</span>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

// 2. Popular Job Domains (Horizontal Bar Chart)
export interface DomainMetric {
  name: string;
  count: number;
  percentage: number;
  color?: string;
}

interface PopularDomainsBarChartProps {
  data: DomainMetric[];
  onSelectDomain?: (name: string) => void;
}

export const PopularDomainsBarChart: React.FC<PopularDomainsBarChartProps> = ({
  data,
  onSelectDomain
}) => {
  if (!data || data.length === 0) {
    return (
      <div className="h-64 flex flex-col items-center justify-center text-slate-400 text-sm">
        <span>No domain analysis records available yet.</span>
      </div>
    );
  }

  const maxCount = Math.max(...data.map(d => d.count), 1);

  return (
    <div className="w-full">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h4 className="text-sm font-bold text-[#111827]">Popular Job Domains</h4>
          <p className="text-xs text-[#6B7280]">Sorted by total resume analyses requested</p>
        </div>
      </div>

      <div className="space-y-3.5">
        {data.map((item, idx) => {
          const barWidthPct = Math.max(Math.round((item.count / maxCount) * 100), 4);
          return (
            <div
              key={item.name}
              onClick={() => onSelectDomain?.(item.name)}
              className="group cursor-pointer"
            >
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="font-medium text-[#1F2937] group-hover:text-[#6D5DFB] transition-colors truncate max-w-[200px]">
                  {item.name}
                </span>
                <div className="flex items-center gap-2 text-slate-500 font-mono tabular-nums">
                  <span className="font-bold text-[#111827]">{item.count}</span>
                  <span className="text-[11px] text-slate-400">({item.percentage}%)</span>
                </div>
              </div>
              <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                <div
                  className="h-full rounded-full transition-all duration-500 ease-out group-hover:opacity-90"
                  style={{
                    width: `${barWidthPct}%`,
                    backgroundColor: idx === 0 ? '#6D5DFB' : idx === 1 ? '#8B5CF6' : idx === 2 ? '#3B82F6' : '#94A3B8'
                  }}
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

// 3. Donut Chart for Analysis Status Breakdown
interface DonutSegment {
  label: string;
  count: number;
  color: string;
}

export const StatusDonutChart: React.FC<{ data: DonutSegment[]; totalLabel?: string }> = ({
  data,
  totalLabel = 'Total'
}) => {
  const total = data.reduce((sum, d) => sum + d.count, 0);

  if (total === 0) {
    return (
      <div className="h-48 flex items-center justify-center text-slate-400 text-xs">
        No status records available
      </div>
    );
  }

  const radius = 42;
  const strokeWidth = 14;
  const circumference = 2 * Math.PI * radius;

  let currentOffset = 0;

  return (
    <div className="flex flex-col sm:flex-row items-center justify-center gap-6 py-2">
      <div className="relative w-36 h-36 shrink-0">
        <svg viewBox="0 0 120 120" className="w-full h-full transform -rotate-90">
          <circle
            cx="60"
            cy="60"
            r={radius}
            fill="transparent"
            stroke="#F1F5F9"
            strokeWidth={strokeWidth}
          />
          {data.map((item, idx) => {
            const strokeDasharray = `${(item.count / total) * circumference} ${circumference}`;
            const strokeDashoffset = -currentOffset;
            currentOffset += (item.count / total) * circumference;

            return (
              <circle
                key={idx}
                cx="60"
                cy="60"
                r={radius}
                fill="transparent"
                stroke={item.color}
                strokeWidth={strokeWidth}
                strokeDasharray={strokeDasharray}
                strokeDashoffset={strokeDashoffset}
                strokeLinecap="round"
                className="transition-all duration-700 ease-out hover:opacity-85"
              />
            );
          })}
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
          <span className="text-xl font-bold font-mono tabular-nums text-[#111827]">
            {total}
          </span>
          <span className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold">
            {totalLabel}
          </span>
        </div>
      </div>

      {/* Legend */}
      <div className="flex flex-col gap-2 min-w-[130px]">
        {data.map((item, idx) => {
          const pct = Math.round((item.count / total) * 100);
          return (
            <div key={idx} className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <span
                  className="w-2.5 h-2.5 rounded-full shrink-0"
                  style={{ backgroundColor: item.color }}
                />
                <span className="text-slate-600 truncate max-w-[90px]">{item.label}</span>
              </div>
              <span className="font-mono tabular-nums font-semibold text-slate-800 ml-2">
                {item.count} <span className="text-[10px] text-slate-400">({pct}%)</span>
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};

// 4. Missing Skills Frequency Bar Chart
export const MissingSkillsBarChart: React.FC<{
  skills: { name: string; count: number; importance: string }[];
}> = ({ skills }) => {
  if (!skills || skills.length === 0) {
    return (
      <div className="h-48 flex items-center justify-center text-slate-400 text-xs">
        No missing skill patterns recorded yet.
      </div>
    );
  }

  const maxVal = Math.max(...skills.map(s => s.count), 1);

  return (
    <div className="space-y-3">
      {skills.map((skill) => {
        const pct = Math.round((skill.count / maxVal) * 100);
        return (
          <div key={skill.name}>
            <div className="flex items-center justify-between text-xs mb-1">
              <div className="flex items-center gap-2">
                <span className="font-medium text-[#1F2937]">{skill.name}</span>
                <span className={`text-[10px] font-semibold px-1.5 py-0.2 rounded ${
                  skill.importance === 'High' ? 'bg-red-50 text-red-600' :
                  skill.importance === 'Medium' ? 'bg-amber-50 text-amber-600' :
                  'bg-slate-100 text-slate-600'
                }`}>
                  {skill.importance} Priority
                </span>
              </div>
              <span className="font-mono tabular-nums font-semibold text-slate-700">
                {skill.count} resumes missing
              </span>
            </div>
            <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
              <div
                className="h-full bg-[#EF4444] rounded-full transition-all duration-500"
                style={{ width: `${pct}%` }}
              />
            </div>
          </div>
        );
      })}
    </div>
  );
};
