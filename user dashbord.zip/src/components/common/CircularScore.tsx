import React from 'react';

interface CircularScoreProps {
  score: number;
  size?: number;
  strokeWidth?: number;
  label?: string;
  showGrade?: boolean;
}

export const CircularScore: React.FC<CircularScoreProps> = ({
  score,
  size = 120,
  strokeWidth = 10,
  label = 'ATS Score',
  showGrade = true,
}) => {
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const clampedScore = Math.max(0, Math.min(100, Math.round(score)));
  const strokeDashoffset = circumference - (clampedScore / 100) * circumference;

  let colorClass = 'text-rose-500 stroke-rose-500';
  let badgeText = 'Needs Work';
  let badgeBg = 'bg-rose-50 text-rose-700 border-rose-200';

  if (clampedScore >= 80) {
    colorClass = 'text-emerald-500 stroke-emerald-500';
    badgeText = 'Excellent Match';
    badgeBg = 'bg-emerald-50 text-emerald-700 border-emerald-200';
  } else if (clampedScore >= 70) {
    colorClass = 'text-violet-600 stroke-violet-600';
    badgeText = 'Strong Match';
    badgeBg = 'bg-violet-50 text-violet-700 border-violet-200';
  } else if (clampedScore >= 55) {
    colorClass = 'text-amber-500 stroke-amber-500';
    badgeText = 'Moderate Fit';
    badgeBg = 'bg-amber-50 text-amber-700 border-amber-200';
  }

  return (
    <div className="flex flex-col items-center justify-center text-center">
      <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="rotate-[-90deg]">
          {/* Background Track */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            strokeWidth={strokeWidth}
            className="stroke-slate-200 dark:stroke-slate-800 fill-transparent"
          />
          {/* Active Meter */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            strokeWidth={strokeWidth}
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
            className={`${colorClass} fill-transparent transition-all duration-1000 ease-out`}
          />
        </svg>

        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-3xl font-extrabold text-slate-900 tracking-tight">
            {clampedScore}
            <span className="text-sm font-semibold text-slate-400 ml-0.5">%</span>
          </span>
          <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-500">
            {label}
          </span>
        </div>
      </div>

      {showGrade && (
        <span className={`mt-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold border ${badgeBg}`}>
          {badgeText}
        </span>
      )}
    </div>
  );
};
