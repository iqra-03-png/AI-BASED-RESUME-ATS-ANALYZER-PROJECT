import React, { useState, useRef, useEffect, useTransition } from 'react';
import {
  Menu,
  Search,
  Bell,
  ChevronDown,
  UserCheck,
  Key,
  ShieldCheck,
  LogOut,
  RefreshCw,
  Server,
  Loader2,
  FileSearch,
  Users,
  Briefcase,
  Zap,
  HelpCircle,
  FileText
} from 'lucide-react';
import { NavItemKey } from './Sidebar';
import { ResuNovaStore } from '../../services/storage';
import { SearchResult, SearchCategory } from '../../types';

interface TopbarProps {
  currentTab: NavItemKey;
  onSelectTab: (tab: NavItemKey) => void;
  onOpenMobileSidebar: () => void;
  onRefreshData: () => void;
  onLogout: () => void;
  onOpenFlaskModal: () => void;
  onSelectSearchResult?: (result: SearchResult) => void;
}

interface NotificationItem {
  id: string;
  title: string;
  time: string;
  unread: boolean;
  type: 'info' | 'success' | 'alert';
}

export const Topbar: React.FC<TopbarProps> = ({
  currentTab,
  onSelectTab,
  onOpenMobileSidebar,
  onRefreshData,
  onLogout,
  onOpenFlaskModal,
  onSelectSearchResult,
}) => {
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isNotifOpen, setIsNotifOpen] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Search State
  const [searchVal, setSearchVal] = useState('');
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState<number>(-1);
  const searchContainerRef = useRef<HTMLDivElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);

  const [notifications, setNotifications] = useState<NotificationItem[]>([
    {
      id: 'n1',
      title: 'Parser Failure Flagged: PDF detached tokens (ATS-9036)',
      time: '12m ago',
      unread: true,
      type: 'alert'
    },
    {
      id: 'n2',
      title: 'New Student Registration: Devon Vance (Stanford)',
      time: '45m ago',
      unread: true,
      type: 'info'
    },
    {
      id: 'n3',
      title: 'Automated MySQL Audit: 100% foreign key integrity verified',
      time: '2h ago',
      unread: false,
      type: 'success'
    }
  ]);

  const profileRef = useRef<HTMLDivElement>(null);
  const notifRef = useRef<HTMLDivElement>(null);

  // Close dropdowns on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (profileRef.current && !profileRef.current.contains(e.target as Node)) {
        setIsProfileOpen(false);
      }
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) {
        setIsNotifOpen(false);
      }
      if (searchContainerRef.current && !searchContainerRef.current.contains(e.target as Node)) {
        setIsSearchOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Debounced search effect
  useEffect(() => {
    const q = searchVal.trim();
    if (!q) {
      setSearchResults([]);
      setIsSearching(false);
      setIsSearchOpen(false);
      setSelectedIndex(-1);
      return;
    }

    setIsSearching(true);
    setIsSearchOpen(true);
    setSelectedIndex(-1);

    const timer = setTimeout(() => {
      try {
        const found = ResuNovaStore.globalSearch(q);
        setSearchResults(found);
      } catch (err) {
        console.error('Search error:', err);
        setSearchResults([]);
      } finally {
        setIsSearching(false);
      }
    }, 150);

    return () => clearTimeout(timer);
  }, [searchVal]);

  const tabTitles: Record<NavItemKey, { title: string }> = {
    dashboard: { title: 'Admin Dashboard' },
    users: { title: 'User Management' },
    domains: { title: 'Job Domains & Roles' },
    skills: { title: 'Skills Management' },
    analyses: { title: 'Resume Analysis' },
    templates: { title: 'Resume Templates' },
    reports: { title: 'Reports & Analytics' },
    profile: { title: 'Admin Profile' }
  };

  const currentInfo = tabTitles[currentTab];
  const unreadCount = notifications.filter(n => n.unread).length;

  const handleRefreshClick = () => {
    setIsRefreshing(true);
    onRefreshData();
    setTimeout(() => setIsRefreshing(false), 600);
  };

  const handleMarkAllRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, unread: false })));
  };

  const handleSelectResult = (result: SearchResult) => {
    setIsSearchOpen(false);
    setSearchVal('');
    onSelectTab(result.targetTab);
    if (onSelectSearchResult) {
      onSelectSearchResult(result);
    }
  };

  // Keyboard navigation for search dropdown
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (!isSearchOpen) return;

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex(prev => (prev < searchResults.length - 1 ? prev + 1 : 0));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex(prev => (prev > 0 ? prev - 1 : searchResults.length - 1));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (selectedIndex >= 0 && searchResults[selectedIndex]) {
        handleSelectResult(searchResults[selectedIndex]);
      } else if (searchResults.length > 0) {
        handleSelectResult(searchResults[0]);
      }
    } else if (e.key === 'Escape') {
      setIsSearchOpen(false);
      searchInputRef.current?.blur();
    }
  };

  const categoryIcons: Record<SearchCategory, React.ReactNode> = {
    'User': <Users className="w-3.5 h-3.5 text-blue-500 shrink-0" />,
    'Resume Analysis': <FileSearch className="w-3.5 h-3.5 text-[#6D5DFB] shrink-0" />,
    'Job Domain': <Briefcase className="w-3.5 h-3.5 text-indigo-500 shrink-0" />,
    'Skill': <Zap className="w-3.5 h-3.5 text-amber-500 shrink-0" />,
    'Interview Question': <HelpCircle className="w-3.5 h-3.5 text-emerald-500 shrink-0" />,
    'Resume Template': <FileText className="w-3.5 h-3.5 text-rose-500 shrink-0" />,
  };

  const highlightMatch = (text: string, query: string) => {
    if (!query) return text;
    const regex = new RegExp(`(${query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
    const parts = text.split(regex);
    return parts.map((part, i) =>
      regex.test(part) ? (
        <span key={i} className="text-[#6D5DFB] font-bold underline underline-offset-2 decoration-[#6D5DFB]/40">
          {part}
        </span>
      ) : (
        part
      )
    );
  };

  return (
    <header className="sticky top-0 z-20 bg-white/95 backdrop-blur-md border-b border-slate-200/80 px-4 lg:px-8 py-3.5 flex items-center justify-between gap-4">
      {/* Left: Mobile hamburger + Page Title & Breadcrumb */}
      <div className="flex items-center gap-3 min-w-0">
        <button
          onClick={onOpenMobileSidebar}
          className="lg:hidden p-2 rounded-xl text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors"
          aria-label="Open navigation menu"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="min-w-0">
          <h1 className="text-lg sm:text-xl font-extrabold text-[#111827] tracking-tight truncate leading-tight">
            {currentTab === 'dashboard' ? 'Admin Dashboard' : currentInfo.title}
          </h1>
        </div>
      </div>

      {/* Middle/Right Controls */}
      <div className="flex items-center gap-2.5 sm:gap-4 shrink-0">
        {/* Functional Global Search Bar with Live Dropdown */}
        <div className="relative" ref={searchContainerRef}>
          <div className="relative w-48 sm:w-64 lg:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              ref={searchInputRef}
              type="text"
              placeholder="Search records, skills, IDs..."
              value={searchVal}
              onChange={e => setSearchVal(e.target.value)}
              onFocus={() => {
                if (searchVal.trim()) setIsSearchOpen(true);
              }}
              onKeyDown={handleKeyDown}
              className="w-full bg-[#F7F8FC] border border-slate-200 rounded-xl pl-9 pr-8 py-1.5 text-xs text-[#1F2937] placeholder-slate-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB] transition-all"
            />
            {isSearching && (
              <Loader2 className="w-3.5 h-3.5 text-[#6D5DFB] animate-spin absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            )}
          </div>

          {/* Search Results Dropdown */}
          {isSearchOpen && (
            <div className="absolute right-0 sm:left-0 sm:right-auto mt-2 w-80 sm:w-96 bg-white rounded-2xl shadow-xl border border-slate-200/90 py-2 z-50 animate-in fade-in zoom-in-95 duration-100 max-h-96 overflow-y-auto">
              <div className="px-3 py-1.5 text-[10px] uppercase font-bold text-slate-400 border-b border-slate-100 flex items-center justify-between">
                <span>Database Search Results</span>
                {searchResults.length > 0 && (
                  <span className="font-mono text-slate-500 font-normal">
                    {searchResults.length} found
                  </span>
                )}
              </div>

              {isSearching ? (
                <div className="p-6 text-center text-xs text-slate-400 flex flex-col items-center justify-center gap-2">
                  <Loader2 className="w-4 h-4 animate-spin text-[#6D5DFB]" />
                  <span>Searching ResuNova database records...</span>
                </div>
              ) : searchResults.length === 0 ? (
                <div className="p-6 text-center text-xs text-slate-400">
                  <p className="font-semibold text-slate-600 mb-0.5">No matching records found.</p>
                  <p className="text-[11px]">Try searching by candidate name, skill name, or record ID.</p>
                </div>
              ) : (
                <div className="divide-y divide-slate-50">
                  {searchResults.map((item, idx) => (
                    <button
                      key={`${item.category}-${item.id}-${idx}`}
                      type="button"
                      onClick={() => handleSelectResult(item)}
                      className={`w-full text-left px-3.5 py-2.5 flex items-start gap-3 transition-colors ${
                        selectedIndex === idx
                          ? 'bg-[#F1EEFF] text-[#111827]'
                          : 'hover:bg-slate-50 text-slate-700'
                      }`}
                    >
                      <div className="mt-0.5">{categoryIcons[item.category]}</div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2">
                          <span className="font-bold text-xs text-[#111827] truncate">
                            {highlightMatch(item.title, searchVal.trim())}
                          </span>
                          <span className="text-[10px] font-mono text-slate-400 font-semibold px-1.5 py-0.2 bg-slate-100 rounded shrink-0">
                            {item.id}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500 truncate mt-0.5">
                          {item.subtitle}
                        </p>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Real Refresh Button */}
        <button
          onClick={handleRefreshClick}
          title="Refresh database records"
          className="p-2 rounded-xl text-slate-500 hover:text-[#6D5DFB] hover:bg-[#F1EEFF] transition-colors border border-transparent hover:border-[#6D5DFB]/20"
        >
          <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin text-[#6D5DFB]' : ''}`} />
        </button>

        {/* Notifications Icon with Unread Dropdown */}
        <div className="relative" ref={notifRef}>
          <button
            onClick={() => setIsNotifOpen(!isNotifOpen)}
            className="p-2 rounded-xl text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors relative"
            aria-label="View notifications"
          >
            <Bell className="w-4 h-4" />
            {unreadCount > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[#6D5DFB] ring-2 ring-white" />
            )}
          </button>

          {isNotifOpen && (
            <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-2xl shadow-xl border border-slate-200/90 py-3 z-50 animate-in fade-in zoom-in-95 duration-150">
              <div className="px-4 pb-2 border-b border-slate-100 flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-[#111827] uppercase tracking-wider">
                    Notifications
                  </h4>
                  <p className="text-[11px] text-slate-500">{unreadCount} unread system events</p>
                </div>
                {unreadCount > 0 && (
                  <button
                    onClick={handleMarkAllRead}
                    className="text-[11px] font-semibold text-[#6D5DFB] hover:underline"
                  >
                    Mark all read
                  </button>
                )}
              </div>

              <div className="max-h-72 overflow-y-auto divide-y divide-slate-100">
                {notifications.map(item => (
                  <div
                    key={item.id}
                    className={`px-4 py-3 hover:bg-slate-50 transition-colors text-xs flex items-start gap-3 ${
                      item.unread ? 'bg-[#F1EEFF]/30' : ''
                    }`}
                  >
                    <span
                      className={`w-2 h-2 rounded-full mt-1.5 shrink-0 ${
                        item.type === 'alert'
                          ? 'bg-[#DC2626]'
                          : item.type === 'success'
                          ? 'bg-[#16A34A]'
                          : 'bg-[#6D5DFB]'
                      }`}
                    />
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-[#1F2937] leading-snug">{item.title}</p>
                      <span className="text-[10px] text-slate-400 font-mono mt-0.5 block">
                        {item.time}
                      </span>
                    </div>
                  </div>
                ))}
              </div>

              <div className="px-4 pt-2 border-t border-slate-100 text-center">
                <button
                  onClick={() => {
                    setIsNotifOpen(false);
                    onSelectTab('analyses');
                  }}
                  className="text-xs font-semibold text-[#6D5DFB] hover:text-[#5B4BE3]"
                >
                  View all system logs & analyses →
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Admin Profile Dropdown (Clean, Updated to Iram, Super Admin) */}
        <div className="relative" ref={profileRef}>
          <button
            onClick={() => setIsProfileOpen(!isProfileOpen)}
            className="flex items-center gap-2 p-1.5 rounded-xl hover:bg-slate-100 transition-colors border border-transparent hover:border-slate-200"
          >
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-[#6D5DFB] to-[#8B5CF6] text-white flex items-center justify-center font-bold text-xs shadow-xs">
              I
            </div>
            <div className="hidden sm:block text-left pr-1">
              <span className="text-xs font-bold text-[#111827] block leading-tight">
                Iram
              </span>
              <span className="text-[10px] text-slate-400 font-medium block">Super Admin</span>
            </div>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
          </button>

          {isProfileOpen && (
            <div className="absolute right-0 mt-2 w-56 bg-white rounded-2xl shadow-xl border border-slate-200/90 py-2 z-50 animate-in fade-in zoom-in-95 duration-150">
              <div className="px-4 py-2 border-b border-slate-100">
                <p className="text-xs font-bold text-[#111827]">Iram</p>
                <p className="text-[11px] text-slate-500 font-mono">admin@resunova.ai</p>
              </div>

              <div className="py-1 text-xs text-slate-700">
                <button
                  onClick={() => {
                    setIsProfileOpen(false);
                    onSelectTab('profile');
                  }}
                  className="w-full px-4 py-2 text-left hover:bg-slate-50 flex items-center gap-2.5 transition-colors"
                >
                  <UserCheck className="w-4 h-4 text-[#6D5DFB]" />
                  <span>Admin Profile & Info</span>
                </button>
                <button
                  onClick={() => {
                    setIsProfileOpen(false);
                    onSelectTab('profile');
                  }}
                  className="w-full px-4 py-2 text-left hover:bg-slate-50 flex items-center gap-2.5 transition-colors"
                >
                  <Key className="w-4 h-4 text-slate-500" />
                  <span>Change Password</span>
                </button>
                <button
                  onClick={() => {
                    setIsProfileOpen(false);
                    onOpenFlaskModal();
                  }}
                  className="w-full px-4 py-2 text-left hover:bg-slate-50 flex items-center gap-2.5 transition-colors"
                >
                  <Server className="w-4 h-4 text-[#8B5CF6]" />
                  <span>Flask API & Schema</span>
                </button>
              </div>

              <div className="border-t border-slate-100 pt-1">
                <button
                  onClick={() => {
                    setIsProfileOpen(false);
                    onLogout();
                  }}
                  className="w-full px-4 py-2 text-left text-xs font-medium text-[#DC2626] hover:bg-red-50 flex items-center gap-2.5 transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Log Out</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
