import React from 'react';
import { Menu, UploadCloud, ShieldCheck } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

interface HeaderProps {
  currentView: string;
  onOpenMobile: () => void;
  onNavigate: (view: string) => void;
}

export const Header: React.FC<HeaderProps> = ({ currentView, onOpenMobile, onNavigate }) => {
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin';

  const viewTitles: Record<string, { title: string; subtitle: string }> = {
    'user-dashboard': {
      title: 'Applicant Dashboard',
      subtitle: 'Overview of your resume performance, ATS compatibility and recent activity',
    },
    'user-upload': {
      title: 'Resume Analysis & ATS Scanner',
      subtitle: 'Upload your PDF or DOCX resume to extract data and test role compatibility',
    },
    'user-templates': {
      title: 'Resume Templates Gallery',
      subtitle: 'Explore professional ATS-friendly templates shared across ResuNova',
    },
    'user-history': {
      title: 'Analysis History & Reports',
      subtitle: 'Access, compare, and reopen past resume ATS scans and feedback',
    },
    'user-interview': {
      title: 'Interview Preparation',
      subtitle: 'Domain-specific technical, HR, and project questions tailored to your profile',
    },
    'user-reports': {
      title: 'Reports & Competency Analytics',
      subtitle: 'Track your keyword coverage, skill readiness, and ATS progress over time',
    },
    'user-assistant': {
      title: 'AI Career Assistant',
      subtitle: 'Get actionable feedback on resume bullets, missing skills, and interview questions',
    },
    'user-profile': {
      title: 'Profile & Account Settings',
      subtitle: 'Manage your personal details and account credentials',
    },
    // Admin
    'admin-dashboard': {
      title: 'Administrator Operations Hub',
      subtitle: 'System overview, total analyses, registered applicants, and platform trends',
    },
    'admin-users': {
      title: 'User Management',
      subtitle: 'Inspect registered accounts, change roles, and monitor applicant scan activity',
    },
    'admin-domains': {
      title: 'Job Domains & Roles',
      subtitle: 'Configure target domains, associate specialized roles, and define skill criteria',
    },
    'admin-skills': {
      title: 'Skills Taxonomy Management',
      subtitle: 'Manage technical, soft, and tool skills mapped to hiring requirements',
    },
    'admin-analyses': {
      title: 'Platform Resume Analyses',
      subtitle: 'Audit all applicant submissions, ATS score distributions, and domain queries',
    },
    'admin-templates': {
      title: 'Template Management (Shared System)',
      subtitle: 'Author, price, publish, unpublish, and duplicate templates for users',
    },
    'admin-analytics': {
      title: 'Analytics & Insights',
      subtitle: 'Detailed ATS score breakdowns, conversion metrics, and domain popularity',
    },
    'admin-profile': {
      title: 'Administrator Profile',
      subtitle: 'Admin account security, credentials, and settings',
    },
  };

  const currentMeta = viewTitles[currentView] || {
    title: 'Applicant Dashboard',
    subtitle: 'Overview of your resume performance, ATS compatibility and recent activity',
  };

  return (
    <header className="sticky top-0 z-30 flex items-center justify-between px-4 sm:px-8 py-4 bg-white/95 backdrop-blur-md border-b border-slate-200/80 shadow-xs">
      <div className="flex items-center gap-3">
        <button
          onClick={onOpenMobile}
          className="p-2 text-slate-600 rounded-lg lg:hidden hover:bg-slate-100 focus:outline-hidden"
          aria-label="Open sidebar"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight font-sans">
            {currentMeta.title}
          </h1>
          <p className="hidden sm:block text-xs text-slate-500 font-medium">
            {currentMeta.subtitle}
          </p>
        </div>
      </div>

      <div className="flex items-center gap-3">
        {/* Upload Resume Button */}
        {!isAdmin && (
          <button
            onClick={() => onNavigate('user-upload')}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-white bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 rounded-xl shadow-xs transition-all cursor-pointer"
          >
            <UploadCloud className="w-4 h-4" />
            <span>Upload Resume</span>
          </button>
        )}

        {/* Admin Badge (shown only for Admin users) */}
        {isAdmin && (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200">
            <ShieldCheck className="w-3.5 h-3.5 text-indigo-600" />
            <span>Admin</span>
          </span>
        )}
      </div>
    </header>
  );
};
