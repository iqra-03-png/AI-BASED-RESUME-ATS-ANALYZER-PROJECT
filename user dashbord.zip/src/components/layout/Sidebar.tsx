import React from 'react';
import {
  LayoutDashboard,
  Users,
  Briefcase,
  Zap,
  FileSearch,
  HelpCircle,
  FileText,
  BarChart3,
  UserCheck,
  LogOut,
  ChevronLeft,
  ChevronRight,
  Sparkles,
  Server
} from 'lucide-react';

export type NavItemKey =
  | 'dashboard'
  | 'users'
  | 'domains'
  | 'skills'
  | 'analyses'
  | 'templates'
  | 'reports'
  | 'profile';

interface SidebarProps {
  currentTab: NavItemKey;
  onSelectTab: (tab: NavItemKey) => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
  isMobileOpen: boolean;
  onCloseMobile: () => void;
  onLogout: () => void;
  onOpenFlaskModal: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  isCollapsed,
  onToggleCollapse,
  isMobileOpen,
  onCloseMobile,
  onLogout,
  onOpenFlaskModal,
}) => {
  const navItems: { key: NavItemKey; label: string; icon: React.ReactNode; badge?: string }[] = [
    { key: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard className="w-5 h-5 shrink-0" /> },
    { key: 'users', label: 'User Management', icon: <Users className="w-5 h-5 shrink-0" /> },
    { key: 'domains', label: 'Job Domains & Roles', icon: <Briefcase className="w-5 h-5 shrink-0" /> },
    { key: 'skills', label: 'Skills Management', icon: <Zap className="w-5 h-5 shrink-0" /> },
    { key: 'analyses', label: 'Resume Analysis', icon: <FileSearch className="w-5 h-5 shrink-0" />, badge: 'Live' },
    { key: 'templates', label: 'Resume Templates', icon: <FileText className="w-5 h-5 shrink-0" /> },
    { key: 'reports', label: 'Reports & Analytics', icon: <BarChart3 className="w-5 h-5 shrink-0" /> },
    { key: 'profile', label: 'Admin Profile', icon: <UserCheck className="w-5 h-5 shrink-0" /> },
  ];

  const sidebarContent = (
    <div className="flex flex-col h-full bg-[#111827] text-slate-200 select-none">
      {/* Brand Header: Clean & Compact */}
      <div className={`px-4 py-4 flex items-center justify-between border-b border-slate-800/60 ${isCollapsed ? 'justify-center px-2' : ''}`}>
        <div
          className="flex items-center gap-2.5 cursor-pointer overflow-hidden"
          onClick={() => onSelectTab('dashboard')}
          title="ResuNova Admin Dashboard"
        >
          {/* ResuNova Custom Logo Icon */}
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-[#6D5DFB] via-[#8B5CF6] to-[#4F46E5] flex items-center justify-center text-white shadow-sm shrink-0">
            <svg
              viewBox="0 0 24 24"
              className="w-4 h-4 text-white"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
              <polyline points="14 2 14 8 20 8" />
              <path d="M8 15l3-3 2 2 4-5" />
              <polyline points="14 9 17 9 17 12" />
            </svg>
          </div>

          {!isCollapsed && (
            <span className="text-base font-bold text-white tracking-tight">
              ResuNova
            </span>
          )}
        </div>

        {/* Desktop Collapse Toggle */}
        <button
          onClick={onToggleCollapse}
          className="hidden lg:flex w-6 h-6 rounded-md items-center justify-center text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          title={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          {isCollapsed ? <ChevronRight className="w-3.5 h-3.5" /> : <ChevronLeft className="w-3.5 h-3.5" />}
        </button>
      </div>

      {/* Navigation List - All 9 Core Items Preserved in Exact Order */}
      <nav className="flex-1 overflow-y-auto px-2.5 py-3 space-y-1">
        {navItems.map(item => {
          const isActive = currentTab === item.key;
          return (
            <button
              key={item.key}
              onClick={() => {
                onSelectTab(item.key);
                onCloseMobile();
              }}
              title={isCollapsed ? item.label : undefined}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg font-medium text-xs transition-colors relative ${
                isActive
                  ? 'bg-[#6D5DFB] text-white shadow-xs'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              } ${isCollapsed ? 'justify-center px-2' : ''}`}
            >
              {item.icon}

              {!isCollapsed && (
                <span className="truncate text-left flex-1">{item.label}</span>
              )}

              {isActive && isCollapsed && (
                <div className="absolute left-0 top-1.5 bottom-1.5 w-1 bg-[#8B5CF6] rounded-r" />
              )}
            </button>
          );
        })}
      </nav>

      {/* Bottom Logout Only (No duplicate admin profile card) */}
      <div className="p-2.5 border-t border-slate-800/60">
        <button
          onClick={onLogout}
          title={isCollapsed ? 'Log out' : undefined}
          className={`w-full flex items-center gap-3 px-3 py-2 text-xs font-medium text-slate-400 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-colors ${
            isCollapsed ? 'justify-center px-2' : ''
          }`}
        >
          <LogOut className="w-4 h-4 shrink-0" />
          {!isCollapsed && <span>Log Out</span>}
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Persistent Sidebar */}
      <aside
        className={`hidden lg:block shrink-0 h-screen sticky top-0 transition-all duration-300 ease-in-out z-30 ${
          isCollapsed ? 'w-20' : 'w-64'
        }`}
      >
        {sidebarContent}
      </aside>

      {/* Mobile Drawer Backdrop */}
      {isMobileOpen && (
        <div
          className="lg:hidden fixed inset-0 z-40 bg-slate-950/60 backdrop-blur-xs transition-opacity"
          onClick={onCloseMobile}
        />
      )}

      {/* Mobile Slide-Out Drawer */}
      <aside
        className={`lg:hidden fixed inset-y-0 left-0 z-50 w-72 max-w-[85vw] transform transition-transform duration-300 ease-in-out shadow-2xl ${
          isMobileOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {sidebarContent}
      </aside>
    </>
  );
};
