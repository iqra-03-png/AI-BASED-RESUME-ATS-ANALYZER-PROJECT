import React from 'react';
import {
  Sparkles,
  CheckCircle2,
  Clock,
  ShieldCheck,
  FileText,
  Layers,
  ArrowRight,
  RotateCcw,
} from 'lucide-react';

interface LoggedOutViewProps {
  onResumeSession: () => void;
}

export const LoggedOutView: React.FC<LoggedOutViewProps> = ({ onResumeSession }) => {
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-between text-slate-900 font-sans selection:bg-violet-500 selection:text-white">
      {/* Top Navigation Bar with ResuNova Branding */}
      <header className="w-full bg-[#0a0f1d] border-b border-slate-800 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-violet-600 via-indigo-600 to-blue-500 flex items-center justify-center text-white shadow-lg shadow-violet-500/25 ring-1 ring-white/20">
            <Sparkles className="w-5 h-5 text-violet-100" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xl font-extrabold tracking-tight text-white font-sans">
                Resu<span className="text-violet-400">Nova</span>
              </span>
              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-violet-500/20 text-violet-300 border border-violet-500/30 uppercase">
                AI
              </span>
            </div>
            <p className="text-[11px] font-medium text-slate-400">
              Resume & ATS Suite
            </p>
          </div>
        </div>

        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-800/80 text-slate-300 border border-slate-700 text-xs font-medium">
          <Clock className="w-3.5 h-3.5 text-violet-400" />
          <span>Session Ended</span>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 flex items-center justify-center p-4 sm:p-8">
        <div className="w-full max-w-xl bg-white rounded-3xl border border-slate-200/90 shadow-xl p-8 sm:p-10 text-center animate-fadeIn">
          {/* Success Check Icon */}
          <div className="w-20 h-20 rounded-full bg-emerald-50 border-8 border-emerald-100 flex items-center justify-center mx-auto text-emerald-600 mb-6 shadow-xs">
            <CheckCircle2 className="w-10 h-10" />
          </div>

          {/* Heading & Subtitle */}
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            You have been signed out successfully.
          </h1>
          <p className="mt-2 text-sm sm:text-base text-slate-600 font-medium">
            Thank you for using <span className="font-semibold text-violet-600">ResuNova</span> — Resume & ATS Suite.
          </p>

          {/* Login Page Coming Soon Badge */}
          <div className="mt-6 inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-violet-50 text-violet-700 border border-violet-200/80 text-xs font-semibold">
            <Clock className="w-4 h-4 text-violet-600 animate-pulse" />
            <span>Login Page Coming Soon</span>
          </div>

          <p className="mt-4 text-xs text-slate-500 max-w-md mx-auto leading-relaxed">
            Your authenticated session has been safely closed and sensitive cached credentials were removed.
            Your uploaded resumes, ATS scores, draft documents, and profile details remain preserved in the persistent database.
          </p>

          {/* Preserved Data Highlights */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 my-8 text-left">
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/60">
              <div className="flex items-center gap-2 text-xs font-bold text-slate-800">
                <FileText className="w-4 h-4 text-violet-600" />
                <span>Resumes Safe</span>
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                Your uploaded files and extracted parameters are intact.
              </p>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/60">
              <div className="flex items-center gap-2 text-xs font-bold text-slate-800">
                <ShieldCheck className="w-4 h-4 text-indigo-600" />
                <span>ATS Reports</span>
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                Previous scoring reports and skill gaps are saved.
              </p>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/60">
              <div className="flex items-center gap-2 text-xs font-bold text-slate-800">
                <Layers className="w-4 h-4 text-blue-600" />
                <span>Drafts Kept</span>
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                All saved template customizations are preserved.
              </p>
            </div>
          </div>

          {/* Modular Session Resume Button */}
          <div className="space-y-3 pt-2 border-t border-slate-100">
            <button
              onClick={onResumeSession}
              className="w-full inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl font-bold text-sm bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 text-white shadow-lg shadow-violet-600/25 transition-all hover:scale-[1.01] cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Resume Session (Demo Mode)</span>
              <ArrowRight className="w-4 h-4 ml-1" />
            </button>
            <p className="text-[11px] text-slate-400">
              Note: When your standalone Login & Registration pages are connected, this page will seamlessly transition to the live login route.
            </p>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="w-full py-4 text-center text-xs text-slate-400 border-t border-slate-200 bg-white">
        © {new Date().getFullYear()} ResuNova — Resume & ATS Suite. All rights reserved.
      </footer>
    </div>
  );
};
