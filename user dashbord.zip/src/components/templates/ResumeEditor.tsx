import React, { useState } from 'react';
import {
  ArrowLeft,
  Download,
  RotateCcw,
  Plus,
  Trash2,
  CheckCircle,
  Eye,
  Sparkles,
  FileText,
  User,
  Briefcase,
  GraduationCap,
  Code,
  Award,
  Layers,
  ChevronDown,
  ChevronUp,
  Printer
} from 'lucide-react';
import { ResumeFormData, ResumeTemplate } from '../../types';
import { DEFAULT_SAMPLE_RESUME, renderResumeTemplate } from './ResumeTemplateRenderers';
import { useToast } from '../../context/ToastContext';

interface ResumeEditorProps {
  template: ResumeTemplate;
  onBackToGallery: () => void;
}

export const ResumeEditor: React.FC<ResumeEditorProps> = ({
  template,
  onBackToGallery
}) => {
  const [resumeData, setResumeData] = useState<ResumeFormData>(DEFAULT_SAMPLE_RESUME);
  const [activeSection, setActiveSection] = useState<string>('contact');
  const [zoomLevel, setZoomLevel] = useState<number>(100);

  const toast = useToast();

  const handleResetToSample = () => {
    setResumeData(DEFAULT_SAMPLE_RESUME);
    toast.info('Sample Data Restored', 'Form repopulated with standard student candidate profile.');
  };

  const handleClearForm = () => {
    setResumeData({
      fullName: '',
      title: '',
      email: '',
      phone: '',
      location: '',
      linkedin: '',
      github: '',
      portfolio: '',
      summary: '',
      education: [],
      technicalSkills: [],
      softSkills: [],
      programmingLanguages: [],
      experience: [],
      internships: [],
      projects: [],
      certifications: [],
      achievements: []
    });
    toast.warning('Form Cleared', 'All fields blanked for custom drafting.');
  };

  // Education Helpers
  const handleAddEducation = () => {
    const newEdu = {
      id: `edu-${Date.now()}`,
      institution: 'University Name',
      degree: 'Degree / Major',
      field: 'Field of Study',
      startYear: '2023',
      endYear: '2027',
      score: 'GPA: 3.8 / 4.0'
    };
    setResumeData(prev => ({ ...prev, education: [...prev.education, newEdu] }));
  };

  const handleRemoveEducation = (id: string) => {
    setResumeData(prev => ({
      ...prev,
      education: prev.education.filter(e => e.id !== id)
    }));
  };

  // Projects Helpers
  const handleAddProject = () => {
    const newPrj = {
      id: `prj-${Date.now()}`,
      title: 'Project Title',
      techStack: 'React, Node.js, SQL',
      link: 'github.com/project',
      bullets: ['Describe your key accomplishment and quantified metrics.']
    };
    setResumeData(prev => ({ ...prev, projects: [...prev.projects, newPrj] }));
  };

  const handleRemoveProject = (id: string) => {
    setResumeData(prev => ({
      ...prev,
      projects: prev.projects.filter(p => p.id !== id)
    }));
  };

  // Experience Helpers
  const handleAddExperience = () => {
    const newExp = {
      id: `exp-${Date.now()}`,
      company: 'Company / Organization',
      role: 'Job Role',
      location: 'City, State',
      startDate: 'Jan 2025',
      endDate: 'Present',
      bullets: ['Implemented core business requirement resulting in 20% efficiency gain.']
    };
    setResumeData(prev => ({ ...prev, experience: [...prev.experience, newExp] }));
  };

  const handleRemoveExperience = (id: string) => {
    setResumeData(prev => ({
      ...prev,
      experience: prev.experience.filter(e => e.id !== id)
    }));
  };

  // Certifications Helpers
  const handleAddCertification = () => {
    const newCert = {
      id: `cert-${Date.now()}`,
      name: 'Certification Name',
      issuer: 'Issuing Organization',
      year: '2025'
    };
    setResumeData(prev => ({
      ...prev,
      certifications: [...prev.certifications, newCert]
    }));
  };

  const handleRemoveCertification = (id: string) => {
    setResumeData(prev => ({
      ...prev,
      certifications: prev.certifications.filter(c => c.id !== id)
    }));
  };

  // Achievements Helpers
  const handleAddAchievement = () => {
    const newAch = {
      id: `ach-${Date.now()}`,
      title: 'Honor or Award',
      description: 'Detail about this academic or professional achievement.'
    };
    setResumeData(prev => ({
      ...prev,
      achievements: [...prev.achievements, newAch]
    }));
  };

  const handleRemoveAchievement = (id: string) => {
    setResumeData(prev => ({
      ...prev,
      achievements: prev.achievements.filter(a => a.id !== id)
    }));
  };

  // Native Browser Print to PDF
  const handleDownloadPdf = () => {
    toast.info('Preparing PDF Document', 'Opening browser print dialog. Select "Save as PDF".');
    setTimeout(() => {
      window.print();
    }, 200);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Top Action Bar (Hidden during print) */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs flex flex-wrap items-center justify-between gap-3 print:hidden">
        <div className="flex items-center gap-3">
          <button
            onClick={onBackToGallery}
            className="p-2 rounded-xl text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors"
            title="Back to Template Gallery"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-[#111827]">
                Resume Editor &bull; {template.title}
              </h2>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-emerald-50 text-emerald-700 border border-emerald-200">
                Free Template
              </span>
            </div>
            <p className="text-xs text-[#6B7280]">
              Edit candidate information on the left; live ATS resume renders on the right
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={handleResetToSample}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset to Sample</span>
          </button>

          <button
            onClick={handleDownloadPdf}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-gradient-to-r from-[#6D5DFB] to-[#7C3AED] hover:from-[#5B4BE3] hover:to-[#6D28D9] rounded-xl transition-all shadow-md shadow-[#6D5DFB]/20"
          >
            <Printer className="w-4 h-4" />
            <span>Download PDF</span>
          </button>
        </div>
      </div>

      {/* Editor Main Grid: Form on Left, Live Preview on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Form Editor (lg:col-span-5) (Hidden during print) */}
        <div className="lg:col-span-5 space-y-4 print:hidden">
          {/* Section 1: Contact Details */}
          <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-xs">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900 mb-3 flex items-center gap-2">
              <User className="w-4 h-4 text-[#6D5DFB]" />
              1. Contact Information
            </h3>
            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">Full Name</label>
                <input
                  type="text"
                  value={resumeData.fullName}
                  onChange={e => setResumeData(prev => ({ ...prev, fullName: e.target.value }))}
                  placeholder="e.g. Aarav Sharma"
                  className="w-full bg-[#F7F8FC] border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">Target Professional Title</label>
                <input
                  type="text"
                  value={resumeData.title}
                  onChange={e => setResumeData(prev => ({ ...prev, title: e.target.value }))}
                  placeholder="e.g. Full Stack Software Engineer"
                  className="w-full bg-[#F7F8FC] border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Email Address</label>
                  <input
                    type="email"
                    value={resumeData.email}
                    onChange={e => setResumeData(prev => ({ ...prev, email: e.target.value }))}
                    placeholder="email@example.com"
                    className="w-full bg-[#F7F8FC] border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Phone Number</label>
                  <input
                    type="text"
                    value={resumeData.phone}
                    onChange={e => setResumeData(prev => ({ ...prev, phone: e.target.value }))}
                    placeholder="+1 (555) 000-0000"
                    className="w-full bg-[#F7F8FC] border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Location</label>
                  <input
                    type="text"
                    value={resumeData.location}
                    onChange={e => setResumeData(prev => ({ ...prev, location: e.target.value }))}
                    placeholder="City, State"
                    className="w-full bg-[#F7F8FC] border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">LinkedIn URL</label>
                  <input
                    type="text"
                    value={resumeData.linkedin}
                    onChange={e => setResumeData(prev => ({ ...prev, linkedin: e.target.value }))}
                    placeholder="linkedin.com/in/username"
                    className="w-full bg-[#F7F8FC] border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">GitHub URL</label>
                  <input
                    type="text"
                    value={resumeData.github}
                    onChange={e => setResumeData(prev => ({ ...prev, github: e.target.value }))}
                    placeholder="github.com/username"
                    className="w-full bg-[#F7F8FC] border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Portfolio Website</label>
                  <input
                    type="text"
                    value={resumeData.portfolio}
                    onChange={e => setResumeData(prev => ({ ...prev, portfolio: e.target.value }))}
                    placeholder="portfolio.dev"
                    className="w-full bg-[#F7F8FC] border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Section 2: Career Objective / Summary */}
          <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-xs">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900 mb-3 flex items-center gap-2">
              <FileText className="w-4 h-4 text-[#6D5DFB]" />
              2. Career Objective / Summary
            </h3>
            <textarea
              rows={4}
              value={resumeData.summary}
              onChange={e => setResumeData(prev => ({ ...prev, summary: e.target.value }))}
              placeholder="State your career goals, core strengths, and what you aim to contribute..."
              className="w-full bg-[#F7F8FC] border border-slate-200 rounded-xl p-3 text-xs text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30"
            />
          </div>

          {/* Section 3: Education (Repeatable with Add/Remove) */}
          <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-xs">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900 flex items-center gap-2">
                <GraduationCap className="w-4 h-4 text-[#6D5DFB]" />
                3. Education
              </h3>
              <button
                type="button"
                onClick={handleAddEducation}
                className="flex items-center gap-1 text-[11px] font-bold text-[#6D5DFB] hover:text-[#5B4BE3]"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Education</span>
              </button>
            </div>

            <div className="space-y-3">
              {resumeData.education.map((edu, idx) => (
                <div key={edu.id} className="p-3 bg-[#F7F8FC] rounded-xl border border-slate-200/60 relative group">
                  <button
                    type="button"
                    onClick={() => handleRemoveEducation(edu.id)}
                    className="absolute top-2.5 right-2.5 text-slate-400 hover:text-red-500 transition-colors"
                    title="Remove item"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                  <div className="space-y-2 text-xs pr-6">
                    <input
                      type="text"
                      value={edu.institution}
                      onChange={e => {
                        const val = e.target.value;
                        setResumeData(prev => ({
                          ...prev,
                          education: prev.education.map(it => it.id === edu.id ? { ...it, institution: val } : it)
                        }));
                      }}
                      placeholder="University / College"
                      className="w-full font-bold bg-white border border-slate-200 rounded-lg px-2.5 py-1.5"
                    />
                    <div className="grid grid-cols-2 gap-2">
                      <input
                        type="text"
                        value={edu.degree}
                        onChange={e => {
                          const val = e.target.value;
                          setResumeData(prev => ({
                            ...prev,
                            education: prev.education.map(it => it.id === edu.id ? { ...it, degree: val } : it)
                          }));
                        }}
                        placeholder="Degree (e.g. B.Tech / B.S.)"
                        className="bg-white border border-slate-200 rounded-lg px-2.5 py-1.5"
                      />
                      <input
                        type="text"
                        value={edu.field}
                        onChange={e => {
                          const val = e.target.value;
                          setResumeData(prev => ({
                            ...prev,
                            education: prev.education.map(it => it.id === edu.id ? { ...it, field: val } : it)
                          }));
                        }}
                        placeholder="Major / Field of Study"
                        className="bg-white border border-slate-200 rounded-lg px-2.5 py-1.5"
                      />
                    </div>
                    <div className="grid grid-cols-3 gap-2">
                      <input
                        type="text"
                        value={edu.startYear}
                        onChange={e => {
                          const val = e.target.value;
                          setResumeData(prev => ({
                            ...prev,
                            education: prev.education.map(it => it.id === edu.id ? { ...it, startYear: val } : it)
                          }));
                        }}
                        placeholder="Start Year"
                        className="bg-white border border-slate-200 rounded-lg px-2.5 py-1.5"
                      />
                      <input
                        type="text"
                        value={edu.endYear}
                        onChange={e => {
                          const val = e.target.value;
                          setResumeData(prev => ({
                            ...prev,
                            education: prev.education.map(it => it.id === edu.id ? { ...it, endYear: val } : it)
                          }));
                        }}
                        placeholder="End Year"
                        className="bg-white border border-slate-200 rounded-lg px-2.5 py-1.5"
                      />
                      <input
                        type="text"
                        value={edu.score}
                        onChange={e => {
                          const val = e.target.value;
                          setResumeData(prev => ({
                            ...prev,
                            education: prev.education.map(it => it.id === edu.id ? { ...it, score: val } : it)
                          }));
                        }}
                        placeholder="GPA or %"
                        className="bg-white border border-slate-200 rounded-lg px-2.5 py-1.5"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Section 4: Skills */}
          <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-xs">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900 mb-3 flex items-center gap-2">
              <Code className="w-4 h-4 text-[#6D5DFB]" />
              4. Skills (Comma Separated)
            </h3>
            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  Programming Languages
                </label>
                <input
                  type="text"
                  value={resumeData.programmingLanguages.join(', ')}
                  onChange={e => {
                    const arr = e.target.value.split(',').map(s => s.trim()).filter(Boolean);
                    setResumeData(prev => ({ ...prev, programmingLanguages: arr }));
                  }}
                  placeholder="Python, Java, TypeScript, C++, SQL"
                  className="w-full bg-[#F7F8FC] border border-slate-200 rounded-xl px-3 py-2 text-slate-800"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  Technical Skills & Frameworks
                </label>
                <input
                  type="text"
                  value={resumeData.technicalSkills.join(', ')}
                  onChange={e => {
                    const arr = e.target.value.split(',').map(s => s.trim()).filter(Boolean);
                    setResumeData(prev => ({ ...prev, technicalSkills: arr }));
                  }}
                  placeholder="React.js, Node.js, Docker, PostgreSQL, REST APIs"
                  className="w-full bg-[#F7F8FC] border border-slate-200 rounded-xl px-3 py-2 text-slate-800"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  Soft Skills
                </label>
                <input
                  type="text"
                  value={resumeData.softSkills.join(', ')}
                  onChange={e => {
                    const arr = e.target.value.split(',').map(s => s.trim()).filter(Boolean);
                    setResumeData(prev => ({ ...prev, softSkills: arr }));
                  }}
                  placeholder="Agile Collaboration, Problem Solving, Communication"
                  className="w-full bg-[#F7F8FC] border border-slate-200 rounded-xl px-3 py-2 text-slate-800"
                />
              </div>
            </div>
          </div>

          {/* Section 5: Projects (Repeatable) */}
          <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-xs">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900 flex items-center gap-2">
                <Briefcase className="w-4 h-4 text-[#6D5DFB]" />
                5. Projects
              </h3>
              <button
                type="button"
                onClick={handleAddProject}
                className="flex items-center gap-1 text-[11px] font-bold text-[#6D5DFB] hover:text-[#5B4BE3]"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Project</span>
              </button>
            </div>

            <div className="space-y-3">
              {resumeData.projects.map((prj, idx) => (
                <div key={prj.id} className="p-3 bg-[#F7F8FC] rounded-xl border border-slate-200/60 relative">
                  <button
                    type="button"
                    onClick={() => handleRemoveProject(prj.id)}
                    className="absolute top-2.5 right-2.5 text-slate-400 hover:text-red-500"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                  <div className="space-y-2 text-xs pr-6">
                    <input
                      type="text"
                      value={prj.title}
                      onChange={e => {
                        const val = e.target.value;
                        setResumeData(prev => ({
                          ...prev,
                          projects: prev.projects.map(p => p.id === prj.id ? { ...p, title: val } : p)
                        }));
                      }}
                      placeholder="Project Name"
                      className="w-full font-bold bg-white border border-slate-200 rounded-lg px-2.5 py-1.5"
                    />
                    <div className="grid grid-cols-2 gap-2">
                      <input
                        type="text"
                        value={prj.techStack}
                        onChange={e => {
                          const val = e.target.value;
                          setResumeData(prev => ({
                            ...prev,
                            projects: prev.projects.map(p => p.id === prj.id ? { ...p, techStack: val } : p)
                          }));
                        }}
                        placeholder="Tech Stack"
                        className="bg-white border border-slate-200 rounded-lg px-2.5 py-1.5"
                      />
                      <input
                        type="text"
                        value={prj.link || ''}
                        onChange={e => {
                          const val = e.target.value;
                          setResumeData(prev => ({
                            ...prev,
                            projects: prev.projects.map(p => p.id === prj.id ? { ...p, link: val } : p)
                          }));
                        }}
                        placeholder="GitHub / Live Demo URL"
                        className="bg-white border border-slate-200 rounded-lg px-2.5 py-1.5"
                      />
                    </div>
                    <textarea
                      rows={2}
                      value={prj.bullets.join('\n')}
                      onChange={e => {
                        const lines = e.target.value.split('\n').filter(Boolean);
                        setResumeData(prev => ({
                          ...prev,
                          projects: prev.projects.map(p => p.id === prj.id ? { ...p, bullets: lines } : p)
                        }));
                      }}
                      placeholder="Bullet points (one per line)..."
                      className="w-full bg-white border border-slate-200 rounded-lg p-2 text-xs"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Section 6: Experience & Internships (Repeatable) */}
          <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-xs">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900 flex items-center gap-2">
                <Briefcase className="w-4 h-4 text-[#6D5DFB]" />
                6. Work Experience / Internships
              </h3>
              <button
                type="button"
                onClick={handleAddExperience}
                className="flex items-center gap-1 text-[11px] font-bold text-[#6D5DFB] hover:text-[#5B4BE3]"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Experience</span>
              </button>
            </div>

            <div className="space-y-3">
              {resumeData.experience.map((exp, idx) => (
                <div key={exp.id} className="p-3 bg-[#F7F8FC] rounded-xl border border-slate-200/60 relative">
                  <button
                    type="button"
                    onClick={() => handleRemoveExperience(exp.id)}
                    className="absolute top-2.5 right-2.5 text-slate-400 hover:text-red-500"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                  <div className="space-y-2 text-xs pr-6">
                    <div className="grid grid-cols-2 gap-2">
                      <input
                        type="text"
                        value={exp.role}
                        onChange={e => {
                          const val = e.target.value;
                          setResumeData(prev => ({
                            ...prev,
                            experience: prev.experience.map(it => it.id === exp.id ? { ...it, role: val } : it)
                          }));
                        }}
                        placeholder="Job / Intern Title"
                        className="bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 font-bold"
                      />
                      <input
                        type="text"
                        value={exp.company}
                        onChange={e => {
                          const val = e.target.value;
                          setResumeData(prev => ({
                            ...prev,
                            experience: prev.experience.map(it => it.id === exp.id ? { ...it, company: val } : it)
                          }));
                        }}
                        placeholder="Company"
                        className="bg-white border border-slate-200 rounded-lg px-2.5 py-1.5"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <input
                        type="text"
                        value={exp.startDate}
                        onChange={e => {
                          const val = e.target.value;
                          setResumeData(prev => ({
                            ...prev,
                            experience: prev.experience.map(it => it.id === exp.id ? { ...it, startDate: val } : it)
                          }));
                        }}
                        placeholder="Start Date"
                        className="bg-white border border-slate-200 rounded-lg px-2.5 py-1.5"
                      />
                      <input
                        type="text"
                        value={exp.endDate}
                        onChange={e => {
                          const val = e.target.value;
                          setResumeData(prev => ({
                            ...prev,
                            experience: prev.experience.map(it => it.id === exp.id ? { ...it, endDate: val } : it)
                          }));
                        }}
                        placeholder="End Date"
                        className="bg-white border border-slate-200 rounded-lg px-2.5 py-1.5"
                      />
                    </div>
                    <textarea
                      rows={2}
                      value={exp.bullets.join('\n')}
                      onChange={e => {
                        const lines = e.target.value.split('\n').filter(Boolean);
                        setResumeData(prev => ({
                          ...prev,
                          experience: prev.experience.map(it => it.id === exp.id ? { ...it, bullets: lines } : it)
                        }));
                      }}
                      placeholder="Bullet accomplishments (one per line)..."
                      className="w-full bg-white border border-slate-200 rounded-lg p-2 text-xs"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Section 7: Certifications & Achievements */}
          <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-xs">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900 flex items-center gap-2">
                <Award className="w-4 h-4 text-[#6D5DFB]" />
                7. Certifications & Achievements
              </h3>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={handleAddCertification}
                  className="text-[11px] font-bold text-[#6D5DFB] hover:text-[#5B4BE3]"
                >
                  + Cert
                </button>
                <button
                  type="button"
                  onClick={handleAddAchievement}
                  className="text-[11px] font-bold text-[#6D5DFB] hover:text-[#5B4BE3]"
                >
                  + Award
                </button>
              </div>
            </div>

            <div className="space-y-3">
              {resumeData.certifications.map(cert => (
                <div key={cert.id} className="flex items-center gap-2 text-xs">
                  <input
                    type="text"
                    value={cert.name}
                    onChange={e => {
                      const val = e.target.value;
                      setResumeData(prev => ({
                        ...prev,
                        certifications: prev.certifications.map(c => c.id === cert.id ? { ...c, name: val } : c)
                      }));
                    }}
                    placeholder="Cert Name"
                    className="flex-1 bg-[#F7F8FC] border border-slate-200 rounded-lg px-2.5 py-1"
                  />
                  <input
                    type="text"
                    value={cert.issuer}
                    onChange={e => {
                      const val = e.target.value;
                      setResumeData(prev => ({
                        ...prev,
                        certifications: prev.certifications.map(c => c.id === cert.id ? { ...c, issuer: val } : c)
                      }));
                    }}
                    placeholder="Issuer"
                    className="w-24 bg-[#F7F8FC] border border-slate-200 rounded-lg px-2 py-1"
                  />
                  <input
                    type="text"
                    value={cert.year}
                    onChange={e => {
                      const val = e.target.value;
                      setResumeData(prev => ({
                        ...prev,
                        certifications: prev.certifications.map(c => c.id === cert.id ? { ...c, year: val } : c)
                      }));
                    }}
                    placeholder="Year"
                    className="w-16 bg-[#F7F8FC] border border-slate-200 rounded-lg px-2 py-1"
                  />
                  <button
                    type="button"
                    onClick={() => handleRemoveCertification(cert.id)}
                    className="text-slate-400 hover:text-red-500"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Live Resume Preview (lg:col-span-7) */}
        <div className="lg:col-span-7 space-y-3">
          <div className="bg-white rounded-2xl p-3 border border-slate-200/80 shadow-xs flex items-center justify-between print:hidden">
            <div className="flex items-center gap-2 text-xs text-slate-600">
              <Eye className="w-4 h-4 text-[#6D5DFB]" />
              <span className="font-semibold text-slate-800">Live ATS Resume Preview</span>
              <span className="text-slate-400">&bull;</span>
              <span className="text-slate-500">Updates instantly as you type</span>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-[11px] text-slate-400 font-mono">A4 Ready</span>
              <button
                onClick={handleDownloadPdf}
                className="flex items-center gap-1 px-3 py-1.5 text-xs font-bold text-white bg-[#6D5DFB] hover:bg-[#5B4BE3] rounded-lg transition-colors shadow-xs"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Save PDF</span>
              </button>
            </div>
          </div>

          {/* Printable Resume Container */}
          <div
            id="resume-print-area"
            className="bg-slate-100 p-2 sm:p-4 rounded-2xl border border-slate-200 overflow-x-auto shadow-inner print:p-0 print:m-0 print:border-none print:shadow-none print:bg-white"
          >
            {renderResumeTemplate(template.templateKey, resumeData, false)}
          </div>
        </div>
      </div>
    </div>
  );
};
