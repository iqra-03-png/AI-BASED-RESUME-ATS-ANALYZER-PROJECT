import React from 'react';
import { ResumeFormData } from '../../types';
import { Mail, Phone, MapPin, Globe, Github, Linkedin, Award, Briefcase, GraduationCap, Code, CheckCircle, ExternalLink } from 'lucide-react';

export const DEFAULT_SAMPLE_RESUME: ResumeFormData = {
  fullName: 'Aarav Sharma',
  title: 'Full Stack Software Engineer',
  email: 'aarav.sharma@stanford.edu',
  phone: '+1 (555) 234-5678',
  location: 'San Francisco, CA',
  linkedin: 'linkedin.com/in/aarav-sharma',
  github: 'github.com/aaravsharma',
  portfolio: 'aaravsharma.dev',
  summary:
    'Dedicated Software Engineer with strong foundations in full-stack architecture, distributed systems, and modern web frameworks. Proven track record in building production-ready RESTful microservices, optimizing database queries, and collaborating within Agile sprint cycles.',
  education: [
    {
      id: 'edu-1',
      institution: 'Stanford University',
      degree: 'Bachelor of Science',
      field: 'Computer Science & Software Systems',
      startYear: '2022',
      endYear: '2026',
      score: 'GPA: 3.88 / 4.0 (Dean\'s Honor List)'
    },
    {
      id: 'edu-2',
      institution: 'Delhi Public School',
      degree: 'Senior Secondary Certificate',
      field: 'Physics, Chemistry, Mathematics & CS',
      startYear: '2020',
      endYear: '2022',
      score: 'Percentage: 96.4%'
    }
  ],
  technicalSkills: [
    'React.js',
    'Node.js / Express',
    'PostgreSQL & MySQL',
    'Docker & Containers',
    'RESTful APIs',
    'Git & GitHub CI/CD',
    'Redis Cache',
    'Tailwind CSS'
  ],
  softSkills: [
    'Agile Collaboration',
    'Problem Solving',
    'Technical Documentation',
    'Cross-Functional Communication'
  ],
  programmingLanguages: [
    'Python',
    'TypeScript',
    'JavaScript (ES6+)',
    'Java',
    'SQL',
    'C++'
  ],
  experience: [
    {
      id: 'exp-1',
      company: 'Apex Cloud Innovations',
      role: 'Associate Software Engineer Intern',
      location: 'San Jose, CA',
      startDate: 'Jun 2025',
      endDate: 'Aug 2025',
      bullets: [
        'Architected asynchronous message processing queue using Redis and Node.js, reducing background job latency by 42%.',
        'Implemented 18+ high-traffic REST endpoints verified through Jest automated test suites with 92% code coverage.',
        'Collaborated with 6 senior engineers in bi-weekly Agile sprints, participating in code reviews and CI/CD releases.'
      ]
    },
    {
      id: 'exp-2',
      company: 'Stanford Career Tech Center',
      role: 'Peer Technical Assistant',
      location: 'Stanford, CA',
      startDate: 'Sep 2024',
      endDate: 'May 2025',
      bullets: [
        'Guided 140+ engineering undergraduate students in data structures, algorithmic complexity, and full-stack debug workflows.',
        'Developed internal student check-in portal using React and PostgreSQL, eliminating paper logs.'
      ]
    }
  ],
  internships: [
    {
      id: 'int-1',
      company: 'TechVibe Labs',
      role: 'Web Development Intern',
      location: 'Remote',
      startDate: 'Jan 2025',
      endDate: 'Apr 2025',
      bullets: [
        'Refactored customer checkout flow into responsive React components, improving mobile conversion rate by 14%.',
        'Integrated Stripe payments sandbox and automated webhook handlers.'
      ]
    }
  ],
  projects: [
    {
      id: 'prj-1',
      title: 'ResuNova — AI ATS Resume Analyzer',
      techStack: 'React, TypeScript, Python NLP, Tailwind CSS',
      link: 'github.com/aaravsharma/resunova',
      bullets: [
        'Engineered an intelligent ATS parser parsing PDF resumes to extract structured skills, work history, and contact details.',
        'Calculated semantic keyword compatibility scoring and missing skill recommendations against job descriptions.'
      ]
    },
    {
      id: 'prj-2',
      title: 'DevPulse — Real-Time Developer Collaboration Board',
      techStack: 'Node.js, WebSockets, Redis, PostgreSQL',
      link: 'github.com/aaravsharma/devpulse',
      bullets: [
        'Built real-time collaborative kanban board with sub-50ms WebSocket synchronisation across concurrent browser tabs.',
        'Dockerized development and production pipelines for seamless multi-container deployment.'
      ]
    }
  ],
  certifications: [
    {
      id: 'cert-1',
      name: 'AWS Certified Cloud Practitioner (CLF-C02)',
      issuer: 'Amazon Web Services',
      year: '2025'
    },
    {
      id: 'cert-2',
      name: 'Meta Certified Front-End Developer Specialization',
      issuer: 'Coursera / Meta',
      year: '2024'
    }
  ],
  achievements: [
    {
      id: 'ach-1',
      title: '1st Place Winner — Stanford Autumn Hackathon',
      description: 'Awarded first place among 65 collegiate teams for developing an accessible voice-navigated campus guide.'
    },
    {
      id: 'ach-2',
      title: 'National Merit Scholar Finalist',
      description: 'Recognized in top 0.5% nationwide for excellence in science and mathematical aptitude.'
    }
  ]
};

// ============================================================================
// TEMPLATE 1: FreshStart (Free)
// Simple, clean, single-column design for freshers.
// Sections: Contact Details, Career Objective, Education, Skills, Projects, Certifications, Achievements.
// ============================================================================
export const FreshStartResume: React.FC<{ data: ResumeFormData; isMiniature?: boolean }> = ({
  data,
  isMiniature = false
}) => {
  return (
    <div
      className={`bg-white text-slate-800 font-sans leading-relaxed selection:bg-emerald-100 ${
        isMiniature ? 'text-[9px] p-4 scale-[0.98]' : 'text-xs sm:text-sm p-6 sm:p-10 shadow-sm border border-slate-200'
      }`}
      style={{ minHeight: isMiniature ? 'auto' : '1050px', maxWidth: '850px', margin: '0 auto' }}
    >
      {/* 1. Header / Contact Details */}
      <header className="border-b-2 border-emerald-600 pb-3 sm:pb-4 mb-4 text-center">
        <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900 uppercase">
          {data.fullName || 'Candidate Name'}
        </h1>
        <p className="text-emerald-700 font-semibold text-xs sm:text-sm mt-0.5">
          {data.title || 'Entry-Level Professional'}
        </p>

        <div className="flex flex-wrap items-center justify-center gap-x-4 gap-y-1 text-slate-600 text-[11px] sm:text-xs mt-2">
          {data.email && <span>{data.email}</span>}
          {data.phone && <span>&bull; {data.phone}</span>}
          {data.location && <span>&bull; {data.location}</span>}
          {data.linkedin && <span>&bull; {data.linkedin}</span>}
          {data.github && <span>&bull; {data.github}</span>}
        </div>
      </header>

      {/* 2. Career Objective */}
      {data.summary && (
        <section className="mb-4">
          <h2 className="text-xs sm:text-sm font-bold uppercase tracking-wider text-emerald-800 border-b border-emerald-100 pb-1 mb-1.5 flex items-center gap-1.5">
            Career Objective
          </h2>
          <p className="text-slate-700 text-justify text-xs sm:text-[13px] leading-normal">
            {data.summary}
          </p>
        </section>
      )}

      {/* 3. Education */}
      {data.education && data.education.length > 0 && (
        <section className="mb-4">
          <h2 className="text-xs sm:text-sm font-bold uppercase tracking-wider text-emerald-800 border-b border-emerald-100 pb-1 mb-2">
            Education
          </h2>
          <div className="space-y-2">
            {data.education.map(edu => (
              <div key={edu.id} className="flex flex-col sm:flex-row sm:items-baseline justify-between text-xs sm:text-[13px]">
                <div>
                  <span className="font-bold text-slate-900">{edu.degree}</span>
                  {edu.field && <span className="text-slate-700"> in {edu.field}</span>}
                  <div className="text-slate-600 italic text-[11px] sm:text-xs">{edu.institution}</div>
                </div>
                <div className="text-right sm:text-right shrink-0 mt-0.5 sm:mt-0">
                  <span className="font-medium text-slate-600 text-[11px] sm:text-xs">
                    {edu.startYear} – {edu.endYear}
                  </span>
                  {edu.score && (
                    <div className="text-emerald-700 font-semibold text-[11px]">{edu.score}</div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 4. Skills */}
      {(data.technicalSkills.length > 0 || data.programmingLanguages.length > 0 || data.softSkills.length > 0) && (
        <section className="mb-4">
          <h2 className="text-xs sm:text-sm font-bold uppercase tracking-wider text-emerald-800 border-b border-emerald-100 pb-1 mb-2">
            Key Skills
          </h2>
          <div className="space-y-1.5 text-xs sm:text-[13px]">
            {data.programmingLanguages.length > 0 && (
              <div>
                <span className="font-bold text-slate-800">Languages: </span>
                <span className="text-slate-700">{data.programmingLanguages.join(', ')}</span>
              </div>
            )}
            {data.technicalSkills.length > 0 && (
              <div>
                <span className="font-bold text-slate-800">Technical Skills: </span>
                <span className="text-slate-700">{data.technicalSkills.join(', ')}</span>
              </div>
            )}
            {data.softSkills.length > 0 && (
              <div>
                <span className="font-bold text-slate-800">Soft Skills: </span>
                <span className="text-slate-700">{data.softSkills.join(', ')}</span>
              </div>
            )}
          </div>
        </section>
      )}

      {/* 5. Projects */}
      {data.projects && data.projects.length > 0 && (
        <section className="mb-4">
          <h2 className="text-xs sm:text-sm font-bold uppercase tracking-wider text-emerald-800 border-b border-emerald-100 pb-1 mb-2">
            Academic & Personal Projects
          </h2>
          <div className="space-y-2.5">
            {data.projects.map(prj => (
              <div key={prj.id}>
                <div className="flex flex-col sm:flex-row sm:items-center justify-between text-xs sm:text-[13px]">
                  <span className="font-bold text-slate-900">{prj.title}</span>
                  {prj.techStack && (
                    <span className="text-emerald-700 font-mono text-[11px]">[{prj.techStack}]</span>
                  )}
                </div>
                {prj.link && (
                  <p className="text-[11px] text-slate-500 font-mono">{prj.link}</p>
                )}
                <ul className="list-disc list-outside ml-4 mt-1 space-y-0.5 text-slate-700 text-xs sm:text-[13px]">
                  {prj.bullets.map((b, idx) => (
                    <li key={idx}>{b}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 6. Certifications */}
      {data.certifications && data.certifications.length > 0 && (
        <section className="mb-4">
          <h2 className="text-xs sm:text-sm font-bold uppercase tracking-wider text-emerald-800 border-b border-emerald-100 pb-1 mb-2">
            Certifications & Training
          </h2>
          <div className="space-y-1.5">
            {data.certifications.map(cert => (
              <div key={cert.id} className="flex items-center justify-between text-xs sm:text-[13px]">
                <div>
                  <span className="font-bold text-slate-900">{cert.name}</span>
                  <span className="text-slate-600"> — {cert.issuer}</span>
                </div>
                <span className="text-slate-500 text-[11px]">{cert.year}</span>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 7. Achievements */}
      {data.achievements && data.achievements.length > 0 && (
        <section className="mb-2">
          <h2 className="text-xs sm:text-sm font-bold uppercase tracking-wider text-emerald-800 border-b border-emerald-100 pb-1 mb-2">
            Achievements & Extracurriculars
          </h2>
          <div className="space-y-1.5 text-xs sm:text-[13px]">
            {data.achievements.map(ach => (
              <div key={ach.id}>
                <span className="font-bold text-slate-900">{ach.title}: </span>
                <span className="text-slate-700">{ach.description}</span>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
};

// ============================================================================
// TEMPLATE 2: TechBasic (Free)
// ATS-friendly design for IT students and entry-level developers.
// Sections: Contact Details, Education, Technical Skills, Programming Languages, Projects, Internships, Certifications and Achievements.
// ============================================================================
export const TechBasicResume: React.FC<{ data: ResumeFormData; isMiniature?: boolean }> = ({
  data,
  isMiniature = false
}) => {
  return (
    <div
      className={`bg-white text-slate-900 font-sans leading-relaxed ${
        isMiniature ? 'text-[9px] p-4 scale-[0.98]' : 'text-xs sm:text-sm p-6 sm:p-10 shadow-sm border border-slate-200'
      }`}
      style={{ minHeight: isMiniature ? 'auto' : '1050px', maxWidth: '850px', margin: '0 auto' }}
    >
      {/* 1. Contact Details (High Contrast Centered Header) */}
      <header className="border-b-2 border-slate-900 pb-3 mb-3.5 text-center">
        <h1 className="text-xl sm:text-2xl font-extrabold uppercase tracking-tight text-slate-950 font-mono">
          {data.fullName || 'Candidate Name'}
        </h1>
        <p className="text-sky-700 font-bold font-mono text-xs sm:text-sm mt-0.5">
          {data.title || 'Junior Software Developer'}
        </p>
        <div className="flex flex-wrap items-center justify-center gap-x-3 gap-y-1 text-slate-700 font-mono text-[11px] mt-1.5">
          {data.email && <span>{data.email}</span>}
          {data.phone && <span>| {data.phone}</span>}
          {data.location && <span>| {data.location}</span>}
          {data.github && <span>| {data.github}</span>}
          {data.linkedin && <span>| {data.linkedin}</span>}
        </div>
      </header>

      {/* 2. Education */}
      {data.education && data.education.length > 0 && (
        <section className="mb-3.5">
          <h2 className="text-xs sm:text-sm font-bold uppercase tracking-wide text-slate-950 bg-slate-100 px-2 py-0.5 border-l-4 border-sky-600 mb-2">
            Education
          </h2>
          <div className="space-y-2">
            {data.education.map(edu => (
              <div key={edu.id} className="flex justify-between items-baseline text-xs sm:text-[13px]">
                <div>
                  <span className="font-bold text-slate-950">{edu.institution}</span>
                  <div className="text-slate-700">{edu.degree} in {edu.field}</div>
                </div>
                <div className="text-right shrink-0">
                  <span className="font-mono text-slate-600 text-[11px]">{edu.startYear} – {edu.endYear}</span>
                  {edu.score && <div className="text-sky-700 font-semibold text-[11px]">{edu.score}</div>}
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 3. Technical Skills & 4. Programming Languages */}
      <section className="mb-3.5">
        <h2 className="text-xs sm:text-sm font-bold uppercase tracking-wide text-slate-950 bg-slate-100 px-2 py-0.5 border-l-4 border-sky-600 mb-2">
          Technical Skills & Tooling
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-1.5 text-xs sm:text-[13px]">
          <div>
            <span className="font-bold text-slate-900 block sm:inline">Programming Languages: </span>
            <span className="text-slate-700 font-mono text-[12px]">{data.programmingLanguages.join(', ')}</span>
          </div>
          <div>
            <span className="font-bold text-slate-900 block sm:inline">Technologies & Frameworks: </span>
            <span className="text-slate-700">{data.technicalSkills.join(', ')}</span>
          </div>
        </div>
      </section>

      {/* 5. Projects */}
      {data.projects && data.projects.length > 0 && (
        <section className="mb-3.5">
          <h2 className="text-xs sm:text-sm font-bold uppercase tracking-wide text-slate-950 bg-slate-100 px-2 py-0.5 border-l-4 border-sky-600 mb-2">
            Technical Projects
          </h2>
          <div className="space-y-2.5">
            {data.projects.map(prj => (
              <div key={prj.id}>
                <div className="flex justify-between items-baseline text-xs sm:text-[13px]">
                  <span className="font-bold text-slate-950">{prj.title}</span>
                  <span className="text-sky-700 font-mono text-[11px] font-semibold">{prj.techStack}</span>
                </div>
                <ul className="list-disc list-outside ml-4 mt-1 space-y-0.5 text-slate-700 text-xs sm:text-[13px]">
                  {prj.bullets.map((b, idx) => (
                    <li key={idx}>{b}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 6. Internships */}
      {(data.internships.length > 0 || data.experience.length > 0) && (
        <section className="mb-3.5">
          <h2 className="text-xs sm:text-sm font-bold uppercase tracking-wide text-slate-950 bg-slate-100 px-2 py-0.5 border-l-4 border-sky-600 mb-2">
            Internships & Practical Experience
          </h2>
          <div className="space-y-2.5">
            {(data.internships.length > 0 ? data.internships : data.experience.slice(0, 1)).map(item => (
              <div key={item.id}>
                <div className="flex justify-between items-baseline text-xs sm:text-[13px]">
                  <div>
                    <span className="font-bold text-slate-950">{item.role}</span>
                    <span className="text-slate-600"> — {item.company}</span>
                  </div>
                  <span className="text-slate-500 font-mono text-[11px]">
                    {item.startDate} – {item.endDate}
                  </span>
                </div>
                <ul className="list-disc list-outside ml-4 mt-1 space-y-0.5 text-slate-700 text-xs sm:text-[13px]">
                  {item.bullets.map((b, idx) => (
                    <li key={idx}>{b}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 7. Certifications */}
      {data.certifications && data.certifications.length > 0 && (
        <section className="mb-3.5">
          <h2 className="text-xs sm:text-sm font-bold uppercase tracking-wide text-slate-950 bg-slate-100 px-2 py-0.5 border-l-4 border-sky-600 mb-1.5">
            Certifications
          </h2>
          <div className="space-y-1 text-xs sm:text-[13px]">
            {data.certifications.map(cert => (
              <div key={cert.id} className="flex justify-between items-baseline">
                <span className="text-slate-800 font-medium">{cert.name} ({cert.issuer})</span>
                <span className="font-mono text-slate-500 text-[11px]">{cert.year}</span>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 8. Achievements */}
      {data.achievements && data.achievements.length > 0 && (
        <section className="mb-2">
          <h2 className="text-xs sm:text-sm font-bold uppercase tracking-wide text-slate-950 bg-slate-100 px-2 py-0.5 border-l-4 border-sky-600 mb-1.5">
            Honors & Achievements
          </h2>
          <div className="space-y-1 text-xs sm:text-[13px]">
            {data.achievements.map(ach => (
              <div key={ach.id} className="text-slate-700">
                <strong className="text-slate-900">{ach.title}:</strong> {ach.description}
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
};

// ============================================================================
// TEMPLATE 3: CareerEdge (Premium)
// Modern professional design with clean typography and subtle colour accents.
// Sections: Professional Summary, Skills, Work Experience, Education, Projects and Certifications.
// ============================================================================
export const CareerEdgeResume: React.FC<{ data: ResumeFormData; isMiniature?: boolean }> = ({
  data,
  isMiniature = false
}) => {
  return (
    <div
      className={`bg-white text-slate-800 font-sans leading-relaxed ${
        isMiniature ? 'text-[9px] p-4 scale-[0.98]' : 'text-xs sm:text-sm p-6 sm:p-10 shadow-sm border border-slate-200'
      }`}
      style={{ minHeight: isMiniature ? 'auto' : '1050px', maxWidth: '850px', margin: '0 auto' }}
    >
      {/* Header with Royal Purple Accent Bar */}
      <header className="border-b pb-4 mb-4 border-slate-200">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h1 className="text-xl sm:text-3xl font-extrabold text-[#111827] tracking-tight">
              {data.fullName || 'Candidate Name'}
            </h1>
            <p className="text-[#6D5DFB] font-bold text-xs sm:text-sm uppercase tracking-wider mt-0.5">
              {data.title || 'Professional Title'}
            </p>
          </div>
          <div className="text-left sm:text-right text-[11px] sm:text-xs text-slate-600 space-y-0.5">
            {data.email && <div>{data.email}</div>}
            {data.phone && <div>{data.phone} &bull; {data.location}</div>}
            {data.linkedin && <div className="text-[#6D5DFB]">{data.linkedin}</div>}
          </div>
        </div>
      </header>

      {/* 1. Professional Summary */}
      {data.summary && (
        <section className="mb-4">
          <h2 className="text-xs sm:text-sm font-bold uppercase tracking-wider text-[#6D5DFB] border-b border-[#6D5DFB]/20 pb-1 mb-2">
            Professional Summary
          </h2>
          <p className="text-slate-700 text-justify text-xs sm:text-[13px] leading-relaxed">
            {data.summary}
          </p>
        </section>
      )}

      {/* 2. Skills Grid */}
      <section className="mb-4">
        <h2 className="text-xs sm:text-sm font-bold uppercase tracking-wider text-[#6D5DFB] border-b border-[#6D5DFB]/20 pb-1 mb-2">
          Core Competencies & Skills
        </h2>
        <div className="flex flex-wrap gap-1.5">
          {[...data.technicalSkills, ...data.programmingLanguages, ...data.softSkills].map((s, idx) => (
            <span
              key={idx}
              className="px-2 py-0.5 rounded bg-[#F1EEFF] text-[#6D5DFB] text-[11px] sm:text-xs font-semibold border border-[#6D5DFB]/20"
            >
              {s}
            </span>
          ))}
        </div>
      </section>

      {/* 3. Work Experience */}
      {data.experience && data.experience.length > 0 && (
        <section className="mb-4">
          <h2 className="text-xs sm:text-sm font-bold uppercase tracking-wider text-[#6D5DFB] border-b border-[#6D5DFB]/20 pb-1 mb-2.5">
            Work Experience
          </h2>
          <div className="space-y-3">
            {data.experience.map(exp => (
              <div key={exp.id}>
                <div className="flex flex-col sm:flex-row sm:items-center justify-between text-xs sm:text-[13px]">
                  <div>
                    <span className="font-bold text-[#111827]">{exp.role}</span>
                    <span className="text-[#6D5DFB] font-semibold"> &bull; {exp.company}</span>
                  </div>
                  <span className="text-slate-500 font-mono text-[11px]">
                    {exp.startDate} – {exp.endDate} | {exp.location}
                  </span>
                </div>
                <ul className="list-disc list-outside ml-4 mt-1 space-y-1 text-slate-700 text-xs sm:text-[13px]">
                  {exp.bullets.map((b, idx) => (
                    <li key={idx}>{b}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 4. Education */}
      {data.education && data.education.length > 0 && (
        <section className="mb-4">
          <h2 className="text-xs sm:text-sm font-bold uppercase tracking-wider text-[#6D5DFB] border-b border-[#6D5DFB]/20 pb-1 mb-2">
            Education
          </h2>
          <div className="space-y-2">
            {data.education.map(edu => (
              <div key={edu.id} className="flex justify-between items-baseline text-xs sm:text-[13px]">
                <div>
                  <span className="font-bold text-[#111827]">{edu.degree} in {edu.field}</span>
                  <div className="text-slate-600 text-[11px]">{edu.institution}</div>
                </div>
                <span className="font-mono text-slate-500 text-[11px]">{edu.startYear} – {edu.endYear}</span>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 5. Projects */}
      {data.projects && data.projects.length > 0 && (
        <section className="mb-4">
          <h2 className="text-xs sm:text-sm font-bold uppercase tracking-wider text-[#6D5DFB] border-b border-[#6D5DFB]/20 pb-1 mb-2">
            Key Projects
          </h2>
          <div className="space-y-2.5">
            {data.projects.map(prj => (
              <div key={prj.id}>
                <div className="flex justify-between items-baseline text-xs sm:text-[13px]">
                  <span className="font-bold text-[#111827]">{prj.title}</span>
                  <span className="text-slate-500 font-mono text-[11px]">{prj.techStack}</span>
                </div>
                <ul className="list-disc list-outside ml-4 mt-0.5 space-y-0.5 text-slate-700 text-xs sm:text-[13px]">
                  {prj.bullets.map((b, idx) => (
                    <li key={idx}>{b}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 6. Certifications */}
      {data.certifications && data.certifications.length > 0 && (
        <section className="mb-2">
          <h2 className="text-xs sm:text-sm font-bold uppercase tracking-wider text-[#6D5DFB] border-b border-[#6D5DFB]/20 pb-1 mb-1.5">
            Certifications
          </h2>
          <div className="space-y-1 text-xs sm:text-[13px]">
            {data.certifications.map(cert => (
              <div key={cert.id} className="flex justify-between items-baseline">
                <span className="font-semibold text-slate-800">{cert.name} — <span className="text-slate-600 font-normal">{cert.issuer}</span></span>
                <span className="text-slate-500 font-mono text-[11px]">{cert.year}</span>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
};

// ============================================================================
// TEMPLATE 4: DevPro (Premium)
// Software developer-focused design.
// Sections: Technical Skills, Programming Languages, Projects, Experience, Education, Certifications and GitHub/Portfolio links.
// ============================================================================
export const DevProResume: React.FC<{ data: ResumeFormData; isMiniature?: boolean }> = ({
  data,
  isMiniature = false
}) => {
  return (
    <div
      className={`bg-white text-slate-900 font-sans leading-relaxed ${
        isMiniature ? 'text-[9px] p-4 scale-[0.98]' : 'text-xs sm:text-sm p-6 sm:p-10 shadow-sm border border-slate-200'
      }`}
      style={{ minHeight: isMiniature ? 'auto' : '1050px', maxWidth: '850px', margin: '0 auto' }}
    >
      {/* Dark Tech Header */}
      <header className="bg-[#111827] text-white p-4 sm:p-6 rounded-xl mb-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h1 className="text-xl sm:text-2xl font-black tracking-tight font-mono text-white">
              {data.fullName || 'Developer Name'}
            </h1>
            <p className="text-violet-400 font-bold font-mono text-xs sm:text-sm mt-0.5">
              &gt; {data.title || 'Senior Software Developer'}
            </p>
          </div>
          <div className="text-[11px] sm:text-xs font-mono space-y-1 text-slate-300">
            {data.email && <div>{data.email}</div>}
            {data.phone && <div>{data.phone} &bull; {data.location}</div>}
            <div className="flex gap-3 text-violet-300 font-semibold">
              {data.github && <span>github: {data.github}</span>}
              {data.portfolio && <span>web: {data.portfolio}</span>}
            </div>
          </div>
        </div>
      </header>

      {/* 1. Technical Skills & 2. Programming Languages */}
      <section className="mb-4 bg-slate-50 p-3.5 rounded-xl border border-slate-200/80">
        <h2 className="text-xs sm:text-sm font-bold uppercase tracking-wider text-violet-900 font-mono mb-2 flex items-center gap-1.5">
          <Code className="w-4 h-4 text-violet-600" />
          Technical Stack & Languages
        </h2>
        <div className="space-y-1.5 text-xs sm:text-[13px]">
          <div>
            <span className="font-bold font-mono text-slate-900">Languages: </span>
            <span className="text-slate-700 font-mono text-[12px]">{data.programmingLanguages.join(' | ')}</span>
          </div>
          <div>
            <span className="font-bold font-mono text-slate-900">Frameworks & Tools: </span>
            <span className="text-slate-700">{data.technicalSkills.join(' &bull; ')}</span>
          </div>
        </div>
      </section>

      {/* 3. Projects (Dev-Centric) */}
      {data.projects && data.projects.length > 0 && (
        <section className="mb-4">
          <h2 className="text-xs sm:text-sm font-bold uppercase tracking-wider text-slate-900 border-b-2 border-violet-500 pb-1 mb-2.5 font-mono">
            Systems & Open Source Projects
          </h2>
          <div className="space-y-3">
            {data.projects.map(prj => (
              <div key={prj.id}>
                <div className="flex flex-col sm:flex-row sm:items-baseline justify-between text-xs sm:text-[13px]">
                  <span className="font-bold text-[#111827] font-mono">{prj.title}</span>
                  <span className="text-violet-700 font-mono text-[11px] font-semibold">{prj.techStack}</span>
                </div>
                {prj.link && (
                  <p className="text-[11px] text-slate-500 font-mono">{prj.link}</p>
                )}
                <ul className="list-disc list-outside ml-4 mt-1 space-y-1 text-slate-700 text-xs sm:text-[13px]">
                  {prj.bullets.map((b, idx) => (
                    <li key={idx}>{b}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 4. Experience */}
      {data.experience && data.experience.length > 0 && (
        <section className="mb-4">
          <h2 className="text-xs sm:text-sm font-bold uppercase tracking-wider text-slate-900 border-b-2 border-violet-500 pb-1 mb-2.5 font-mono">
            Engineering Experience
          </h2>
          <div className="space-y-3">
            {data.experience.map(exp => (
              <div key={exp.id}>
                <div className="flex justify-between items-baseline text-xs sm:text-[13px]">
                  <span className="font-bold text-[#111827]">{exp.role} — <span className="text-violet-700">{exp.company}</span></span>
                  <span className="font-mono text-slate-500 text-[11px]">{exp.startDate} – {exp.endDate}</span>
                </div>
                <ul className="list-disc list-outside ml-4 mt-1 space-y-1 text-slate-700 text-xs sm:text-[13px]">
                  {exp.bullets.map((b, idx) => (
                    <li key={idx}>{b}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 5. Education & 6. Certifications */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {data.education && data.education.length > 0 && (
          <section>
            <h2 className="text-xs sm:text-sm font-bold uppercase tracking-wider text-slate-900 border-b border-slate-200 pb-1 mb-2 font-mono">
              Education
            </h2>
            <div className="space-y-1 text-xs sm:text-[13px]">
              {data.education.map(edu => (
                <div key={edu.id}>
                  <div className="font-bold text-slate-900">{edu.degree}</div>
                  <div className="text-slate-600 text-[11px]">{edu.institution} ({edu.startYear} – {edu.endYear})</div>
                </div>
              ))}
            </div>
          </section>
        )}

        {data.certifications && data.certifications.length > 0 && (
          <section>
            <h2 className="text-xs sm:text-sm font-bold uppercase tracking-wider text-slate-900 border-b border-slate-200 pb-1 mb-2 font-mono">
              Certifications
            </h2>
            <div className="space-y-1 text-xs sm:text-[13px]">
              {data.certifications.map(cert => (
                <div key={cert.id} className="text-slate-800">
                  <div className="font-semibold">{cert.name}</div>
                  <div className="text-slate-500 text-[11px] font-mono">{cert.issuer} &bull; {cert.year}</div>
                </div>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
};

// ============================================================================
// TEMPLATE 5: EliteExecutive (Premium)
// Elegant professional design for experienced candidates.
// Sections: Professional Summary, Work Experience, Key Achievements, Skills, Education and Certifications.
// ============================================================================
export const EliteExecutiveResume: React.FC<{ data: ResumeFormData; isMiniature?: boolean }> = ({
  data,
  isMiniature = false
}) => {
  return (
    <div
      className={`bg-white text-slate-900 font-serif leading-relaxed ${
        isMiniature ? 'text-[9px] p-4 scale-[0.98]' : 'text-xs sm:text-sm p-6 sm:p-10 shadow-sm border border-slate-200'
      }`}
      style={{ minHeight: isMiniature ? 'auto' : '1050px', maxWidth: '850px', margin: '0 auto' }}
    >
      {/* Executive Clean Header */}
      <header className="border-b-2 border-slate-800 pb-4 mb-4 text-center">
        <h1 className="text-2xl sm:text-3xl font-extrabold uppercase tracking-widest text-[#111827]">
          {data.fullName || 'Executive Candidate'}
        </h1>
        <p className="text-slate-600 font-sans uppercase tracking-widest text-xs sm:text-sm mt-1 font-semibold">
          {data.title || 'Vice President of Engineering / Technology Executive'}
        </p>
        <div className="flex flex-wrap justify-center gap-x-4 gap-y-1 text-slate-600 font-sans text-[11px] sm:text-xs mt-2">
          {data.email && <span>{data.email}</span>}
          {data.phone && <span>&bull; {data.phone}</span>}
          {data.location && <span>&bull; {data.location}</span>}
          {data.linkedin && <span>&bull; {data.linkedin}</span>}
        </div>
      </header>

      {/* 1. Professional Summary */}
      {data.summary && (
        <section className="mb-4">
          <h2 className="text-xs sm:text-sm font-sans font-bold uppercase tracking-widest text-slate-900 border-b border-slate-200 pb-1 mb-2">
            Executive Profile
          </h2>
          <p className="text-slate-800 text-justify text-xs sm:text-[13px] leading-relaxed">
            {data.summary}
          </p>
        </section>
      )}

      {/* 2. Key Achievements Strip */}
      {data.achievements && data.achievements.length > 0 && (
        <section className="mb-4 bg-slate-50 p-3 rounded-lg border border-slate-200">
          <h2 className="text-xs sm:text-sm font-sans font-bold uppercase tracking-widest text-slate-900 mb-2">
            Key Career Milestones & Impact
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs sm:text-[13px] font-sans">
            {data.achievements.map(ach => (
              <div key={ach.id} className="flex items-start gap-2">
                <CheckCircle className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-slate-900">{ach.title}: </span>
                  <span className="text-slate-700">{ach.description}</span>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 3. Work Experience */}
      {data.experience && data.experience.length > 0 && (
        <section className="mb-4">
          <h2 className="text-xs sm:text-sm font-sans font-bold uppercase tracking-widest text-slate-900 border-b border-slate-200 pb-1 mb-2.5">
            Executive Leadership & Experience
          </h2>
          <div className="space-y-3.5">
            {data.experience.map(exp => (
              <div key={exp.id}>
                <div className="flex justify-between items-baseline font-sans text-xs sm:text-[13px]">
                  <span className="font-bold text-slate-950">{exp.role} &bull; <span className="font-medium text-slate-700">{exp.company}</span></span>
                  <span className="text-slate-500 font-mono text-[11px]">{exp.startDate} – {exp.endDate}</span>
                </div>
                <ul className="list-disc list-outside ml-4 mt-1 space-y-1 text-slate-800 text-xs sm:text-[13px]">
                  {exp.bullets.map((b, idx) => (
                    <li key={idx}>{b}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 4. Skills & Strategic Governance */}
      <section className="mb-4">
        <h2 className="text-xs sm:text-sm font-sans font-bold uppercase tracking-widest text-slate-900 border-b border-slate-200 pb-1 mb-2">
          Strategic & Technical Competencies
        </h2>
        <p className="font-sans text-xs sm:text-[13px] text-slate-700">
          {[...data.technicalSkills, ...data.softSkills].join(' &bull; ')}
        </p>
      </section>

      {/* 5. Education & 6. Certifications */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 font-sans">
        {data.education && data.education.length > 0 && (
          <section>
            <h2 className="text-xs sm:text-sm font-bold uppercase tracking-widest text-slate-900 border-b border-slate-200 pb-1 mb-2">
              Education
            </h2>
            <div className="space-y-1 text-xs sm:text-[13px]">
              {data.education.map(edu => (
                <div key={edu.id}>
                  <div className="font-bold text-slate-900">{edu.degree} in {edu.field}</div>
                  <div className="text-slate-600 text-[11px]">{edu.institution} ({edu.endYear})</div>
                </div>
              ))}
            </div>
          </section>
        )}

        {data.certifications && data.certifications.length > 0 && (
          <section>
            <h2 className="text-xs sm:text-sm font-bold uppercase tracking-widest text-slate-900 border-b border-slate-200 pb-1 mb-2">
              Credentials & Governance
            </h2>
            <div className="space-y-1 text-xs sm:text-[13px]">
              {data.certifications.map(cert => (
                <div key={cert.id} className="text-slate-800">
                  <span className="font-semibold">{cert.name}</span>
                  <span className="text-slate-500 text-[11px]"> ({cert.issuer})</span>
                </div>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
};

// 6. Custom Configurable Resume (Single or Two Column, custom accent, configurable sections)
export const CustomConfigurableResume: React.FC<{
  data: ResumeFormData;
  isMiniature?: boolean;
  accentColor?: string;
  layout?: 'single-column' | 'two-column';
  font?: 'sans' | 'serif' | 'mono';
  enabledSections?: {
    summary?: boolean;
    education?: boolean;
    skills?: boolean;
    projects?: boolean;
    experience?: boolean;
    certifications?: boolean;
    achievements?: boolean;
  };
}> = ({
  data,
  isMiniature = false,
  accentColor = '#6D5DFB',
  layout = 'single-column',
  font = 'sans',
  enabledSections = {
    summary: true,
    education: true,
    skills: true,
    projects: true,
    experience: true,
    certifications: true,
    achievements: true
  }
}) => {
  const fontClass = font === 'serif' ? 'font-serif' : font === 'mono' ? 'font-mono' : 'font-sans';
  const showSummary = enabledSections.summary !== false;
  const showEducation = enabledSections.education !== false;
  const showSkills = enabledSections.skills !== false;
  const showProjects = enabledSections.projects !== false;
  const showExperience = enabledSections.experience !== false;
  const showCertifications = enabledSections.certifications !== false;
  const showAchievements = enabledSections.achievements !== false;

  if (layout === 'two-column') {
    return (
      <div className={`w-full bg-white text-slate-800 ${fontClass} ${isMiniature ? 'p-3 text-[10px]' : 'p-6 sm:p-8 text-xs sm:text-sm'} leading-normal`}>
        {/* Header */}
        <div className="border-b-2 pb-3 mb-4" style={{ borderColor: accentColor }}>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900">{data.fullName || 'Candidate Name'}</h1>
          <p className="text-xs sm:text-sm font-semibold mt-0.5" style={{ color: accentColor }}>{data.title || 'Target Job Role'}</p>
          <div className="flex flex-wrap gap-x-3 gap-y-1 text-slate-500 text-[11px] mt-1.5">
            {data.email && <span>{data.email}</span>}
            {data.phone && <span>&bull; {data.phone}</span>}
            {data.location && <span>&bull; {data.location}</span>}
            {data.linkedin && <span>&bull; {data.linkedin}</span>}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          {/* Left Column (Main): Summary, Experience, Projects */}
          <div className="md:col-span-8 space-y-4">
            {showSummary && data.summary && (
              <section>
                <h2 className="text-xs sm:text-sm font-bold uppercase tracking-wider pb-1 mb-1.5 border-b border-slate-200" style={{ color: accentColor }}>
                  Professional Summary
                </h2>
                <p className="text-slate-700 text-xs sm:text-[13px] leading-relaxed">{data.summary}</p>
              </section>
            )}

            {showExperience && data.experience && data.experience.length > 0 && (
              <section>
                <h2 className="text-xs sm:text-sm font-bold uppercase tracking-wider pb-1 mb-2 border-b border-slate-200" style={{ color: accentColor }}>
                  Work Experience
                </h2>
                <div className="space-y-3">
                  {data.experience.map(exp => (
                    <div key={exp.id}>
                      <div className="flex justify-between items-baseline">
                        <span className="font-bold text-slate-900">{exp.role}</span>
                        <span className="text-slate-400 font-mono text-[11px]">{exp.startDate} – {exp.endDate}</span>
                      </div>
                      <p className="text-slate-600 font-medium text-[11px]">{exp.company} &bull; {exp.location}</p>
                      <ul className="list-disc list-outside ml-4 mt-1 space-y-1 text-slate-700 text-xs sm:text-[13px]">
                        {exp.bullets.map((b, i) => (
                          <li key={i}>{b}</li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {showProjects && data.projects && data.projects.length > 0 && (
              <section>
                <h2 className="text-xs sm:text-sm font-bold uppercase tracking-wider pb-1 mb-2 border-b border-slate-200" style={{ color: accentColor }}>
                  Key Projects
                </h2>
                <div className="space-y-2.5">
                  {data.projects.map(proj => (
                    <div key={proj.id}>
                      <div className="flex justify-between items-baseline font-semibold text-slate-900">
                        <span>{proj.title}</span>
                        <span className="text-[10px] font-mono text-slate-400">{proj.techStack}</span>
                      </div>
                      <p className="text-slate-600 text-xs sm:text-[13px] mt-0.5">{proj.bullets?.[0] || ''}</p>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {showAchievements && data.achievements && data.achievements.length > 0 && (
              <section>
                <h2 className="text-xs sm:text-sm font-bold uppercase tracking-wider pb-1 mb-1.5 border-b border-slate-200" style={{ color: accentColor }}>
                  Achievements & Honors
                </h2>
                <ul className="list-disc list-outside ml-4 space-y-1 text-slate-700 text-xs sm:text-[13px]">
                  {data.achievements.map(ach => (
                    <li key={ach.id}>
                      <span className="font-semibold text-slate-900">{ach.title}</span> – {ach.description}
                    </li>
                  ))}
                </ul>
              </section>
            )}
          </div>

          {/* Right Column (Sidebar): Skills, Education, Certifications */}
          <div className="md:col-span-4 space-y-4 border-l border-slate-100 pl-4">
            {showSkills && (
              <section>
                <h2 className="text-xs sm:text-sm font-bold uppercase tracking-wider pb-1 mb-2 border-b border-slate-200" style={{ color: accentColor }}>
                  Skills & Tools
                </h2>
                <div className="space-y-2">
                  <div>
                    <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">Technical</span>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {data.technicalSkills.map((s, i) => (
                        <span key={i} className="px-2 py-0.5 bg-slate-100 text-slate-800 rounded text-[11px] font-medium">
                          {s}
                        </span>
                      ))}
                    </div>
                  </div>
                  {data.programmingLanguages && data.programmingLanguages.length > 0 && (
                    <div>
                      <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">Languages</span>
                      <p className="text-slate-700 text-xs mt-0.5">{data.programmingLanguages.join(', ')}</p>
                    </div>
                  )}
                  {data.softSkills && data.softSkills.length > 0 && (
                    <div>
                      <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">Soft Skills</span>
                      <p className="text-slate-700 text-xs mt-0.5">{data.softSkills.join(', ')}</p>
                    </div>
                  )}
                </div>
              </section>
            )}

            {showEducation && data.education && data.education.length > 0 && (
              <section>
                <h2 className="text-xs sm:text-sm font-bold uppercase tracking-wider pb-1 mb-2 border-b border-slate-200" style={{ color: accentColor }}>
                  Education
                </h2>
                <div className="space-y-2">
                  {data.education.map(edu => (
                    <div key={edu.id} className="text-xs">
                      <div className="font-bold text-slate-900">{edu.degree}</div>
                      <div className="text-slate-600 text-[11px]">{edu.field}</div>
                      <div className="text-slate-400 font-mono text-[10px]">{edu.institution} ({edu.endYear})</div>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {showCertifications && data.certifications && data.certifications.length > 0 && (
              <section>
                <h2 className="text-xs sm:text-sm font-bold uppercase tracking-wider pb-1 mb-2 border-b border-slate-200" style={{ color: accentColor }}>
                  Certifications
                </h2>
                <div className="space-y-1.5 text-xs">
                  {data.certifications.map(cert => (
                    <div key={cert.id}>
                      <span className="font-semibold text-slate-800">{cert.name}</span>
                      <span className="text-slate-400 block text-[10px]">{cert.issuer} ({cert.year})</span>
                    </div>
                  ))}
                </div>
              </section>
            )}
          </div>
        </div>
      </div>
    );
  }

  // Single-Column Layout
  return (
    <div className={`w-full bg-white text-slate-800 ${fontClass} ${isMiniature ? 'p-3 text-[10px]' : 'p-6 sm:p-8 text-xs sm:text-sm'} leading-normal`}>
      {/* Top Header */}
      <div className="text-center border-b pb-3 mb-4" style={{ borderColor: accentColor }}>
        <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900">{data.fullName || 'Candidate Name'}</h1>
        <p className="text-xs sm:text-sm font-semibold mt-0.5" style={{ color: accentColor }}>{data.title || 'Target Job Role'}</p>
        <div className="flex flex-wrap justify-center gap-x-3 gap-y-1 text-slate-500 text-[11px] mt-1.5">
          {data.email && <span>{data.email}</span>}
          {data.phone && <span>&bull; {data.phone}</span>}
          {data.location && <span>&bull; {data.location}</span>}
          {data.linkedin && <span>&bull; {data.linkedin}</span>}
        </div>
      </div>

      <div className="space-y-4">
        {showSummary && data.summary && (
          <section>
            <h2 className="text-xs sm:text-sm font-bold uppercase tracking-wider pb-1 mb-1.5 border-b border-slate-200" style={{ color: accentColor }}>
              Professional Summary
            </h2>
            <p className="text-slate-700 text-xs sm:text-[13px] leading-relaxed">{data.summary}</p>
          </section>
        )}

        {showSkills && (
          <section>
            <h2 className="text-xs sm:text-sm font-bold uppercase tracking-wider pb-1 mb-2 border-b border-slate-200" style={{ color: accentColor }}>
              Skills & Expertise
            </h2>
            <div className="space-y-1.5 text-xs sm:text-[13px]">
              <div>
                <span className="font-bold text-slate-900">Technical Skills: </span>
                <span className="text-slate-700">{data.technicalSkills.join(', ')}</span>
              </div>
              {data.programmingLanguages && data.programmingLanguages.length > 0 && (
                <div>
                  <span className="font-bold text-slate-900">Languages: </span>
                  <span className="text-slate-700">{data.programmingLanguages.join(', ')}</span>
                </div>
              )}
              {data.softSkills && data.softSkills.length > 0 && (
                <div>
                  <span className="font-bold text-slate-900">Soft Skills: </span>
                  <span className="text-slate-700">{data.softSkills.join(', ')}</span>
                </div>
              )}
            </div>
          </section>
        )}

        {showExperience && data.experience && data.experience.length > 0 && (
          <section>
            <h2 className="text-xs sm:text-sm font-bold uppercase tracking-wider pb-1 mb-2 border-b border-slate-200" style={{ color: accentColor }}>
              Work Experience
            </h2>
            <div className="space-y-3">
              {data.experience.map(exp => (
                <div key={exp.id}>
                  <div className="flex justify-between items-baseline">
                    <span className="font-bold text-slate-900">{exp.role} &bull; <span className="font-medium text-slate-700">{exp.company}</span></span>
                    <span className="text-slate-400 font-mono text-[11px]">{exp.startDate} – {exp.endDate}</span>
                  </div>
                  <ul className="list-disc list-outside ml-4 mt-1 space-y-1 text-slate-700 text-xs sm:text-[13px]">
                    {exp.bullets.map((b, i) => (
                      <li key={i}>{b}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </section>
        )}

        {showProjects && data.projects && data.projects.length > 0 && (
          <section>
            <h2 className="text-xs sm:text-sm font-bold uppercase tracking-wider pb-1 mb-2 border-b border-slate-200" style={{ color: accentColor }}>
              Projects
            </h2>
            <div className="space-y-2.5">
              {data.projects.map(proj => (
                <div key={proj.id}>
                  <div className="flex justify-between items-baseline font-semibold text-slate-900">
                    <span>{proj.title}</span>
                    <span className="text-[10px] font-mono text-slate-400">{proj.techStack}</span>
                  </div>
                  <p className="text-slate-600 text-xs sm:text-[13px] mt-0.5">{proj.bullets?.[0] || ''}</p>
                </div>
              ))}
            </div>
          </section>
        )}

        {showEducation && data.education && data.education.length > 0 && (
          <section>
            <h2 className="text-xs sm:text-sm font-bold uppercase tracking-wider pb-1 mb-2 border-b border-slate-200" style={{ color: accentColor }}>
              Education
            </h2>
            <div className="space-y-1 text-xs sm:text-[13px]">
              {data.education.map(edu => (
                <div key={edu.id} className="flex justify-between items-baseline">
                  <div>
                    <span className="font-bold text-slate-900">{edu.degree} in {edu.field}</span>
                    <span className="text-slate-600 text-[11px]"> &bull; {edu.institution}</span>
                  </div>
                  <span className="text-slate-400 font-mono text-[11px]">{edu.endYear}</span>
                </div>
              ))}
            </div>
          </section>
        )}

        {showCertifications && data.certifications && data.certifications.length > 0 && (
          <section>
            <h2 className="text-xs sm:text-sm font-bold uppercase tracking-wider pb-1 mb-2 border-b border-slate-200" style={{ color: accentColor }}>
              Certifications & Achievements
            </h2>
            <div className="space-y-1 text-xs sm:text-[13px]">
              {data.certifications.map(cert => (
                <div key={cert.id} className="text-slate-800">
                  <span className="font-semibold">{cert.name}</span>
                  <span className="text-slate-500 text-[11px]"> ({cert.issuer})</span>
                </div>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
};

// Helper renderer supporting built-in and custom templates
export const renderResumeTemplate = (
  templateKey: string,
  data: ResumeFormData,
  isMiniature = false,
  customOptions?: {
    accentColor?: string;
    layout?: 'single-column' | 'two-column';
    font?: 'sans' | 'serif' | 'mono';
    enabledSections?: any;
  }
) => {
  switch (templateKey) {
    case 'fresh-start':
      return <FreshStartResume data={data} isMiniature={isMiniature} />;
    case 'tech-basic':
      return <TechBasicResume data={data} isMiniature={isMiniature} />;
    case 'career-edge':
      return <CareerEdgeResume data={data} isMiniature={isMiniature} />;
    case 'dev-pro':
      return <DevProResume data={data} isMiniature={isMiniature} />;
    case 'elite-executive':
      return <EliteExecutiveResume data={data} isMiniature={isMiniature} />;
    default:
      return (
        <CustomConfigurableResume
          data={data}
          isMiniature={isMiniature}
          accentColor={customOptions?.accentColor || '#6D5DFB'}
          layout={customOptions?.layout || 'single-column'}
          font={customOptions?.font || 'sans'}
          enabledSections={customOptions?.enabledSections}
        />
      );
  }
};

