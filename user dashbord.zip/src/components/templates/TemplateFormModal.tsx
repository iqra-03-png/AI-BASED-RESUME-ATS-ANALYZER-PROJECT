import React, { useState, useEffect } from 'react';
import {
  X,
  Sparkles,
  Layers,
  Palette,
  Check,
  Eye,
  AlertCircle,
  Lock,
  Tag,
  Briefcase,
  Columns,
  Type
} from 'lucide-react';
import { ResumeTemplate, ResumeTemplateSections, TemplateLayout, TemplateStatus } from '../../types';
import { renderResumeTemplate, DEFAULT_SAMPLE_RESUME, CustomConfigurableResume } from './ResumeTemplateRenderers';
import { useToast } from '../../context/ToastContext';

interface TemplateFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (templateData: Partial<ResumeTemplate>, targetStatus: TemplateStatus) => void;
  initialTemplate?: ResumeTemplate | null;
}

const PRESET_COLORS = [
  { name: 'Royal Violet', hex: '#6D5DFB' },
  { name: 'Emerald Green', hex: '#16A34A' },
  { name: 'Ocean Blue', hex: '#0284C7' },
  { name: 'Purple Accent', hex: '#8B5CF6' },
  { name: 'Classic Navy', hex: '#111827' },
  { name: 'Rose Coral', hex: '#E11D48' },
  { name: 'Teal Pro', hex: '#0D9488' },
  { name: 'Amber Gold', hex: '#D97706' }
];

export const TemplateFormModal: React.FC<TemplateFormModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialTemplate
}) => {
  const toast = useToast();

  const isEditing = Boolean(initialTemplate);

  // Form State
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('Software Engineering');
  const [intendedUser, setIntendedUser] = useState('');
  const [intendedRolesInput, setIntendedRolesInput] = useState('');
  const [tier, setTier] = useState<'free' | 'premium'>('free');
  const [priceInr, setPriceInr] = useState<number>(299);
  const [layout, setLayout] = useState<TemplateLayout>('single-column');
  const [accentColor, setAccentColor] = useState<string>('#6D5DFB');
  const [themeFont, setThemeFont] = useState<'sans' | 'serif' | 'mono'>('sans');

  // Resume Sections Config
  const [sections, setSections] = useState<ResumeTemplateSections>({
    summary: true,
    education: true,
    skills: true,
    projects: true,
    experience: true,
    certifications: true,
    achievements: true
  });

  // UI state
  const [previewTab, setPreviewTab] = useState<'form' | 'preview'>('form');
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (initialTemplate) {
      setTitle(initialTemplate.title || '');
      setDescription(initialTemplate.description || '');
      setCategory(initialTemplate.category || 'Software Engineering');
      setIntendedUser(initialTemplate.intendedUser || '');
      setIntendedRolesInput(initialTemplate.intendedRoles?.join(', ') || initialTemplate.previewSnippet?.targetRole || '');
      setTier(initialTemplate.tier || 'free');
      setPriceInr(initialTemplate.priceInr || 299);
      setLayout(initialTemplate.layout || 'single-column');
      setAccentColor(initialTemplate.accentColor || '#6D5DFB');
      setThemeFont(initialTemplate.themeFont || 'sans');
      if (initialTemplate.enabledSections) {
        setSections({ ...initialTemplate.enabledSections });
      }
    } else {
      // Default clean template creation
      setTitle('');
      setDescription('');
      setCategory('Software Engineering');
      setIntendedUser('Developers & CS Freshers');
      setIntendedRolesInput('Software Engineer, Full Stack Developer, Backend Specialist');
      setTier('free');
      setPriceInr(299);
      setLayout('single-column');
      setAccentColor('#6D5DFB');
      setThemeFont('sans');
      setSections({
        summary: true,
        education: true,
        skills: true,
        projects: true,
        experience: true,
        certifications: true,
        achievements: true
      });
    }
    setErrors({});
    setPreviewTab('form');
  }, [initialTemplate, isOpen]);

  if (!isOpen) return null;

  const toggleSection = (key: keyof ResumeTemplateSections) => {
    setSections(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!title.trim()) errs.title = 'Template name is required.';
    if (!description.trim()) errs.description = 'Description is required for administrator records.';
    if (!intendedUser.trim()) errs.intendedUser = 'Intended audience/user group is required.';
    if (tier === 'premium' && (!priceInr || priceInr <= 0)) {
      errs.priceInr = 'Premium templates require a valid price in INR (> 0).';
    }

    const hasAtLeastOneSection = Object.values(sections).some(v => v);
    if (!hasAtLeastOneSection) {
      errs.sections = 'At least one resume section must be enabled.';
    }

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (targetStatus: TemplateStatus) => {
    if (!validate()) {
      toast.error('Validation Error', 'Please check the highlighted required fields.');
      return;
    }

    const parsedRoles = intendedRolesInput
      .split(',')
      .map(r => r.trim())
      .filter(Boolean);

    const templateData: Partial<ResumeTemplate> = {
      title: title.trim(),
      description: description.trim(),
      category: category.trim(),
      intendedUser: intendedUser.trim(),
      intendedRoles: parsedRoles.length > 0 ? parsedRoles : ['Software Engineer'],
      tier,
      priceInr: tier === 'free' ? 0 : Number(priceInr),
      layout,
      accentColor,
      themeFont,
      enabledSections: sections,
      format: 'PDF',
      templateKey: initialTemplate?.templateKey && ['fresh-start', 'tech-basic', 'career-edge', 'dev-pro', 'elite-executive'].includes(initialTemplate.templateKey)
        ? initialTemplate.templateKey
        : (layout === 'two-column' ? 'custom-two' : 'custom-single'),
      features: [
        layout === 'two-column' ? 'Two-Column Executive Layout' : 'Clean ATS Single-Column Layout',
        tier === 'free' ? '100% Free Forever' : `Premium Pro (${priceInr} INR)`,
        `${Object.values(sections).filter(Boolean).length} Modular Sections`,
        '100% ATS Parser Compliant'
      ],
      previewSnippet: {
        name: DEFAULT_SAMPLE_RESUME.fullName,
        targetRole: parsedRoles[0] || 'Target Job Role',
        summary: DEFAULT_SAMPLE_RESUME.summary,
        skillsSample: DEFAULT_SAMPLE_RESUME.technicalSkills.slice(0, 5),
        experienceSample: DEFAULT_SAMPLE_RESUME.experience[0]?.bullets[0] || ''
      }
    };

    onSave(templateData, targetStatus);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white w-full max-w-5xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh] animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="px-6 py-4 bg-gradient-to-r from-[#111827] via-[#1E1B4B] to-[#111827] text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#6D5DFB] flex items-center justify-center text-white">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-extrabold tracking-tight">
                {isEditing ? `Edit Template: ${initialTemplate?.title}` : 'Create New Resume Template'}
              </h2>
              <p className="text-xs text-slate-300">
                ResuNova Admin Control Center &bull; Free & Premium Customizer
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Mobile Tab Switcher */}
            <div className="lg:hidden flex bg-white/10 rounded-lg p-0.5 text-xs">
              <button
                type="button"
                onClick={() => setPreviewTab('form')}
                className={`px-2.5 py-1 rounded-md font-semibold ${
                  previewTab === 'form' ? 'bg-white text-slate-900' : 'text-slate-300'
                }`}
              >
                Settings
              </button>
              <button
                type="button"
                onClick={() => setPreviewTab('preview')}
                className={`px-2.5 py-1 rounded-md font-semibold ${
                  previewTab === 'preview' ? 'bg-white text-slate-900' : 'text-slate-300'
                }`}
              >
                Live Preview
              </button>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/10 transition-colors"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body: Split Form & Live Preview */}
        <div className="flex-1 overflow-y-auto grid grid-cols-1 lg:grid-cols-12 divide-y lg:divide-y-0 lg:divide-x divide-slate-200">
          {/* Left: Configuration Form (7 columns on desktop) */}
          <div
            className={`lg:col-span-7 p-6 space-y-5 ${
              previewTab === 'preview' ? 'hidden lg:block' : 'block'
            }`}
          >
            {/* 1. Basic Details */}
            <div className="space-y-3.5">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 border-b pb-1">
                1. General Information
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Template Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={title}
                    onChange={e => setTitle(e.target.value)}
                    placeholder="e.g. NeoApex Tech"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
                  />
                  {errors.title && <p className="text-[11px] text-red-600 mt-1">{errors.title}</p>}
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Category
                  </label>
                  <select
                    value={category}
                    onChange={e => setCategory(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
                  >
                    <option value="Software Engineering">Software Engineering</option>
                    <option value="Fresher Resume">Fresher & Entry-Level</option>
                    <option value="IT & Developer Resume">IT & Cloud Developer</option>
                    <option value="Corporate & Tech">Corporate & Tech</option>
                    <option value="Executive & Senior Leadership">Executive & Senior Leadership</option>
                    <option value="Data Science & AI">Data Science & AI</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Description <span className="text-red-500">*</span>
                </label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  placeholder="Summarize the typography, ATS compatibility, and recommended target audience..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
                />
                {errors.description && <p className="text-[11px] text-red-600 mt-1">{errors.description}</p>}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Intended Audience / User <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={intendedUser}
                    onChange={e => setIntendedUser(e.target.value)}
                    placeholder="e.g. Mid-Level Developers & Tech Leads"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
                  />
                  {errors.intendedUser && <p className="text-[11px] text-red-600 mt-1">{errors.intendedUser}</p>}
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Target Job Roles (comma-separated)
                  </label>
                  <input
                    type="text"
                    value={intendedRolesInput}
                    onChange={e => setIntendedRolesInput(e.target.value)}
                    placeholder="Software Engineer, Cloud Architect, DevOps"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
                  />
                </div>
              </div>
            </div>

            {/* 2. Access Tier & Pricing */}
            <div className="space-y-3.5 pt-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 border-b pb-1">
                2. Access Tier & Pricing
              </h3>

              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setTier('free')}
                  className={`p-3 rounded-xl border text-left transition-all flex items-start gap-2.5 ${
                    tier === 'free'
                      ? 'border-emerald-500 bg-emerald-50/50 ring-2 ring-emerald-500/20'
                      : 'border-slate-200 bg-slate-50/50 hover:bg-slate-100/60'
                  }`}
                >
                  <div
                    className={`w-4 h-4 rounded-full border mt-0.5 flex items-center justify-center shrink-0 ${
                      tier === 'free' ? 'border-emerald-600 bg-emerald-600 text-white' : 'border-slate-300'
                    }`}
                  >
                    {tier === 'free' && <Check className="w-3 h-3 stroke-[3]" />}
                  </div>
                  <div>
                    <span className="font-bold text-xs text-slate-900 block">Free Template</span>
                    <span className="text-[11px] text-slate-500 block">
                      Accessible by all registered users without payment
                    </span>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setTier('premium')}
                  className={`p-3 rounded-xl border text-left transition-all flex items-start gap-2.5 ${
                    tier === 'premium'
                      ? 'border-[#6D5DFB] bg-[#F1EEFF]/60 ring-2 ring-[#6D5DFB]/20'
                      : 'border-slate-200 bg-slate-50/50 hover:bg-slate-100/60'
                  }`}
                >
                  <div
                    className={`w-4 h-4 rounded-full border mt-0.5 flex items-center justify-center shrink-0 ${
                      tier === 'premium' ? 'border-[#6D5DFB] bg-[#6D5DFB] text-white' : 'border-slate-300'
                    }`}
                  >
                    {tier === 'premium' && <Check className="w-3 h-3 stroke-[3]" />}
                  </div>
                  <div>
                    <span className="font-bold text-xs text-slate-900 block flex items-center gap-1">
                      <Lock className="w-3 h-3 text-[#6D5DFB]" />
                      Premium Pro
                    </span>
                    <span className="text-[11px] text-slate-500 block">
                      Users require verified purchase or entitlement
                    </span>
                  </div>
                </button>
              </div>

              {tier === 'premium' && (
                <div className="bg-[#F1EEFF]/40 border border-[#6D5DFB]/20 rounded-xl p-3.5 space-y-2">
                  <label className="block text-xs font-bold text-slate-800">
                    Template Price in Indian Rupees (INR) <span className="text-red-500">*</span>
                  </label>
                  <div className="relative max-w-xs">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 font-bold text-slate-500 text-xs">
                      ₹
                    </span>
                    <input
                      type="number"
                      min={1}
                      max={9999}
                      value={priceInr}
                      onChange={e => setPriceInr(Math.max(1, parseInt(e.target.value) || 0))}
                      className="w-full bg-white border border-slate-200 rounded-xl pl-8 pr-3 py-2 text-xs font-mono font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
                    />
                  </div>
                  {errors.priceInr && <p className="text-[11px] text-red-600">{errors.priceInr}</p>}
                  <p className="text-[11px] text-slate-500">
                    Note: Admin accounts can test, preview, and edit this template directly with zero purchase restrictions.
                  </p>
                </div>
              )}
            </div>

            {/* 3. Layout, Typography & Styling */}
            <div className="space-y-3.5 pt-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 border-b pb-1">
                3. Layout & Visual Styling
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                {/* Layout selection */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5 flex items-center gap-1.5">
                    <Columns className="w-3.5 h-3.5 text-[#6D5DFB]" />
                    Layout Format
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setLayout('single-column')}
                      className={`p-2.5 rounded-xl border text-xs font-semibold text-center transition-all ${
                        layout === 'single-column'
                          ? 'border-[#6D5DFB] bg-[#F1EEFF] text-[#6D5DFB]'
                          : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      Single Column
                    </button>
                    <button
                      type="button"
                      onClick={() => setLayout('two-column')}
                      className={`p-2.5 rounded-xl border text-xs font-semibold text-center transition-all ${
                        layout === 'two-column'
                          ? 'border-[#6D5DFB] bg-[#F1EEFF] text-[#6D5DFB]'
                          : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      Two Column
                    </button>
                  </div>
                </div>

                {/* Font selection */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5 flex items-center gap-1.5">
                    <Type className="w-3.5 h-3.5 text-[#6D5DFB]" />
                    Typography Theme
                  </label>
                  <div className="grid grid-cols-3 gap-1.5">
                    <button
                      type="button"
                      onClick={() => setThemeFont('sans')}
                      className={`p-2 rounded-xl border text-xs text-center transition-all ${
                        themeFont === 'sans'
                          ? 'border-[#6D5DFB] bg-[#F1EEFF] text-[#6D5DFB] font-bold'
                          : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      Sans
                    </button>
                    <button
                      type="button"
                      onClick={() => setThemeFont('serif')}
                      className={`p-2 rounded-xl border text-xs text-center font-serif transition-all ${
                        themeFont === 'serif'
                          ? 'border-[#6D5DFB] bg-[#F1EEFF] text-[#6D5DFB] font-bold'
                          : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      Serif
                    </button>
                    <button
                      type="button"
                      onClick={() => setThemeFont('mono')}
                      className={`p-2 rounded-xl border text-xs text-center font-mono transition-all ${
                        themeFont === 'mono'
                          ? 'border-[#6D5DFB] bg-[#F1EEFF] text-[#6D5DFB] font-bold'
                          : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      Mono
                    </button>
                  </div>
                </div>
              </div>

              {/* Accent Color Palette */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5 flex items-center gap-1.5">
                  <Palette className="w-3.5 h-3.5 text-[#6D5DFB]" />
                  Accent Color
                </label>
                <div className="flex flex-wrap items-center gap-2">
                  {PRESET_COLORS.map(c => (
                    <button
                      key={c.hex}
                      type="button"
                      onClick={() => setAccentColor(c.hex)}
                      title={c.name}
                      className={`w-7 h-7 rounded-full flex items-center justify-center transition-all ${
                        accentColor.toLowerCase() === c.hex.toLowerCase()
                          ? 'ring-2 ring-offset-2 ring-[#6D5DFB] scale-110'
                          : 'hover:scale-105'
                      }`}
                      style={{ backgroundColor: c.hex }}
                    >
                      {accentColor.toLowerCase() === c.hex.toLowerCase() && (
                        <Check className="w-3.5 h-3.5 text-white stroke-[3]" />
                      )}
                    </button>
                  ))}
                  <div className="flex items-center gap-1.5 ml-2">
                    <span className="text-[11px] text-slate-400 font-mono">Hex:</span>
                    <input
                      type="text"
                      value={accentColor}
                      onChange={e => setAccentColor(e.target.value)}
                      className="w-20 px-2 py-1 text-xs font-mono rounded-lg border border-slate-200 bg-slate-50"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* 4. Modular Resume Sections */}
            <div className="space-y-3 pt-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 border-b pb-1">
                4. Modular Resume Sections
              </h3>
              <p className="text-[11px] text-slate-500">
                Choose which content modules are active in this template:
              </p>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {[
                  { key: 'summary', label: 'Summary / Objective' },
                  { key: 'education', label: 'Education' },
                  { key: 'skills', label: 'Skills & Tools' },
                  { key: 'projects', label: 'Academic Projects' },
                  { key: 'experience', label: 'Work Experience' },
                  { key: 'certifications', label: 'Certifications' },
                  { key: 'achievements', label: 'Achievements' }
                ].map(item => {
                  const isChecked = sections[item.key as keyof ResumeTemplateSections];
                  return (
                    <button
                      key={item.key}
                      type="button"
                      onClick={() => toggleSection(item.key as keyof ResumeTemplateSections)}
                      className={`p-2 rounded-xl border text-xs text-left font-medium transition-all flex items-center gap-2 ${
                        isChecked
                          ? 'border-[#6D5DFB]/40 bg-[#F1EEFF]/60 text-slate-900 font-semibold'
                          : 'border-slate-200 bg-slate-50 text-slate-400'
                      }`}
                    >
                      <div
                        className={`w-3.5 h-3.5 rounded border flex items-center justify-center shrink-0 ${
                          isChecked ? 'bg-[#6D5DFB] border-[#6D5DFB] text-white' : 'border-slate-300'
                        }`}
                      >
                        {isChecked && <Check className="w-2.5 h-2.5 stroke-[3]" />}
                      </div>
                      <span className="truncate">{item.label}</span>
                    </button>
                  );
                })}
              </div>
              {errors.sections && <p className="text-[11px] text-red-600">{errors.sections}</p>}
            </div>
          </div>

          {/* Right: Live Miniature Preview (5 columns on desktop) */}
          <div
            className={`lg:col-span-5 p-6 bg-slate-50/70 flex flex-col justify-between ${
              previewTab === 'form' ? 'hidden lg:flex' : 'flex'
            }`}
          >
            <div>
              <div className="flex items-center justify-between pb-3 border-b border-slate-200 mb-3">
                <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800">
                  <Eye className="w-4 h-4 text-[#6D5DFB]" />
                  <span>Real-Time Template Preview</span>
                </div>
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-slate-200 text-slate-700">
                  {layout === 'two-column' ? '2-Column' : '1-Column'}
                </span>
              </div>

              {/* Rendered Live Miniature Canvas */}
              <div className="bg-white rounded-xl shadow-xs border border-slate-200 overflow-hidden relative">
                <div className="p-3 max-h-[460px] overflow-y-auto">
                  <CustomConfigurableResume
                    data={DEFAULT_SAMPLE_RESUME}
                    isMiniature={true}
                    accentColor={accentColor}
                    layout={layout}
                    font={themeFont}
                    enabledSections={sections}
                  />
                </div>
              </div>

              {/* Summary metadata preview */}
              <div className="mt-3 p-3 bg-white rounded-xl border border-slate-200 text-[11px] text-slate-600 space-y-1">
                <div className="flex justify-between">
                  <span className="font-semibold text-slate-700">Preview Name:</span>
                  <span className="font-mono text-slate-900 font-bold">{title || 'Untitled Template'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-semibold text-slate-700">Tier & Price:</span>
                  <span className="font-bold text-[#6D5DFB]">
                    {tier === 'free' ? 'Free (₹0)' : `Premium (₹${priceInr})`}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="font-semibold text-slate-700">Font & Color:</span>
                  <span className="capitalize">{themeFont} &bull; <span className="font-mono">{accentColor}</span></span>
                </div>
              </div>
            </div>

            <div className="text-[11px] text-slate-400 text-center mt-4 pt-2 border-t border-slate-200">
              Live preview automatically updates as you adjust layout, palette, and modules.
            </div>
          </div>
        </div>

        {/* Modal Footer Actions */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <div className="text-xs text-slate-500">
            {isEditing ? (
              <span>Editing template: <strong className="text-slate-800">{initialTemplate?.title}</strong></span>
            ) : (
              <span>Template will be registered in local storage and audit log.</span>
            )}
          </div>

          <div className="flex items-center gap-2.5 w-full sm:w-auto">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 sm:flex-initial px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 rounded-xl transition-colors"
            >
              Cancel
            </button>

            <button
              type="button"
              onClick={() => handleSubmit('Draft')}
              className="flex-1 sm:flex-initial px-4 py-2 text-xs font-bold text-amber-800 bg-amber-100 hover:bg-amber-200 rounded-xl transition-colors"
            >
              Save Draft
            </button>

            <button
              type="button"
              onClick={() => handleSubmit('Published')}
              className="flex-1 sm:flex-initial px-5 py-2 text-xs font-bold text-white bg-gradient-to-r from-[#6D5DFB] to-[#5B4BE3] hover:from-[#5B4BE3] hover:to-[#4C3BCF] shadow-sm shadow-[#6D5DFB]/20 rounded-xl transition-all"
            >
              {isEditing ? 'Save & Publish' : 'Create & Publish'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
