import React, { useState } from 'react';
import {
  Lock,
  Sparkles,
  Check,
  X,
  CreditCard,
  AlertCircle,
  Eye,
  ShieldCheck,
  Zap,
  Info
} from 'lucide-react';
import { ResumeTemplate } from '../../types';
import { DEFAULT_SAMPLE_RESUME, renderResumeTemplate } from './ResumeTemplateRenderers';
import { Modal } from '../common/Modal';

interface PremiumUnlockModalProps {
  template: ResumeTemplate | null;
  isOpen: boolean;
  onClose: () => void;
}

export const PremiumUnlockModal: React.FC<PremiumUnlockModalProps> = ({
  template,
  isOpen,
  onClose
}) => {
  const [showDemoMessage, setShowDemoMessage] = useState(false);
  const [previewTab, setPreviewTab] = useState<'info' | 'preview'>('info');

  if (!template) return null;

  const handleUnlockClick = () => {
    setShowDemoMessage(true);
  };

  const handleModalClose = () => {
    setShowDemoMessage(false);
    setPreviewTab('info');
    onClose();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={handleModalClose}
      title={`Premium Template: ${template.title}`}
      maxWidth="3xl"
    >
      <div className="space-y-5 text-xs text-slate-700">
        {/* Tier & Intended Audience Banner */}
        <div className="bg-gradient-to-r from-[#172554] via-[#1E1B4B] to-[#111827] text-white p-5 rounded-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-[#6D5DFB]/20 rounded-full blur-2xl pointer-events-none" />

          <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1.5">
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-[#8B5CF6] text-white flex items-center gap-1 shadow-xs">
                  <Lock className="w-3 h-3" />
                  Premium Pro Template
                </span>
                <span className="text-slate-300 text-xs font-mono">&bull; {template.category}</span>
              </div>
              <h3 className="text-xl font-extrabold text-white tracking-tight">
                {template.title}
              </h3>
              <p className="text-xs text-slate-300 mt-1">
                Target Audience: <strong className="text-white">{template.intendedUser}</strong>
              </p>
            </div>

            {/* INR Price Tag Placeholder */}
            <div className="text-left sm:text-right bg-white/10 backdrop-blur-md px-4 py-2.5 rounded-xl border border-white/15 shrink-0">
              <span className="text-[10px] uppercase font-bold text-slate-300 block">Single License Price</span>
              <div className="text-2xl font-black font-mono text-emerald-400">
                ₹{template.priceInr || 299}
                <span className="text-[11px] font-sans font-normal text-slate-300 ml-1">INR (Placeholder)</span>
              </div>
            </div>
          </div>
        </div>

        {/* Tab switch between Details and Sample Preview */}
        <div className="flex border-b border-slate-200">
          <button
            type="button"
            onClick={() => setPreviewTab('info')}
            className={`py-2 px-4 text-xs font-bold border-b-2 transition-all ${
              previewTab === 'info'
                ? 'border-[#6D5DFB] text-[#6D5DFB]'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Template Features & Details
          </button>
          <button
            type="button"
            onClick={() => setPreviewTab('preview')}
            className={`py-2 px-4 text-xs font-bold border-b-2 transition-all flex items-center gap-1.5 ${
              previewTab === 'preview'
                ? 'border-[#6D5DFB] text-[#6D5DFB]'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Eye className="w-3.5 h-3.5" />
            <span>Sample Document Preview</span>
          </button>
        </div>

        {previewTab === 'info' ? (
          <div className="space-y-4">
            <p className="text-xs text-slate-600 leading-relaxed">
              {template.description}
            </p>

            {/* Features List */}
            <div className="bg-[#F7F8FC] p-4 rounded-xl border border-slate-200/80">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900 mb-2.5 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-[#6D5DFB]" />
                Included Template Highlights
              </h4>
              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {template.features.map((feat, idx) => (
                  <li key={idx} className="flex items-center gap-2 text-xs text-slate-700">
                    <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>{feat}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Demo Notice / Unlock Response State */}
            {showDemoMessage ? (
              <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-amber-900 space-y-2">
                <div className="flex items-center gap-2 font-bold text-xs">
                  <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                  <span>Payment Gateway Integration Coming Soon</span>
                </div>
                <p className="text-xs text-amber-800 leading-relaxed">
                  Payment integration (Razorpay / UPI / Cards) is currently scheduled for the next release.
                  In accordance with the current platform rules, premium templates remain locked and purchases are not yet processed.
                </p>
                <div className="text-[11px] text-amber-700 pt-1 font-mono">
                  Status: Template remains locked. No charges or automatic unlocks applied.
                </div>
              </div>
            ) : null}

            {/* Action Buttons */}
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={handleModalClose}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 transition-colors"
              >
                Close Preview
              </button>
              <button
                type="button"
                onClick={handleUnlockClick}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-[#6D5DFB] via-[#8B5CF6] to-[#4F46E5] hover:opacity-95 transition-all shadow-md shadow-[#6D5DFB]/25"
              >
                <Lock className="w-4 h-4" />
                <span>Unlock Premium (₹{template.priceInr || 299})</span>
              </button>
            </div>
          </div>
        ) : (
          /* Live Rendered Sample Preview */
          <div className="space-y-3">
            <div className="bg-[#F1EEFF] p-2 rounded-lg text-[11px] text-[#6D5DFB] font-semibold flex items-center justify-between">
              <span>Displaying realistic sample candidate information for visual evaluation.</span>
              <span className="font-mono text-slate-400">Read-Only Sample</span>
            </div>
            <div className="max-h-[500px] overflow-y-auto p-3 bg-slate-100 rounded-xl border border-slate-200 shadow-inner">
              {renderResumeTemplate(template.templateKey, DEFAULT_SAMPLE_RESUME, false)}
            </div>
          </div>
        )}
      </div>
    </Modal>
  );
};
