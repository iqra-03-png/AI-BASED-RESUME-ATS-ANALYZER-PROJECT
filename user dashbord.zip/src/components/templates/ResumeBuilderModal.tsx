import React, { useState, useEffect } from 'react';
import {
  X,
  Save,
  Download,
  Plus,
  Trash2,
  Eye,
  Edit3,
  Sparkles,
  CheckCircle2,
} from 'lucide-react';
import { ResumeTemplate, ResumeDraft } from '../../types';
import { api } from '../../services/api';
import {
  ResumeData,
  sampleResumeData,
  ResumeTemplateRenderer,
} from './ResumeTemplateRenderer';

interface ResumeBuilderModalProps {
  template: ResumeTemplate;
  onClose: () => void;
}

export const ResumeBuilderModal: React.FC<ResumeBuilderModalProps> = ({
  template,
  onClose,
}) => {
  const [data, setData] = useState<ResumeData>(sampleResumeData);
  const [draftTitle, setDraftTitle] = useState<string>(`${template.name} - My Resume`);
  const [saving, setSaving] = useState<boolean>(false);
  const [savedSuccess, setSavedSuccess] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'editor' | 'preview' | 'both'>('both');

  // Load existing draft if present
  useEffect(() => {
    async function loadDraft() {
      try {
        const res = await api.getDraft(template.id);
        if (res.draft && res.draft.data) {
          setData(res.draft.data);
          if (res.draft.title) setDraftTitle(res.draft.title);
        }
      } catch (err) {
        console.error('Failed to load draft:', err);
      }
    }
    loadDraft();
  }, [template.id]);

  const handleSaveDraft = async () => {
    setSaving(true);
    setSavedSuccess(false);
    try {
      await api.saveDraft(template.id, draftTitle, data);
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 3000);
    } catch (err) {
      console.error('Draft save failed:', err);
    } finally {
      setSaving(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  // Add work experience
  const handleAddExperience = () => {
    setData({
      ...data,
      experience: [
        ...data.experience,
        {
          role: 'Software Engineer',
          company: 'Company Name',
          startDate: '2023',
          endDate: 'Present',
          bullets: ['Developed key features and improved performance.'],
        },
      ],
    });
  };

  const handleRemoveExperience = (idx: number) => {
    setData({
      ...data,
      experience: data.experience.filter((_, i) => i !== idx),
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-900/70 backdrop-blur-xs overflow-hidden">
      <div className="w-full max-w-7xl h-[94vh] bg-white rounded-2xl shadow-2xl flex flex-col overflow-hidden border border-slate-200">
        {/* Header Bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50/70">
          <div className="flex items-center gap-3">
            <div
              className="w-8 h-8 rounded-lg flex items-center justify-center text-white font-bold text-xs shadow-xs"
              style={{ backgroundColor: template.accentColor }}
            >
              {template.name.charAt(0)}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={draftTitle}
                  onChange={(e) => setDraftTitle(e.target.value)}
                  className="font-bold text-slate-900 text-sm bg-transparent hover:bg-white px-2 py-0.5 rounded border border-transparent hover:border-slate-300 focus:bg-white focus:border-violet-500 focus:outline-hidden"
                />
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-violet-100 text-violet-700">
                  {template.tier === 'premium' ? 'Premium Layout' : 'Free Layout'}
                </span>
              </div>
              <p className="text-[11px] text-slate-500 px-2">
                Template: {template.name} • Live Preview & Dynamic Field Sync
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {savedSuccess && (
              <span className="inline-flex items-center gap-1 text-xs text-emerald-600 font-semibold px-2.5 py-1 rounded bg-emerald-50 border border-emerald-200">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Draft Saved</span>
              </span>
            )}

            <button
              onClick={handleSaveDraft}
              disabled={saving}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-violet-600 hover:bg-violet-700 rounded-xl shadow-xs transition-colors"
            >
              <Save className="w-3.5 h-3.5" />
              <span>{saving ? 'Saving...' : 'Save Draft'}</span>
            </button>

            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-300 rounded-xl shadow-xs transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download PDF</span>
            </button>

            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-200/60"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Workspace Body: Split View */}
        <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 overflow-hidden">
          {/* Left Form Editor */}
          <div className="lg:col-span-5 p-6 overflow-y-auto border-r border-slate-200 space-y-6 bg-slate-50/40">
            {/* Personal Details */}
            <div className="p-4 rounded-xl bg-white border border-slate-200 space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Personal Credentials
              </h4>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <label className="text-slate-500 font-medium text-[11px]">Full Name</label>
                  <input
                    type="text"
                    value={data.fullName}
                    onChange={(e) => setData({ ...data, fullName: e.target.value })}
                    className="w-full mt-1 p-2 border border-slate-200 rounded-lg text-slate-900 font-semibold"
                  />
                </div>
                <div>
                  <label className="text-slate-500 font-medium text-[11px]">Target Job Title</label>
                  <input
                    type="text"
                    value={data.jobTitle}
                    onChange={(e) => setData({ ...data, jobTitle: e.target.value })}
                    className="w-full mt-1 p-2 border border-slate-200 rounded-lg text-slate-900 font-semibold"
                  />
                </div>
                <div>
                  <label className="text-slate-500 font-medium text-[11px]">Email</label>
                  <input
                    type="email"
                    value={data.email}
                    onChange={(e) => setData({ ...data, email: e.target.value })}
                    className="w-full mt-1 p-2 border border-slate-200 rounded-lg text-slate-800"
                  />
                </div>
                <div>
                  <label className="text-slate-500 font-medium text-[11px]">Phone</label>
                  <input
                    type="text"
                    value={data.phone}
                    onChange={(e) => setData({ ...data, phone: e.target.value })}
                    className="w-full mt-1 p-2 border border-slate-200 rounded-lg text-slate-800"
                  />
                </div>
              </div>
              <div className="text-xs">
                <label className="text-slate-500 font-medium text-[11px]">Location</label>
                <input
                  type="text"
                  value={data.location}
                  onChange={(e) => setData({ ...data, location: e.target.value })}
                  className="w-full mt-1 p-2 border border-slate-200 rounded-lg text-slate-800"
                />
              </div>
            </div>

            {/* Professional Summary */}
            <div className="p-4 rounded-xl bg-white border border-slate-200 space-y-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Professional Summary
              </h4>
              <textarea
                rows={3}
                value={data.summary}
                onChange={(e) => setData({ ...data, summary: e.target.value })}
                className="w-full p-2 border border-slate-200 rounded-lg text-xs text-slate-800"
              />
            </div>

            {/* Experience */}
            <div className="p-4 rounded-xl bg-white border border-slate-200 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  Work Experience
                </h4>
                <button
                  onClick={handleAddExperience}
                  className="inline-flex items-center gap-1 text-[11px] font-semibold text-violet-600 hover:text-violet-700 bg-violet-50 px-2.5 py-1 rounded-lg"
                >
                  <Plus className="w-3 h-3" />
                  <span>Add Role</span>
                </button>
              </div>

              {data.experience.map((exp, idx) => (
                <div key={idx} className="p-3 rounded-lg border border-slate-200 bg-slate-50/60 space-y-2 text-xs">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-slate-800">Role #{idx + 1}</span>
                    <button
                      onClick={() => handleRemoveExperience(idx)}
                      className="text-rose-500 hover:text-rose-700 text-[11px]"
                    >
                      Remove
                    </button>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      placeholder="Role title"
                      value={exp.role}
                      onChange={(e) => {
                        const copy = [...data.experience];
                        copy[idx].role = e.target.value;
                        setData({ ...data, experience: copy });
                      }}
                      className="p-1.5 border border-slate-200 rounded bg-white text-slate-800"
                    />
                    <input
                      type="text"
                      placeholder="Company"
                      value={exp.company}
                      onChange={(e) => {
                        const copy = [...data.experience];
                        copy[idx].company = e.target.value;
                        setData({ ...data, experience: copy });
                      }}
                      className="p-1.5 border border-slate-200 rounded bg-white text-slate-800"
                    />
                  </div>
                </div>
              ))}
            </div>

            {/* Technical Skills */}
            <div className="p-4 rounded-xl bg-white border border-slate-200 space-y-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Technical Skills (Comma separated)
              </h4>
              <input
                type="text"
                value={data.skills.technical.join(', ')}
                onChange={(e) =>
                  setData({
                    ...data,
                    skills: {
                      ...data.skills,
                      technical: e.target.value.split(',').map((s) => s.trim()).filter(Boolean),
                    },
                  })
                }
                className="w-full p-2 border border-slate-200 rounded-lg text-xs text-slate-800"
              />
            </div>
          </div>

          {/* Right Live Preview Canvas */}
          <div className="lg:col-span-7 p-6 overflow-y-auto bg-slate-200/70 flex justify-center items-start">
            <div className="w-full max-w-2xl bg-white shadow-xl rounded-lg overflow-hidden my-4 border border-slate-300">
              <ResumeTemplateRenderer template={template} data={data} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
