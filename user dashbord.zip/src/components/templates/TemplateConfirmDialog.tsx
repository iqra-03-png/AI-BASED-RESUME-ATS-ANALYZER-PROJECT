import React from 'react';
import {
  AlertTriangle,
  Archive,
  Trash2,
  EyeOff,
  ShieldAlert,
  Info,
  Globe,
  X
} from 'lucide-react';
import { ResumeTemplate } from '../../types';

export type ConfirmActionType = 'publish' | 'unpublish' | 'delete';

interface TemplateConfirmDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  actionType: ConfirmActionType;
  template: ResumeTemplate | null;
}

export const TemplateConfirmDialog: React.FC<TemplateConfirmDialogProps> = ({
  isOpen,
  onClose,
  onConfirm,
  actionType,
  template
}) => {
  if (!isOpen || !template) return null;

  const purchasesCount = template.purchasesCount || 0;
  const savedResumesCount = template.savedResumesCount || 0;
  const hasDependencies = purchasesCount > 0 || savedResumesCount > 0;

  const isPublish = actionType === 'publish';
  const isUnpublish = actionType === 'unpublish';
  const isDelete = actionType === 'delete';

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className={`p-5 flex items-start gap-3.5 border-b ${
          isPublish
            ? 'bg-emerald-50/70 border-emerald-100'
            : isUnpublish
            ? 'bg-amber-50/60 border-amber-100'
            : 'bg-red-50/60 border-red-100'
        }`}>
          <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
            isPublish
              ? 'bg-emerald-100 text-emerald-600'
              : isUnpublish
              ? 'bg-amber-100 text-amber-600'
              : 'bg-red-100 text-red-600'
          }`}>
            {isPublish ? <Globe className="w-5 h-5" /> : isUnpublish ? <EyeOff className="w-5 h-5" /> : <Trash2 className="w-5 h-5" />}
          </div>

          <div className="flex-1">
            <h3 className="text-sm font-bold text-slate-900">
              {isPublish
                ? 'Publish Resume Template'
                : isUnpublish
                ? 'Unpublish Resume Template'
                : 'Delete Resume Template'}
            </h3>
            <p className="text-xs text-slate-600 mt-0.5">
              Target: <strong className="text-slate-900 font-semibold">{template.title}</strong> ({template.tier === 'free' ? 'Free' : `₹${template.priceInr}`})
            </p>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 space-y-4 text-xs text-slate-600 leading-relaxed">
          {isPublish ? (
            <>
              <p>
                Are you sure you want to publish <strong>{template.title}</strong>?
              </p>
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-2">
                <div className="flex items-start gap-2 text-slate-700">
                  <Globe className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span>
                    <strong>User Catalogue Visibility:</strong> This template will immediately become visible to all candidates in the User Catalogue.
                  </span>
                </div>
                <div className="flex items-start gap-2 text-slate-700">
                  <Info className="w-4 h-4 text-[#6D5DFB] shrink-0 mt-0.5" />
                  <span>
                    <strong>Tier & Pricing:</strong> {template.tier === 'free' ? 'Free for all users to select and build.' : `Premium template listed at ₹${template.priceInr}.`}
                  </span>
                </div>
                <div className="flex items-start gap-2 text-slate-700">
                  <ShieldAlert className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
                  <span>
                    <strong>Reversible Action:</strong> You can unpublish or update this template at any time from this dashboard.
                  </span>
                </div>
              </div>
            </>
          ) : isUnpublish ? (
            <>
              <p>
                Are you sure you want to unpublish <strong>{template.title}</strong>?
              </p>
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-2">
                <div className="flex items-start gap-2 text-slate-700">
                  <EyeOff className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                  <span>
                    <strong>User Catalogue Visibility:</strong> This template will immediately be hidden from the User Dashboard. New users cannot select or purchase it.
                  </span>
                </div>
                <div className="flex items-start gap-2 text-slate-700">
                  <ShieldAlert className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span>
                    <strong>Existing User Protection:</strong> Candidates who have already purchased or saved resumes using this template retain full uninterrupted access.
                  </span>
                </div>
                <div className="flex items-start gap-2 text-slate-700">
                  <Info className="w-4 h-4 text-[#6D5DFB] shrink-0 mt-0.5" />
                  <span>
                    <strong>Reversible Action:</strong> You can republish this template at any time with a single click.
                  </span>
                </div>
              </div>
            </>
          ) : (
            <>
              <p>
                You are about to delete <strong>{template.title}</strong>.
              </p>

              {hasDependencies ? (
                <div className="bg-amber-50 border border-amber-200 rounded-xl p-3.5 space-y-2 text-amber-900">
                  <div className="flex items-center gap-1.5 font-bold">
                    <AlertTriangle className="w-4 h-4 text-amber-600" />
                    <span>Existing User Records Detected:</span>
                  </div>
                  <ul className="list-disc list-inside space-y-1 text-[11px] text-amber-800">
                    <li><strong>{purchasesCount}</strong> recorded candidate purchases (Paid receipts)</li>
                    <li><strong>{savedResumesCount}</strong> active candidate draft/saved resumes</li>
                  </ul>
                  <div className="pt-1.5 border-t border-amber-200 text-[11px] flex items-start gap-1.5 text-amber-900 font-medium">
                    <Archive className="w-3.5 h-3.5 text-amber-700 shrink-0 mt-0.5" />
                    <span>
                      To protect candidate purchase integrity and prevent broken resumes, this template will be <strong>safely archived</strong> (soft deleted) rather than permanently wiped.
                    </span>
                  </div>
                </div>
              ) : (
                <p className="text-slate-500 bg-slate-50 border border-slate-200 rounded-xl p-3">
                  This template has no dependent user purchases or saved resumes. It can be safely removed from the system.
                </p>
              )}
            </>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-end gap-2.5">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 rounded-xl transition-colors"
          >
            Cancel
          </button>

          <button
            type="button"
            onClick={() => {
              onConfirm();
              onClose();
            }}
            className={`px-4 py-2 text-xs font-bold text-white rounded-xl transition-all shadow-sm ${
              isPublish
                ? 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-500/20'
                : isUnpublish
                ? 'bg-amber-600 hover:bg-amber-700 shadow-amber-500/20'
                : 'bg-red-600 hover:bg-red-700 shadow-red-500/20'
            }`}
          >
            {isPublish
              ? 'Confirm Publish'
              : isUnpublish
              ? 'Confirm Unpublish'
              : hasDependencies
              ? 'Archive Safely'
              : 'Permanently Delete'}
          </button>
        </div>
      </div>
    </div>
  );
};
