import React from 'react';
import { ResumeTemplate } from '../../types';
import { Mail, Phone, MapPin, Globe, Linkedin, Github } from 'lucide-react';

export interface ResumeData {
  fullName: string;
  jobTitle: string;
  email: string;
  phone: string;
  location: string;
  website?: string;
  summary: string;
  experience: Array<{
    role: string;
    company: string;
    location?: string;
    startDate: string;
    endDate: string;
    bullets: string[];
  }>;
  education: Array<{
    degree: string;
    institution: string;
    location?: string;
    year: string;
  }>;
  projects: Array<{
    name: string;
    technologies: string;
    description: string;
  }>;
  skills: {
    technical: string[];
    soft: string[];
    tools?: string[];
  };
  certifications?: string[];
}

export const sampleResumeData: ResumeData = {
  fullName: 'Iqra',
  jobTitle: 'Senior Full-Stack & Cloud Engineer',
  email: 'iqra@resunova.ai',
  phone: '+1 (555) 349-8291',
  location: 'San Francisco, CA',
  website: 'github.com/iqra-dev',
  summary:
    'Results-driven Full-Stack Engineer with 5+ years building scalable microservices, low-latency web applications, and resilient cloud architectures. Passionate about developer tooling, clean modular architecture, and modern ATS optimization.',
  experience: [
    {
      role: 'Senior Software Engineer',
      company: 'NovaTech Solutions',
      location: 'San Francisco, CA',
      startDate: '2022',
      endDate: 'Present',
      bullets: [
        'Architected high-throughput REST and GraphQL services processing 12M+ monthly requests with 99.98% uptime.',
        'Migrated legacy monolithic frontend to React and TypeScript, accelerating core web vitals and reducing bundle size by 38%.',
        'Spearheaded CI/CD automation with GitHub Actions and Docker, cutting deployment cycle times from 45 to 8 minutes.',
      ],
    },
    {
      role: 'Full-Stack Developer',
      company: 'Apex Digital Labs',
      location: 'San Jose, CA',
      startDate: '2020',
      endDate: '2022',
      bullets: [
        'Engineered responsive customer onboarding workflows using React, Node.js, and PostgreSQL.',
        'Implemented Redis caching layers to optimize heavy database queries, slashing response latency by 52%.',
      ],
    },
  ],
  education: [
    {
      degree: 'B.S. in Computer Science',
      institution: 'University of California, Berkeley',
      year: '2016 – 2020',
      location: 'Berkeley, CA',
    },
  ],
  projects: [
    {
      name: 'ResuNova ATS Intelligence Engine',
      technologies: 'React, TypeScript, Node.js, Tailwind CSS',
      description:
        'Engineered an automated resume analyzer assessing 15 hiring parameters, keyword coverage, and real-time interview simulations.',
    },
    {
      name: 'CloudMetrics Distributed Telemetry',
      technologies: 'Go, Docker, Prometheus, Grafana',
      description:
        'Built an open-source real-time metrics scraper capable of monitoring 200+ container nodes.',
    },
  ],
  skills: {
    technical: ['TypeScript', 'JavaScript', 'React', 'Node.js', 'Python', 'SQL', 'GraphQL', 'Tailwind CSS', 'Docker', 'PostgreSQL'],
    soft: ['Technical Leadership', 'Problem Solving', 'Agile/Scrum', 'Cross-functional Collaboration'],
    tools: ['Git', 'AWS', 'VS Code', 'Postman', 'Figma'],
  },
  certifications: ['AWS Certified Solutions Architect', 'Meta Certified Frontend Developer'],
};

interface ResumeTemplateRendererProps {
  template: ResumeTemplate;
  data: ResumeData;
  scale?: number;
}

export const ResumeTemplateRenderer: React.FC<ResumeTemplateRendererProps> = ({
  template,
  data,
  scale = 1,
}) => {
  const accent = template.accentColor || '#7c3aed';

  // Choose style based on template layoutStyle
  if (template.layoutStyle === 'tech-minimal') {
    return (
      <div
        className="w-full bg-white text-slate-800 p-8 shadow-sm font-mono text-[11px] leading-relaxed border-t-4"
        style={{ borderColor: accent, transform: `scale(${scale})`, transformOrigin: 'top center' }}
      >
        <div className="border-b border-slate-200 pb-4 mb-4">
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight font-sans">
            {data.fullName}
          </h1>
          <p className="text-xs font-semibold text-emerald-600 mt-0.5">{data.jobTitle}</p>
          <div className="flex flex-wrap gap-x-4 gap-y-1 text-[10px] text-slate-500 mt-2">
            <span>{data.email}</span>
            <span>•</span>
            <span>{data.phone}</span>
            <span>•</span>
            <span>{data.location}</span>
            {data.website && (
              <>
                <span>•</span>
                <span>{data.website}</span>
              </>
            )}
          </div>
        </div>

        {/* Summary */}
        <div className="mb-4">
          <p className="text-slate-600 font-sans text-xs">{data.summary}</p>
        </div>

        {/* Skills Matrix */}
        <div className="mb-4">
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-900 border-b border-slate-200 pb-1 mb-2">
            // Core Technical Competencies
          </h2>
          <div className="flex flex-wrap gap-1.5 font-sans">
            {data.skills.technical.map((s, i) => (
              <span key={i} className="px-2 py-0.5 rounded bg-slate-100 text-slate-800 text-[10px] font-semibold border border-slate-200">
                {s}
              </span>
            ))}
          </div>
        </div>

        {/* Experience */}
        <div className="mb-4">
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-900 border-b border-slate-200 pb-1 mb-2">
            // Professional Work Experience
          </h2>
          <div className="space-y-3 font-sans">
            {data.experience.map((exp, i) => (
              <div key={i}>
                <div className="flex justify-between items-baseline text-xs">
                  <span className="font-bold text-slate-900">{exp.role} @ {exp.company}</span>
                  <span className="text-[10px] text-slate-400 font-mono">{exp.startDate} – {exp.endDate}</span>
                </div>
                <ul className="list-disc list-inside mt-1 text-[11px] text-slate-600 space-y-1">
                  {exp.bullets.map((b, bi) => (
                    <li key={bi}>{b}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        {/* Projects */}
        <div className="mb-4">
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-900 border-b border-slate-200 pb-1 mb-2">
            // Key Systems & Projects
          </h2>
          <div className="space-y-2 font-sans">
            {data.projects.map((proj, i) => (
              <div key={i} className="text-[11px]">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-900">{proj.name}</span>
                  <span className="text-[10px] text-slate-500 font-mono">[{proj.technologies}]</span>
                </div>
                <p className="text-slate-600 mt-0.5">{proj.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Education */}
        <div>
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-900 border-b border-slate-200 pb-1 mb-1.5">
            // Education & Credentials
          </h2>
          {data.education.map((edu, i) => (
            <div key={i} className="flex justify-between text-[11px] font-sans">
              <span className="font-semibold text-slate-800">{edu.degree} — {edu.institution}</span>
              <span className="text-slate-400 font-mono text-[10px]">{edu.year}</span>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // Modern Compact / Executive / Clean Classic (Default High-Polished Style)
  return (
    <div
      className="w-full bg-white text-slate-800 p-8 shadow-sm font-sans text-xs leading-relaxed border-t-8"
      style={{ borderColor: accent, transform: `scale(${scale})`, transformOrigin: 'top center' }}
    >
      {/* Header */}
      <div className="border-b border-slate-200 pb-5 mb-5">
        <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">
          {data.fullName}
        </h1>
        <p className="text-sm font-semibold mt-1" style={{ color: accent }}>
          {data.jobTitle}
        </p>

        <div className="flex flex-wrap gap-x-4 gap-y-1 text-[11px] text-slate-500 mt-3">
          <span className="flex items-center gap-1">
            <Mail className="w-3.5 h-3.5" />
            {data.email}
          </span>
          <span className="flex items-center gap-1">
            <Phone className="w-3.5 h-3.5" />
            {data.phone}
          </span>
          <span className="flex items-center gap-1">
            <MapPin className="w-3.5 h-3.5" />
            {data.location}
          </span>
          {data.website && (
            <span className="flex items-center gap-1">
              <Globe className="w-3.5 h-3.5" />
              {data.website}
            </span>
          )}
        </div>
      </div>

      {/* Summary */}
      <div className="mb-5">
        <h2 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-1.5">
          Professional Profile
        </h2>
        <p className="text-slate-600 leading-relaxed">{data.summary}</p>
      </div>

      {/* Work Experience */}
      <div className="mb-5">
        <h2
          className="text-xs font-extrabold uppercase tracking-wider mb-3 pb-1 border-b"
          style={{ color: accent, borderColor: `${accent}33` }}
        >
          Work Experience
        </h2>
        <div className="space-y-4">
          {data.experience.map((exp, i) => (
            <div key={i}>
              <div className="flex justify-between items-baseline">
                <span className="font-bold text-slate-900 text-[13px]">{exp.role}</span>
                <span className="text-[11px] font-semibold text-slate-400">
                  {exp.startDate} – {exp.endDate}
                </span>
              </div>
              <p className="text-xs font-semibold text-slate-600">{exp.company} {exp.location ? `• ${exp.location}` : ''}</p>
              <ul className="list-disc list-inside mt-2 text-slate-600 space-y-1 text-xs">
                {exp.bullets.map((b, bi) => (
                  <li key={bi} className="leading-snug">{b}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>

      {/* Projects */}
      <div className="mb-5">
        <h2
          className="text-xs font-extrabold uppercase tracking-wider mb-3 pb-1 border-b"
          style={{ color: accent, borderColor: `${accent}33` }}
        >
          Key Projects & Technical Implementations
        </h2>
        <div className="space-y-3">
          {data.projects.map((proj, i) => (
            <div key={i}>
              <div className="flex items-center gap-2">
                <span className="font-bold text-slate-900 text-xs">{proj.name}</span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-slate-100 text-slate-600 font-medium">
                  {proj.technologies}
                </span>
              </div>
              <p className="text-slate-600 mt-1 text-xs">{proj.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Skills Matrix */}
      <div className="mb-5">
        <h2
          className="text-xs font-extrabold uppercase tracking-wider mb-2.5 pb-1 border-b"
          style={{ color: accent, borderColor: `${accent}33` }}
        >
          Core Skills & Technologies
        </h2>
        <div className="flex flex-wrap gap-1.5">
          {data.skills.technical.map((s, i) => (
            <span
              key={i}
              className="px-2.5 py-1 rounded-md text-[11px] font-semibold bg-slate-100 text-slate-800"
            >
              {s}
            </span>
          ))}
        </div>
      </div>

      {/* Education & Certifications */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <h2
            className="text-xs font-extrabold uppercase tracking-wider mb-2 pb-1 border-b"
            style={{ color: accent, borderColor: `${accent}33` }}
          >
            Education
          </h2>
          {data.education.map((edu, i) => (
            <div key={i}>
              <p className="font-bold text-slate-900 text-xs">{edu.degree}</p>
              <p className="text-slate-600 text-xs">{edu.institution}</p>
              <p className="text-[10px] text-slate-400 mt-0.5">{edu.year}</p>
            </div>
          ))}
        </div>

        {data.certifications && data.certifications.length > 0 && (
          <div>
            <h2
              className="text-xs font-extrabold uppercase tracking-wider mb-2 pb-1 border-b"
              style={{ color: accent, borderColor: `${accent}33` }}
            >
              Certifications
            </h2>
            <ul className="text-xs text-slate-600 space-y-1">
              {data.certifications.map((c, i) => (
                <li key={i}>• {c}</li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>
  );
};
