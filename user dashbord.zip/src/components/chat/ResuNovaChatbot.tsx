import React, { useState, useEffect, useRef } from 'react';
import {
  Sparkles,
  X,
  Send,
  Trash2,
  Bot,
  User as UserIcon,
  MessageSquare,
} from 'lucide-react';
import { api } from '../../services/api';
import { ChatMessage, AnalysisReport } from '../../types';

interface ResuNovaChatbotProps {
  latestReport?: AnalysisReport | null;
}

export const ResuNovaChatbot: React.FC<ResuNovaChatbotProps> = ({ latestReport }) => {
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    async function loadChat() {
      try {
        const res = await api.getChatHistory();
        if (res.messages && res.messages.length > 0) {
          setMessages(res.messages);
        } else {
          setMessages([
            {
              id: 'init-1',
              userId: 'sys',
              role: 'assistant',
              content:
                "👋 Hello! I'm your **ResuNova AI Assistant**.\n\nI can help you:\n• Improve your resume bullet points using the STAR method\n• Explain your ATS score and how to reach 90%+\n• Identify high-priority missing technical & soft skills\n• Formulate answers for technical and HR interview questions\n\nHow can I help you today?",
              timestamp: new Date().toISOString(),
            },
          ]);
        }
      } catch (err) {
        console.error('Failed to load chat history:', err);
      }
    }
    loadChat();
  }, []);

  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen]);

  const handleSend = async (customPrompt?: string) => {
    const textToSend = customPrompt || input;
    if (!textToSend.trim() || loading) return;

    const userMsg: ChatMessage = {
      id: 'local-' + Date.now(),
      userId: 'current',
      role: 'user',
      content: textToSend.trim(),
      timestamp: new Date().toISOString(),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!customPrompt) setInput('');
    setLoading(true);

    try {
      const context = latestReport
        ? {
            role: latestReport.jobRole,
            domain: latestReport.jobDomain,
            atsScore: latestReport.atsScore,
            missingSkills: latestReport.missingSkills?.highPriority || [],
          }
        : undefined;

      const res = await api.sendChatMessage(textToSend.trim(), context);

      const aiMsg: ChatMessage = {
        id: res.messageId || 'ai-' + Date.now(),
        userId: 'assistant',
        role: 'assistant',
        content: res.reply,
        timestamp: new Date().toISOString(),
      };

      setMessages((prev) => [...prev, aiMsg]);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          id: 'err-' + Date.now(),
          userId: 'assistant',
          role: 'assistant',
          content: 'I encountered an error connecting to the AI backend. Please try again in a moment.',
          timestamp: new Date().toISOString(),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleClear = async () => {
    try {
      await api.clearChat();
      setMessages([
        {
          id: 'init-new',
          userId: 'sys',
          role: 'assistant',
          content: 'Conversation cleared. How can I assist with your resume or career goals?',
          timestamp: new Date().toISOString(),
        },
      ]);
    } catch (err) {
      console.error('Clear chat error:', err);
    }
  };

  const quickPrompts = [
    'How do I improve my ATS score?',
    'Give me 3 impactful project bullets',
    'What skills are missing for my role?',
    'Give me a technical interview question',
  ];

  return (
    <div className="fixed bottom-6 right-6 z-40">
      {/* Floating Circular Trigger Icon */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="relative group p-4 rounded-full bg-gradient-to-r from-violet-600 via-indigo-600 to-blue-600 text-white shadow-2xl hover:scale-105 transition-all focus:outline-hidden ring-4 ring-violet-500/20"
          aria-label="Open ResuNova AI Assistant"
        >
          <Sparkles className="w-6 h-6 animate-pulse" />
          <span className="absolute -top-1 -right-1 flex h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-violet-400 opacity-75" />
            <span className="relative inline-flex rounded-full h-3 w-3 bg-violet-500" />
          </span>
          <span className="absolute right-full mr-3 top-1/2 -translate-y-1/2 px-3 py-1.5 rounded-xl bg-slate-900 text-white text-xs font-semibold whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity shadow-lg pointer-events-none">
            ResuNova AI Assistant
          </span>
        </button>
      )}

      {/* Chat Window */}
      {isOpen && (
        <div className="w-[370px] sm:w-[410px] h-[540px] max-h-[85vh] bg-white rounded-3xl shadow-2xl border border-slate-200/90 flex flex-col overflow-hidden animate-scaleUp">
          {/* Header */}
          <div className="px-5 py-4 bg-gradient-to-r from-[#0a0f1d] via-[#131b31] to-[#1e1b4b] text-white flex items-center justify-between border-b border-slate-800">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-violet-600/40 text-violet-300 border border-violet-500/30 flex items-center justify-center">
                <Bot className="w-5 h-5 text-violet-300" />
              </div>
              <div>
                <h4 className="font-bold text-sm text-white">ResuNova AI Assistant</h4>
                <div className="flex items-center gap-1.5 text-[11px] text-slate-300">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                  <span>Online • Career & ATS Advisor</span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-1">
              <button
                onClick={handleClear}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-white/10"
                title="Clear conversation"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setIsOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-white/10"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Messages Container */}
          <div className="flex-1 p-4 overflow-y-auto space-y-3.5 bg-slate-50/60 text-xs">
            {messages.map((m) => {
              const isAssistant = m.role === 'assistant';
              return (
                <div
                  key={m.id}
                  className={`flex items-start gap-2.5 ${isAssistant ? '' : 'flex-row-reverse'}`}
                >
                  <div
                    className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs shrink-0 ${
                      isAssistant
                        ? 'bg-violet-100 text-violet-700'
                        : 'bg-slate-900 text-white'
                    }`}
                  >
                    {isAssistant ? <Sparkles className="w-3.5 h-3.5" /> : <UserIcon className="w-3.5 h-3.5" />}
                  </div>

                  <div
                    className={`p-3.5 rounded-2xl max-w-[82%] leading-relaxed ${
                      isAssistant
                        ? 'bg-white text-slate-800 border border-slate-200/80 shadow-xs'
                        : 'bg-violet-600 text-white rounded-br-xs'
                    }`}
                  >
                    <p className="whitespace-pre-line">{m.content}</p>
                    <span
                      className={`block text-[9px] mt-1.5 ${
                        isAssistant ? 'text-slate-400' : 'text-violet-200 text-right'
                      }`}
                    >
                      {new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                </div>
              );
            })}

            {loading && (
              <div className="flex items-center gap-2 text-xs text-violet-600 p-2 font-medium">
                <Sparkles className="w-4 h-4 animate-spin text-violet-600" />
                <span>ResuNova AI is analyzing...</span>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Quick Prompts Chips */}
          <div className="px-3 py-2 bg-white border-t border-slate-100 flex gap-1.5 overflow-x-auto scrollbar-none">
            {quickPrompts.map((q, i) => (
              <button
                key={i}
                onClick={() => handleSend(q)}
                className="px-2.5 py-1 rounded-full bg-slate-100 hover:bg-violet-50 hover:text-violet-700 text-slate-600 text-[10px] font-medium whitespace-nowrap transition-colors"
              >
                {q}
              </button>
            ))}
          </div>

          {/* Input Box */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="p-3 bg-white border-t border-slate-200 flex items-center gap-2"
          >
            <input
              type="text"
              placeholder="Ask about resume keywords, interview tips..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              className="flex-1 px-3.5 py-2 text-xs border border-slate-200 rounded-xl focus:border-violet-500 focus:outline-hidden"
            />
            <button
              type="submit"
              disabled={!input.trim() || loading}
              className={`p-2 rounded-xl text-white transition-all ${
                input.trim() && !loading
                  ? 'bg-violet-600 hover:bg-violet-700 shadow-xs'
                  : 'bg-slate-200 text-slate-400 cursor-not-allowed'
              }`}
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
