import React, { useState, useEffect } from 'react';
import {
  FileText,
  Search,
  ExternalLink,
  User,
  Clock,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';
import { api } from '../../services/api';
import { AnalysisReport } from '../../types';
import { CircularScore } from '../common/CircularScore';

export const AdminResumeAnalyses: React.FC = () => {
  const [reports, setReports] = useState<AnalysisReport[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedReport, setSelectedReport] = useState<AnalysisReport | null>(null);

  useEffect(() => {
    async function loadAnalyses() {
      setLoading(true);
      try {
        const res = await api.getAdminAnalyses();
        setReports(res.reports || []);
      } catch (err) {
        console.error('Failed to load admin analyses:', err);
      } finally {
        setLoading(false);
      }
    }
    loadAnalyses();
  }, []);

  const filtered = reports.filter(
    (r) =>
      r.resumeFileName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.jobRole.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.jobDomain.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (r.userName && r.userName.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <div className="space-y-6 animate-fadeIn pb-16">
      {/* Top Search Toolbar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search by candidate name, resume file, or role..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-xl text-xs focus:border-violet-500 focus:outline-hidden"
          />
        </div>

        <span className="text-xs font-semibold text-slate-500">
          Total Platform Scans: <strong className="text-slate-900">{reports.length}</strong>
        </span>
      </div>

      {/* Analyses Table */}
      <div className="rounded-2xl bg-white border border-slate-200/80 shadow-xs overflow-hidden">
        {loading ? (
          <div className="py-20 text-center text-slate-400">Loading platform analyses...</div>
        ) : filtered.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/70 text-slate-500 font-semibold uppercase tracking-wider text-[11px]">
                  <th className="py-3.5 px-4">Applicant</th>
                  <th className="py-3.5 px-4">Resume File</th>
                  <th className="py-3.5 px-4">Target Role & Domain</th>
                  <th className="py-3.5 px-4 text-center">ATS Score</th>
                  <th className="py-3.5 px-4">Scanned On</th>
                  <th className="py-3.5 px-4 text-right">Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filtered.map((r) => (
                  <tr key={r.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3.5 px-4">
                      <p className="font-bold text-slate-900">{r.userName || 'Applicant'}</p>
                      <p className="text-[11px] text-slate-500">{r.userEmail || 'User'}</p>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-2">
                        <FileText className="w-4 h-4 text-violet-500 shrink-0" />
                        <span className="font-medium text-slate-800 truncate max-w-[170px]">
                          {r.resumeFileName}
                        </span>
                      </div>
                    </td>

                    <td className="py-3.5 px-4">
                      <p className="font-bold text-slate-800">{r.jobRole}</p>
                      <p className="text-[11px] text-slate-500">{r.jobDomain}</p>
                    </td>

                    <td className="py-3.5 px-4 text-center">
                      <span
                        className={`inline-flex items-center px-2.5 py-0.5 rounded-full font-extrabold text-xs ${
                          r.atsScore >= 80
                            ? 'bg-emerald-50 text-emerald-700'
                            : r.atsScore >= 70
                            ? 'bg-violet-50 text-violet-700'
                            : 'bg-amber-50 text-amber-700'
                        }`}
                      >
                        {r.atsScore}%
                      </span>
                    </td>

                    <td className="py-3.5 px-4 text-slate-500">
                      {new Date(r.createdAt).toLocaleDateString()}
                    </td>

                    <td className="py-3.5 px-4 text-right">
                      <button
                        onClick={() => setSelectedReport(r)}
                        className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold text-violet-700 bg-violet-50 hover:bg-violet-100"
                      >
                        <span>Audit</span>
                        <ExternalLink className="w-3 h-3" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="py-16 text-center text-slate-400">No analyses found.</div>
        )}
      </div>

      {/* Details Audit Modal */}
      {selectedReport && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
          <div className="max-w-2xl w-full bg-white rounded-2xl p-6 sm:p-8 shadow-2xl border border-slate-200 space-y-6 my-8">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-lg font-bold text-slate-900">
                  {selectedReport.jobRole} Analysis Audit
                </h3>
                <p className="text-xs text-slate-500">
                  Applicant: <strong>{selectedReport.userName}</strong> ({selectedReport.userEmail})
                </p>
              </div>
              <button
                onClick={() => setSelectedReport(null)}
                className="text-xs font-semibold px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200"
              >
                Close
              </button>
            </div>

            <div className="flex justify-center py-2">
              <CircularScore score={selectedReport.atsScore} size={130} />
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <span className="text-slate-500">Keyword Match:</span>
                <p className="font-bold text-slate-900">{selectedReport.scoreBreakdown.keywordMatch}%</p>
              </div>
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <span className="text-slate-500">Skills Match:</span>
                <p className="font-bold text-slate-900">{selectedReport.scoreBreakdown.skillsMatch}%</p>
              </div>
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <span className="text-slate-500">Structure Score:</span>
                <p className="font-bold text-slate-900">{selectedReport.scoreBreakdown.resumeStructure}%</p>
              </div>
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <span className="text-slate-500">Readability Score:</span>
                <p className="font-bold text-slate-900">{selectedReport.scoreBreakdown.readability}%</p>
              </div>
            </div>

            <div>
              <span className="text-xs font-bold text-slate-700">Validated Skills:</span>
              <div className="flex flex-wrap gap-1 mt-1.5">
                {selectedReport.matchedSkills.map((s, i) => (
                  <span key={i} className="px-2 py-0.5 rounded bg-emerald-50 text-emerald-800 text-[11px] font-semibold">
                    {s}
                  </span>
                ))}
              </div>
            </div>

            <div>
              <span className="text-xs font-bold text-slate-700">Missing Domain Skills:</span>
              <div className="flex flex-wrap gap-1 mt-1.5">
                {selectedReport.missingSkills?.highPriority?.map((s, i) => (
                  <span key={i} className="px-2 py-0.5 rounded bg-rose-50 text-rose-800 text-[11px] font-semibold">
                    {s}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
