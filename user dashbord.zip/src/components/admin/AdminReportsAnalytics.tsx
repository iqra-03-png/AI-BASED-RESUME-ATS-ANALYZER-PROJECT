import React, { useState, useEffect } from 'react';
import {
  TrendingUp,
  BarChart2,
  PieChart,
  Users,
  Layers,
  FileText,
  Award,
} from 'lucide-react';
import { api } from '../../services/api';

export const AdminReportsAnalytics: React.FC = () => {
  const [data, setData] = useState<{
    totalUsers: number;
    premiumUsers: number;
    totalAnalyses: number;
    totalTemplates: number;
    publishedTemplates: number;
    scoreBuckets: Record<string, number>;
  } | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    async function loadAnalytics() {
      setLoading(true);
      try {
        const res = await api.getAdminAnalytics();
        setData(res);
      } catch (err) {
        console.error('Failed to load admin analytics:', err);
      } finally {
        setLoading(false);
      }
    }
    loadAnalytics();
  }, []);

  return (
    <div className="space-y-8 animate-fadeIn pb-16">
      {/* Banner */}
      <div className="p-6 sm:p-8 rounded-2xl bg-gradient-to-r from-[#0a0f1d] via-[#131b31] to-[#1e1b4b] text-white shadow-xl border border-slate-800">
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-violet-500/20 text-violet-300 border border-violet-500/30 text-xs font-semibold mb-2">
          <TrendingUp className="w-3.5 h-3.5" />
          <span>Platform Intelligence & Conversions</span>
        </span>
        <h2 className="text-2xl font-bold tracking-tight">
          Reports & Platform Analytics
        </h2>
        <p className="text-xs text-slate-300 mt-1">
          Real-time metrics computed directly from database records.
        </p>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
            Registered Users
          </span>
          <p className="text-3xl font-extrabold text-slate-900 mt-2">{data?.totalUsers || 0}</p>
          <p className="text-xs text-indigo-600 font-semibold mt-1">
            {data?.premiumUsers || 0} Premium subscribers
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
            Total Completed Scans
          </span>
          <p className="text-3xl font-extrabold text-violet-600 mt-2">{data?.totalAnalyses || 0}</p>
          <p className="text-xs text-slate-400 mt-1">Evaluated resumes</p>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
            Template Catalog
          </span>
          <p className="text-3xl font-extrabold text-slate-900 mt-2">{data?.totalTemplates || 0}</p>
          <p className="text-xs text-emerald-600 font-semibold mt-1">
            {data?.publishedTemplates || 0} Live & published
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
            Conversion Rate
          </span>
          <p className="text-3xl font-extrabold text-amber-500 mt-2">
            {data?.totalUsers && data.totalUsers > 0
              ? `${Math.round(((data.premiumUsers || 0) / data.totalUsers) * 100)}%`
              : '0%'}
          </p>
          <p className="text-xs text-slate-400 mt-1">Premium entitlement ratio</p>
        </div>
      </div>

      {/* ATS Score Distribution Histogram */}
      <div className="p-6 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-4">
        <h3 className="font-bold text-slate-900 flex items-center gap-2">
          <BarChart2 className="w-5 h-5 text-violet-600" />
          <span>Platform-Wide ATS Score Distribution</span>
        </h3>
        <p className="text-xs text-slate-500">
          Distribution of candidate match scores across all executed scans:
        </p>

        {data?.scoreBuckets ? (
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 pt-2">
            {Object.entries(data.scoreBuckets).map(([bucket, count]) => (
              <div key={bucket} className="p-4 rounded-xl bg-slate-50 border border-slate-200/60 text-center">
                <span className="text-xs font-bold text-slate-500 uppercase">{bucket}% Match</span>
                <p className="text-2xl font-extrabold text-slate-900 mt-1">{count}</p>
                <p className="text-[10px] text-slate-400 mt-0.5">
                  {data.totalAnalyses > 0 ? `${Math.round((count / data.totalAnalyses) * 100)}% of scans` : '0%'}
                </p>
              </div>
            ))}
          </div>
        ) : (
          <div className="py-12 text-center text-slate-400 text-xs">No distribution data available.</div>
        )}
      </div>
    </div>
  );
};
