import React, { useState, useEffect } from 'react';
import {
  Layers,
  Plus,
  Search,
  Edit2,
  Copy,
  Trash2,
  Eye,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Lock,
  Sparkles,
  Zap,
} from 'lucide-react';
import { api } from '../../services/api';
import { ResumeTemplate } from '../../types';
import { sampleResumeData, ResumeTemplateRenderer } from '../templates/ResumeTemplateRenderer';
import { ResumeBuilderModal } from '../templates/ResumeBuilderModal';

export const AdminTemplateManagement: React.FC = () => {
  const [templates, setTemplates] = useState<ResumeTemplate[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'published' | 'draft' | 'unpublished'>('all');
  const [tierFilter, setTierFilter] = useState<'all' | 'free' | 'premium'>('all');

  // Edit / Create modal
  const [editingTemplate, setEditingTemplate] = useState<Partial<ResumeTemplate> | null>(null);
  const [isCreating, setIsCreating] = useState<boolean>(false);

  // Delete confirm
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  // Preview in Builder
  const [previewTemplate, setPreviewTemplate] = useState<ResumeTemplate | null>(null);

  const loadTemplates = async () => {
    setLoading(true);
    try {
      const res = await api.getAdminTemplates();
      setTemplates(res.templates || []);
    } catch (err) {
      console.error('Failed to load admin templates:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadTemplates();
  }, []);

  const handleTogglePublish = async (tmpl: ResumeTemplate) => {
    const nextStatus = tmpl.status === 'published' ? 'unpublished' : 'published';
    try {
      await api.updateAdminTemplate(tmpl.id, { status: nextStatus });
      await loadTemplates();
    } catch (err) {
      console.error('Publish toggle failed:', err);
    }
  };

  const handleDuplicate = async (tmpl: ResumeTemplate) => {
    try {
      await api.duplicateAdminTemplate(tmpl.id);
      await loadTemplates();
    } catch (err) {
      console.error('Duplicate failed:', err);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await api.deleteAdminTemplate(id);
      setDeleteConfirmId(null);
      await loadTemplates();
    } catch (err) {
      console.error('Delete failed:', err);
    }
  };

  const handleSaveModal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingTemplate || !editingTemplate.name) return;

    try {
      if (isCreating) {
        await api.createAdminTemplate(editingTemplate);
      } else if (editingTemplate.id) {
        await api.updateAdminTemplate(editingTemplate.id, editingTemplate);
      }
      setEditingTemplate(null);
      setIsCreating(false);
      await loadTemplates();
    } catch (err) {
      console.error('Save template failed:', err);
    }
  };

  // Filter logic
  const filtered = templates.filter((t) => {
    const matchesSearch =
      t.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.targetRole.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || t.status === statusFilter;
    const matchesTier = tierFilter === 'all' || t.tier === tierFilter;
    return matchesSearch && matchesStatus && matchesTier;
  });

  return (
    <div className="space-y-8 animate-fadeIn pb-16">
      {/* Top Banner */}
      <div className="p-6 sm:p-8 rounded-2xl bg-gradient-to-r from-[#0a0f1d] via-[#131b31] to-[#1e1b4b] text-white shadow-xl border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-violet-500/20 text-violet-300 border border-violet-500/30 text-xs font-semibold mb-2">
            <Layers className="w-3.5 h-3.5" />
            <span>Shared Admin & User Template Architecture</span>
          </span>
          <h2 className="text-2xl font-bold tracking-tight">
            Resume Templates Management
          </h2>
          <p className="text-xs text-slate-300 mt-1">
            Modifications, pricing, and publication statuses here automatically synchronize with the User Template Gallery.
          </p>
        </div>

        <button
          onClick={() => {
            setEditingTemplate({
              name: '',
              description: '',
              targetRole: 'Software & Web Engineers',
              tier: 'free',
              price: 0,
              status: 'published',
              layoutStyle: 'clean-classic',
              accentColor: '#7c3aed',
              fontFamily: 'Plus Jakarta Sans',
              tags: ['ATS-Friendly', 'Single-Column'],
            });
            setIsCreating(true);
          }}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs bg-violet-600 hover:bg-violet-700 text-white shadow-md transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>Create New Template</span>
        </button>
      </div>

      {/* Dynamic Filter & Search Toolbar */}
      <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search by name, role, or description..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-xl text-xs focus:border-violet-500 focus:outline-hidden"
            />
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Status Filter */}
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="px-3 py-2 border border-slate-300 rounded-xl text-xs font-semibold text-slate-700 bg-white"
            >
              <option value="all">All Statuses ({templates.length})</option>
              <option value="published">Published</option>
              <option value="draft">Draft</option>
              <option value="unpublished">Unpublished</option>
            </select>

            {/* Tier Filter */}
            <select
              value={tierFilter}
              onChange={(e) => setTierFilter(e.target.value as any)}
              className="px-3 py-2 border border-slate-300 rounded-xl text-xs font-semibold text-slate-700 bg-white"
            >
              <option value="all">All Tiers</option>
              <option value="free">Free Only</option>
              <option value="premium">Premium Only</option>
            </select>
          </div>
        </div>

        {/* Dynamic status counts pill row */}
        <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-slate-100 text-xs">
          <span className="text-slate-400 font-medium">Counts:</span>
          <span className="px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 font-semibold border border-emerald-100">
            Published: {templates.filter((t) => t.status === 'published').length}
          </span>
          <span className="px-2.5 py-0.5 rounded-full bg-amber-50 text-amber-700 font-semibold border border-amber-100">
            Draft: {templates.filter((t) => t.status === 'draft').length}
          </span>
          <span className="px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-600 font-semibold border border-slate-200">
            Unpublished: {templates.filter((t) => t.status === 'unpublished').length}
          </span>
        </div>
      </div>

      {/* Templates Grid */}
      {loading ? (
        <div className="py-20 text-center text-slate-400 space-y-2">
          <Layers className="w-8 h-8 animate-spin mx-auto text-violet-600" />
          <p className="text-xs font-medium">Loading templates repository...</p>
        </div>
      ) : filtered.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((tmpl) => {
            const isPub = tmpl.status === 'published';
            const isDraft = tmpl.status === 'draft';
            return (
              <div
                key={tmpl.id}
                className="rounded-2xl bg-white border border-slate-200/80 shadow-xs hover:shadow-md transition-all flex flex-col justify-between overflow-hidden"
              >
                <div>
                  {/* Miniature Live Template Canvas */}
                  <div
                    className="relative h-56 bg-slate-100 overflow-hidden border-b border-slate-100 flex items-start justify-center p-2 cursor-pointer"
                    onClick={() => setPreviewTemplate(tmpl)}
                  >
                    <div className="w-[420px] origin-top scale-[0.36] pointer-events-none rounded shadow-sm bg-white">
                      <ResumeTemplateRenderer template={tmpl} data={sampleResumeData} />
                    </div>

                    {/* Status Pill */}
                    <div className="absolute top-3 left-3 flex items-center gap-1.5">
                      <span
                        className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase shadow-xs ${
                          isPub
                            ? 'bg-emerald-600 text-white'
                            : isDraft
                            ? 'bg-amber-500 text-white'
                            : 'bg-slate-700 text-white'
                        }`}
                      >
                        {tmpl.status}
                      </span>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-white/90 text-slate-800 shadow-xs">
                        {tmpl.tier === 'free' ? 'Free' : `₹${tmpl.price}`}
                      </span>
                    </div>

                    <div className="absolute top-3 right-3">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setPreviewTemplate(tmpl);
                        }}
                        className="p-1.5 rounded-lg bg-white/90 text-slate-700 hover:bg-white shadow"
                        title="Live Preview"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Body Info */}
                  <div className="p-5 space-y-2">
                    <div className="flex items-center justify-between">
                      <h3 className="font-extrabold text-slate-900 text-base">{tmpl.name}</h3>
                      <span className="text-[11px] font-mono text-slate-400">{tmpl.layoutStyle}</span>
                    </div>

                    <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                      {tmpl.description}
                    </p>

                    <div className="text-xs pt-1">
                      <span className="font-semibold text-slate-400">Target Role:</span>{' '}
                      <span className="font-medium text-slate-800">{tmpl.targetRole}</span>
                    </div>
                  </div>
                </div>

                {/* Actions Bar */}
                <div className="p-4 border-t border-slate-100 bg-slate-50/50 flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => handleTogglePublish(tmpl)}
                      className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                        isPub
                          ? 'bg-amber-50 text-amber-700 hover:bg-amber-100'
                          : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                      }`}
                    >
                      {isPub ? 'Unpublish' : 'Publish'}
                    </button>

                    <button
                      onClick={() => handleDuplicate(tmpl)}
                      className="p-1.5 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-200/60"
                      title="Duplicate Template"
                    >
                      <Copy className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => {
                        setEditingTemplate(tmpl);
                        setIsCreating(false);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs transition-colors"
                    >
                      Edit
                    </button>

                    <button
                      onClick={() => setDeleteConfirmId(tmpl.id)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                      title="Delete Template"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="py-20 text-center text-slate-400">
          <p className="text-sm font-semibold text-slate-600">No templates match criteria</p>
        </div>
      )}

      {/* Edit / Create Template Modal */}
      {editingTemplate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
          <form
            onSubmit={handleSaveModal}
            className="max-w-xl w-full bg-white rounded-2xl p-6 sm:p-8 shadow-2xl border border-slate-200 space-y-4 my-8 animate-scaleUp"
          >
            <div className="border-b border-slate-100 pb-3">
              <h3 className="text-lg font-bold text-slate-900">
                {isCreating ? 'Create New Resume Template' : `Edit ${editingTemplate.name}`}
              </h3>
              <p className="text-xs text-slate-500">
                Shared template parameters will update for all users immediately upon saving.
              </p>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="font-semibold text-slate-700">Template Name *</label>
                <input
                  type="text"
                  required
                  value={editingTemplate.name || ''}
                  onChange={(e) => setEditingTemplate({ ...editingTemplate, name: e.target.value })}
                  className="w-full mt-1 p-2.5 border border-slate-300 rounded-xl focus:border-violet-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700">Description</label>
                <textarea
                  rows={2}
                  value={editingTemplate.description || ''}
                  onChange={(e) => setEditingTemplate({ ...editingTemplate, description: e.target.value })}
                  className="w-full mt-1 p-2.5 border border-slate-300 rounded-xl focus:border-violet-500 focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700">Target Role</label>
                  <input
                    type="text"
                    value={editingTemplate.targetRole || ''}
                    onChange={(e) => setEditingTemplate({ ...editingTemplate, targetRole: e.target.value })}
                    className="w-full mt-1 p-2.5 border border-slate-300 rounded-xl"
                  />
                </div>

                <div>
                  <label className="font-semibold text-slate-700">Layout Style</label>
                  <select
                    value={editingTemplate.layoutStyle || 'clean-classic'}
                    onChange={(e) => setEditingTemplate({ ...editingTemplate, layoutStyle: e.target.value as any })}
                    className="w-full mt-1 p-2.5 border border-slate-300 rounded-xl bg-white font-medium"
                  >
                    <option value="clean-classic">Clean Classic (Single Column)</option>
                    <option value="tech-minimal">Tech Minimal (Terminal Accent)</option>
                    <option value="modern-compact">Modern Compact (Metrics Header)</option>
                    <option value="creative-grid">Creative Grid (Full Stack)</option>
                    <option value="executive-dual">Executive Dual (Leadership)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="font-semibold text-slate-700">Tier</label>
                  <select
                    value={editingTemplate.tier || 'free'}
                    onChange={(e) => setEditingTemplate({ ...editingTemplate, tier: e.target.value as any })}
                    className="w-full mt-1 p-2.5 border border-slate-300 rounded-xl bg-white font-medium"
                  >
                    <option value="free">Free</option>
                    <option value="premium">Premium</option>
                  </select>
                </div>

                <div>
                  <label className="font-semibold text-slate-700">Price (₹ INR)</label>
                  <input
                    type="number"
                    min="0"
                    value={editingTemplate.price || 0}
                    onChange={(e) => setEditingTemplate({ ...editingTemplate, price: Number(e.target.value) })}
                    className="w-full mt-1 p-2.5 border border-slate-300 rounded-xl"
                  />
                </div>

                <div>
                  <label className="font-semibold text-slate-700">Publication Status</label>
                  <select
                    value={editingTemplate.status || 'published'}
                    onChange={(e) => setEditingTemplate({ ...editingTemplate, status: e.target.value as any })}
                    className="w-full mt-1 p-2.5 border border-slate-300 rounded-xl bg-white font-medium"
                  >
                    <option value="published">Published</option>
                    <option value="draft">Draft</option>
                    <option value="unpublished">Unpublished</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700">Accent Color</label>
                  <input
                    type="color"
                    value={editingTemplate.accentColor || '#7c3aed'}
                    onChange={(e) => setEditingTemplate({ ...editingTemplate, accentColor: e.target.value })}
                    className="w-full h-10 p-1 border border-slate-300 rounded-xl cursor-pointer"
                  />
                </div>

                <div>
                  <label className="font-semibold text-slate-700">Tags (comma separated)</label>
                  <input
                    type="text"
                    value={editingTemplate.tags?.join(', ') || ''}
                    onChange={(e) =>
                      setEditingTemplate({
                        ...editingTemplate,
                        tags: e.target.value.split(',').map((t) => t.trim()).filter(Boolean),
                      })
                    }
                    className="w-full mt-1 p-2.5 border border-slate-300 rounded-xl"
                  />
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setEditingTemplate(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 text-xs font-semibold text-white bg-violet-600 hover:bg-violet-700 rounded-xl shadow-xs"
              >
                Save Template
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="max-w-md w-full bg-white rounded-2xl p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center gap-3">
              <div className="p-3 rounded-full bg-rose-100 text-rose-600">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-base font-bold text-slate-900">Delete Template?</h4>
                <p className="text-xs text-slate-500">
                  This will remove the template from both the Admin and User galleries.
                </p>
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <button
                onClick={() => setDeleteConfirmId(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
              >
                Cancel
              </button>
              <button
                onClick={() => handleDelete(deleteConfirmId)}
                className="px-4 py-2 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-xl"
              >
                Confirm Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Live Builder Modal Preview */}
      {previewTemplate && (
        <ResumeBuilderModal
          template={previewTemplate}
          onClose={() => setPreviewTemplate(null)}
        />
      )}
    </div>
  );
};
