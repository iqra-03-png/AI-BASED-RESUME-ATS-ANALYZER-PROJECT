import React, { useEffect, useState } from 'react';
import {
  Users,
  FileText,
  Briefcase,
  Sliders,
  TrendingUp,
  Award,
  Layers,
  ArrowRight,
  Clock,
  CheckCircle2,
  AlertCircle,
  ShieldCheck,
} from 'lucide-react';
import { api } from '../../services/api';
import { AnalysisReport, User } from '../../types';

interface AdminDashboardViewProps {
  onNavigate: (view: string) => void;
}

export const AdminDashboardView: React.FC<AdminDashboardViewProps> = ({ onNavigate }) => {
  const [stats, setStats] = useState<{
    totalUsers: number;
    totalResumes: number;
    totalAnalyses: number;
    totalDomains: number;
    totalSkills: number;
    avgScore: number;
    popularDomains: Array<{ name: string; count: number }>;
    recentReports: AnalysisReport[];
    recentUsers: User[];
  } | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    async function loadStats() {
      setLoading(true);
      try {
        const res = await api.getAdminOverview();
        setStats(res);
      } catch (err) {
        console.error('Failed to load admin overview:', err);
      } finally {
        setLoading(false);
      }
    }
    loadStats();
  }, []);

  return (
    <div className="space-y-8 animate-fadeIn pb-16">
      {/* Admin Operations Hero */}
      <div className="p-6 sm:p-8 rounded-2xl bg-gradient-to-r from-[#0a0f1d] via-[#131b31] to-[#1e1b4b] text-white shadow-xl border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-xs font-semibold mb-2">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>ResuNova Platform Operations Console</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Administrator Overview
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-xl">
            Live metrics from persistent database storage. Manage candidate roles, configure domain criteria, and curate the shared template catalog.
          </p>
        </div>

        <div className="flex flex-wrap gap-2.5">
          <button
            onClick={() => onNavigate('admin-templates')}
            className="px-4 py-2.5 rounded-xl bg-violet-600 hover:bg-violet-700 text-white font-bold text-xs shadow-md transition-colors"
          >
            Manage Templates
          </button>
          <button
            onClick={() => onNavigate('admin-users')}
            className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs border border-slate-700 transition-colors"
          >
            User Accounts
          </button>
        </div>
      </div>

      {/* 4 Overview Statistics Cards (Phase 11 requirement) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Total Users
            </span>
            <div className="p-2.5 rounded-xl bg-indigo-50 text-indigo-600">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4">
            <span className="text-3xl font-extrabold text-slate-900 tracking-tight">
              {loading ? '...' : stats?.totalUsers || 0}
            </span>
            <p className="text-xs text-slate-400 mt-1">Registered applicant accounts</p>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Total Resumes Analyzed
            </span>
            <div className="p-2.5 rounded-xl bg-violet-50 text-violet-600">
              <FileText className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4">
            <span className="text-3xl font-extrabold text-slate-900 tracking-tight">
              {loading ? '...' : stats?.totalAnalyses || 0}
            </span>
            <p className="text-xs text-slate-400 mt-1">Platform-wide ATS executions</p>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Active Job Domains
            </span>
            <div className="p-2.5 rounded-xl bg-blue-50 text-blue-600">
              <Briefcase className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4">
            <span className="text-3xl font-extrabold text-slate-900 tracking-tight">
              {loading ? '...' : stats?.totalDomains || 0}
            </span>
            <p className="text-xs text-slate-400 mt-1">Configured career verticals</p>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Skills Taxonomy
            </span>
            <div className="p-2.5 rounded-xl bg-emerald-50 text-emerald-600">
              <Sliders className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4">
            <span className="text-3xl font-extrabold text-slate-900 tracking-tight">
              {loading ? '...' : stats?.totalSkills || 0}
            </span>
            <p className="text-xs text-slate-400 mt-1">Mapped ATS skills in dictionary</p>
          </div>
        </div>
      </div>

      {/* Main Grid: Popular Domains & Recent Platform Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Popular Domains */}
        <div className="lg:col-span-5 p-6 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-slate-900 text-sm">Most Popular Job Domains</h3>
            <button
              onClick={() => onNavigate('admin-domains')}
              className="text-xs font-semibold text-violet-600 hover:text-violet-700"
            >
              Manage Domains
            </button>
          </div>

          {stats?.popularDomains && stats.popularDomains.length > 0 ? (
            <div className="space-y-3 pt-1">
              {stats.popularDomains.map((dom, i) => (
                <div
                  key={i}
                  className="p-3.5 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-between text-xs"
                >
                  <div className="flex items-center gap-2.5">
                    <span className="w-5 h-5 rounded-md bg-violet-100 text-violet-700 font-bold flex items-center justify-center text-[10px]">
                      {i + 1}
                    </span>
                    <span className="font-bold text-slate-800">{dom.name}</span>
                  </div>
                  <span className="font-semibold text-slate-600 px-2 py-0.5 rounded-full bg-white border border-slate-200">
                    {dom.count} {dom.count === 1 ? 'scan' : 'scans'}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-xs text-slate-400 py-6 text-center">
              No domain scan data recorded yet.
            </p>
          )}
        </div>

        {/* Recent Platform Analyses */}
        <div className="lg:col-span-7 p-6 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-slate-900 text-sm">Recent Platform Analyses</h3>
              <p className="text-xs text-slate-500">Live applicant scans executed across ResuNova</p>
            </div>
            <button
              onClick={() => onNavigate('admin-analyses')}
              className="text-xs font-semibold text-violet-600 hover:text-violet-700"
            >
              View All
            </button>
          </div>

          {stats?.recentReports && stats.recentReports.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-400 font-medium">
                    <th className="py-2.5 px-2">Target Role</th>
                    <th className="py-2.5 px-2">Domain</th>
                    <th className="py-2.5 px-2 text-center">Score</th>
                    <th className="py-2.5 px-2 text-right">Time</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {stats.recentReports.map((r) => (
                    <tr key={r.id} className="hover:bg-slate-50/70">
                      <td className="py-3 px-2 font-semibold text-slate-900">{r.jobRole}</td>
                      <td className="py-3 px-2 text-slate-600">{r.jobDomain}</td>
                      <td className="py-3 px-2 text-center">
                        <span
                          className={`font-bold px-2 py-0.5 rounded-full text-[11px] ${
                            r.atsScore >= 80
                              ? 'bg-emerald-50 text-emerald-700'
                              : r.atsScore >= 70
                              ? 'bg-violet-50 text-violet-700'
                              : 'bg-amber-50 text-amber-700'
                          }`}
                        >
                          {r.atsScore}%
                        </span>
                      </td>
                      <td className="py-3 px-2 text-right text-slate-400 text-[11px]">
                        {new Date(r.createdAt).toLocaleDateString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="text-xs text-slate-400 py-8 text-center">No analyses recorded yet.</p>
          )}
        </div>
      </div>
    </div>
  );
};
