import React, { useState, useEffect } from 'react';
import {
  Briefcase,
  Plus,
  Edit2,
  Trash2,
  CheckCircle,
  Search,
  Sparkles,
} from 'lucide-react';
import { api } from '../../services/api';
import { JobDomain } from '../../types';

export const AdminDomainManagement: React.FC = () => {
  const [domains, setDomains] = useState<JobDomain[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [editingDomain, setEditingDomain] = useState<Partial<JobDomain> | null>(null);
  const [isCreating, setIsCreating] = useState<boolean>(false);

  const loadDomains = async () => {
    setLoading(true);
    try {
      const res = await api.getAdminDomains();
      setDomains(res.domains || []);
    } catch (err) {
      console.error('Failed to load domains:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadDomains();
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingDomain?.name) return;

    try {
      if (isCreating) {
        await api.createAdminDomain(editingDomain);
      } else if (editingDomain.id) {
        await api.updateAdminDomain(editingDomain.id, editingDomain);
      }
      setEditingDomain(null);
      setIsCreating(false);
      await loadDomains();
    } catch (err) {
      console.error('Save domain error:', err);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await api.deleteAdminDomain(id);
      await loadDomains();
    } catch (err) {
      console.error('Delete domain error:', err);
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn pb-16">
      {/* Top Banner */}
      <div className="p-6 sm:p-8 rounded-2xl bg-gradient-to-r from-[#0a0f1d] via-[#131b31] to-[#1e1b4b] text-white shadow-xl border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30 text-xs font-semibold mb-2">
            <Briefcase className="w-3.5 h-3.5" />
            <span>Job Domain Architecture</span>
          </span>
          <h2 className="text-2xl font-bold tracking-tight">
            Job Domains & Target Roles
          </h2>
          <p className="text-xs text-slate-300 mt-1">
            Domains configured here are directly selectable by applicants during resume upload & ATS scoring.
          </p>
        </div>

        <button
          onClick={() => {
            setEditingDomain({
              name: '',
              description: '',
              roles: ['Lead Specialist'],
              recommendedSkills: ['Core Fundamentals'],
            });
            setIsCreating(true);
          }}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs bg-violet-600 hover:bg-violet-700 text-white shadow-md transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Domain</span>
        </button>
      </div>

      {/* Domain Cards */}
      {loading ? (
        <div className="py-20 text-center text-slate-400">Loading job domains...</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {domains.map((dom) => (
            <div
              key={dom.id}
              className="p-6 rounded-2xl bg-white border border-slate-200/80 shadow-xs flex flex-col justify-between space-y-4"
            >
              <div>
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 rounded-xl bg-violet-50 text-violet-600">
                      <Briefcase className="w-5 h-5" />
                    </div>
                    <h3 className="font-extrabold text-slate-900 text-base">{dom.name}</h3>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => {
                        setEditingDomain(dom);
                        setIsCreating(false);
                      }}
                      className="p-1.5 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-100"
                      title="Edit Domain"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDelete(dom.id)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50"
                      title="Delete Domain"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <p className="text-xs text-slate-500 mt-3 leading-relaxed">
                  {dom.description}
                </p>

                {/* Roles */}
                <div className="mt-4 space-y-1.5">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                    Associated Job Roles ({dom.roles?.length || 0}):
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {dom.roles?.map((r, i) => (
                      <span key={i} className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-slate-100 text-slate-800">
                        {r}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Skills */}
                <div className="mt-4 space-y-1.5">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                    Recommended ATS Benchmarks:
                  </span>
                  <div className="flex flex-wrap gap-1">
                    {dom.recommendedSkills?.map((s, i) => (
                      <span key={i} className="px-2 py-0.5 rounded text-[10px] font-medium bg-violet-50 text-violet-700">
                        {s}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Edit / Create Modal */}
      {editingDomain && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <form
            onSubmit={handleSave}
            className="max-w-lg w-full bg-white rounded-2xl p-6 sm:p-8 shadow-2xl border border-slate-200 space-y-4"
          >
            <h3 className="text-lg font-bold text-slate-900">
              {isCreating ? 'Create Job Domain' : 'Edit Job Domain'}
            </h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="font-semibold text-slate-700">Domain Name *</label>
                <input
                  type="text"
                  required
                  value={editingDomain.name || ''}
                  onChange={(e) => setEditingDomain({ ...editingDomain, name: e.target.value })}
                  className="w-full mt-1 p-2.5 border border-slate-300 rounded-xl focus:border-violet-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700">Description</label>
                <textarea
                  rows={2}
                  value={editingDomain.description || ''}
                  onChange={(e) => setEditingDomain({ ...editingDomain, description: e.target.value })}
                  className="w-full mt-1 p-2.5 border border-slate-300 rounded-xl focus:border-violet-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700">Job Roles (Comma separated)</label>
                <input
                  type="text"
                  value={editingDomain.roles?.join(', ') || ''}
                  onChange={(e) =>
                    setEditingDomain({
                      ...editingDomain,
                      roles: e.target.value.split(',').map((r) => r.trim()).filter(Boolean),
                    })
                  }
                  className="w-full mt-1 p-2.5 border border-slate-300 rounded-xl"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700">Recommended Skills (Comma separated)</label>
                <input
                  type="text"
                  value={editingDomain.recommendedSkills?.join(', ') || ''}
                  onChange={(e) =>
                    setEditingDomain({
                      ...editingDomain,
                      recommendedSkills: e.target.value.split(',').map((s) => s.trim()).filter(Boolean),
                    })
                  }
                  className="w-full mt-1 p-2.5 border border-slate-300 rounded-xl"
                />
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setEditingDomain(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 text-xs font-semibold text-white bg-violet-600 hover:bg-violet-700 rounded-xl shadow-xs"
              >
                Save Domain
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
