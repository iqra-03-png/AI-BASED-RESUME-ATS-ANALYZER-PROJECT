import React, { useState, useEffect } from 'react';
import {
  Sliders,
  Plus,
  Edit2,
  Trash2,
  Search,
  Filter,
} from 'lucide-react';
import { api } from '../../services/api';
import { SkillItem, JobDomain } from '../../types';

export const AdminSkillManagement: React.FC = () => {
  const [skills, setSkills] = useState<SkillItem[]>([]);
  const [domains, setDomains] = useState<JobDomain[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [categoryFilter, setCategoryFilter] = useState<'all' | 'technical' | 'soft' | 'tool'>('all');

  const [editingSkill, setEditingSkill] = useState<Partial<SkillItem> | null>(null);
  const [isCreating, setIsCreating] = useState<boolean>(false);

  const loadSkills = async () => {
    setLoading(true);
    try {
      const [skRes, domRes] = await Promise.all([
        api.getAdminSkills(),
        api.getAdminDomains(),
      ]);
      setSkills(skRes.skills || []);
      setDomains(domRes.domains || []);
    } catch (err) {
      console.error('Failed to load skills:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSkills();
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingSkill?.name || !editingSkill?.domain) return;

    try {
      if (isCreating) {
        await api.createAdminSkill(editingSkill);
      } else if (editingSkill.id) {
        await api.updateAdminSkill(editingSkill.id, editingSkill);
      }
      setEditingSkill(null);
      setIsCreating(false);
      await loadSkills();
    } catch (err) {
      console.error('Save skill error:', err);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await api.deleteAdminSkill(id);
      await loadSkills();
    } catch (err) {
      console.error('Delete skill error:', err);
    }
  };

  const filtered = skills.filter((s) => {
    const matchesSearch =
      s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.domain.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || s.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="space-y-6 animate-fadeIn pb-16">
      {/* Top Banner */}
      <div className="p-6 sm:p-8 rounded-2xl bg-gradient-to-r from-[#0a0f1d] via-[#131b31] to-[#1e1b4b] text-white shadow-xl border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-semibold mb-2">
            <Sliders className="w-3.5 h-3.5" />
            <span>Taxonomy Engine</span>
          </span>
          <h2 className="text-2xl font-bold tracking-tight">
            Skills Management
          </h2>
          <p className="text-xs text-slate-300 mt-1">
            Categorized skills and priority levels used for calculating ATS keyword coverage.
          </p>
        </div>

        <button
          onClick={() => {
            setEditingSkill({
              name: '',
              category: 'technical',
              domain: domains[0]?.name || 'Web Development',
              priority: 'high',
            });
            setIsCreating(true);
          }}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs bg-violet-600 hover:bg-violet-700 text-white shadow-md transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>Add Skill</span>
        </button>
      </div>

      {/* Toolbar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search skills by name or domain..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-xl text-xs focus:border-violet-500 focus:outline-hidden"
          />
        </div>

        <div className="flex items-center gap-2">
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value as any)}
            className="px-3 py-2 border border-slate-300 rounded-xl text-xs font-semibold text-slate-700 bg-white"
          >
            <option value="all">All Categories ({skills.length})</option>
            <option value="technical">Technical</option>
            <option value="soft">Soft Competencies</option>
            <option value="tool">Tools & Platforms</option>
          </select>
        </div>
      </div>

      {/* Table */}
      <div className="rounded-2xl bg-white border border-slate-200/80 shadow-xs overflow-hidden">
        {loading ? (
          <div className="py-20 text-center text-slate-400">Loading skills...</div>
        ) : filtered.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/70 text-slate-500 font-semibold uppercase tracking-wider text-[11px]">
                  <th className="py-3.5 px-4">Skill Name</th>
                  <th className="py-3.5 px-4">Category</th>
                  <th className="py-3.5 px-4">Associated Domain</th>
                  <th className="py-3.5 px-4 text-center">Priority</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filtered.map((skill) => (
                  <tr key={skill.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3.5 px-4 font-bold text-slate-900">{skill.name}</td>
                    <td className="py-3.5 px-4">
                      <span className="capitalize px-2 py-0.5 rounded text-[11px] font-semibold bg-slate-100 text-slate-700">
                        {skill.category}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-slate-600 font-medium">{skill.domain}</td>
                    <td className="py-3.5 px-4 text-center">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                          skill.priority === 'high'
                            ? 'bg-rose-50 text-rose-700 border border-rose-200'
                            : skill.priority === 'medium'
                            ? 'bg-amber-50 text-amber-700 border border-amber-200'
                            : 'bg-slate-100 text-slate-600'
                        }`}
                      >
                        {skill.priority}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => {
                            setEditingSkill(skill);
                            setIsCreating(false);
                          }}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-slate-900"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDelete(skill.id)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="py-16 text-center text-slate-400">No skills match query.</div>
        )}
      </div>

      {/* Edit / Create Skill Modal */}
      {editingSkill && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <form
            onSubmit={handleSave}
            className="max-w-md w-full bg-white rounded-2xl p-6 shadow-2xl border border-slate-200 space-y-4"
          >
            <h3 className="text-lg font-bold text-slate-900">
              {isCreating ? 'Add New Skill' : 'Edit Skill'}
            </h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="font-semibold text-slate-700">Skill Name *</label>
                <input
                  type="text"
                  required
                  value={editingSkill.name || ''}
                  onChange={(e) => setEditingSkill({ ...editingSkill, name: e.target.value })}
                  className="w-full mt-1 p-2.5 border border-slate-300 rounded-xl focus:border-violet-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700">Category</label>
                <select
                  value={editingSkill.category || 'technical'}
                  onChange={(e) => setEditingSkill({ ...editingSkill, category: e.target.value as any })}
                  className="w-full mt-1 p-2.5 border border-slate-300 rounded-xl bg-white font-medium"
                >
                  <option value="technical">Technical</option>
                  <option value="soft">Soft Competency</option>
                  <option value="tool">Tool / Platform</option>
                </select>
              </div>

              <div>
                <label className="font-semibold text-slate-700">Associated Domain *</label>
                <select
                  value={editingSkill.domain || domains[0]?.name || ''}
                  onChange={(e) => setEditingSkill({ ...editingSkill, domain: e.target.value })}
                  className="w-full mt-1 p-2.5 border border-slate-300 rounded-xl bg-white font-medium"
                >
                  {domains.map((d) => (
                    <option key={d.id} value={d.name}>
                      {d.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="font-semibold text-slate-700">ATS Priority</label>
                <select
                  value={editingSkill.priority || 'high'}
                  onChange={(e) => setEditingSkill({ ...editingSkill, priority: e.target.value as any })}
                  className="w-full mt-1 p-2.5 border border-slate-300 rounded-xl bg-white font-medium"
                >
                  <option value="high">High Priority</option>
                  <option value="medium">Medium Priority</option>
                  <option value="low">Low Priority</option>
                </select>
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setEditingSkill(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 text-xs font-semibold text-white bg-violet-600 hover:bg-violet-700 rounded-xl shadow-xs"
              >
                Save Skill
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
