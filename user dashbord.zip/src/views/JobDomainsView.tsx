import React, { useState, useMemo } from 'react';
import {
  Briefcase,
  Search,
  Plus,
  Layers,
  Zap,
  Edit2,
  Trash2,
  ChevronRight,
  Code,
  Globe,
  Database,
  Cpu,
  ShieldAlert,
  Cloud,
  Layout,
  Sliders,
  CheckCircle2,
  AlertTriangle,
  ArrowLeft
} from 'lucide-react';
import { ResuNovaStore } from '../services/storage';
import { JobDomain, JobRole, Skill, SkillImportance, RoleLevel } from '../types';
import { Modal } from '../components/common/Modal';
import { ConfirmDialog } from '../components/common/ConfirmDialog';
import { useToast } from '../context/ToastContext';

interface JobDomainsViewProps {
  initialDomainId?: string | null;
  onClearInitialDomain?: () => void;
}

export const JobDomainsView: React.FC<JobDomainsViewProps> = ({
  initialDomainId,
  onClearInitialDomain
}) => {
  const [domains, setDomains] = useState<JobDomain[]>(() => ResuNovaStore.getDomains());
  const [roles, setRoles] = useState<JobRole[]>(() => ResuNovaStore.getRoles());
  const [skills, setSkills] = useState<Skill[]>(() => ResuNovaStore.getSkills());
  const [searchQuery, setSearchQuery] = useState('');

  // Selected Domain for Roles Drill-Down
  const [activeDomain, setActiveDomain] = useState<JobDomain | null>(() => {
    if (initialDomainId) {
      return ResuNovaStore.getDomains().find(d => d.id === initialDomainId) || null;
    }
    return null;
  });

  React.useEffect(() => {
    if (initialDomainId) {
      const found = domains.find(d => d.id === initialDomainId);
      if (found) setActiveDomain(found);
    }
  }, [initialDomainId, domains]);

  // Modals
  const [isAddDomainOpen, setIsAddDomainOpen] = useState(false);
  const [domainToEdit, setDomainToEdit] = useState<JobDomain | null>(null);
  const [domainToDelete, setDomainToDelete] = useState<JobDomain | null>(null);

  // Role Modals
  const [isAddRoleOpen, setIsAddRoleOpen] = useState(false);
  const [roleToEdit, setRoleToEdit] = useState<JobRole | null>(null);
  const [roleToDelete, setRoleToDelete] = useState<JobRole | null>(null);

  // Form states for Domain
  const [domainName, setDomainName] = useState('');
  const [domainDesc, setDomainDesc] = useState('');
  const [domainIcon, setDomainIcon] = useState('Briefcase');

  // Form states for Role
  const [roleTitle, setRoleTitle] = useState('');
  const [roleDesc, setRoleDesc] = useState('');
  const [roleLevel, setRoleLevel] = useState<RoleLevel>('Mid');
  const [selectedSkillIds, setSelectedSkillIds] = useState<string[]>([]);

  const toast = useToast();

  const reloadAll = () => {
    setDomains(ResuNovaStore.getDomains());
    setRoles(ResuNovaStore.getRoles());
    setSkills(ResuNovaStore.getSkills());
  };

  const domainIconsMap: Record<string, React.ReactNode> = {
    Code: <Code className="w-5 h-5" />,
    Globe: <Globe className="w-5 h-5" />,
    Database: <Database className="w-5 h-5" />,
    Cpu: <Cpu className="w-5 h-5" />,
    ShieldAlert: <ShieldAlert className="w-5 h-5" />,
    Cloud: <Cloud className="w-5 h-5" />,
    Layers: <Layers className="w-5 h-5" />,
    Layout: <Layout className="w-5 h-5" />,
    Briefcase: <Briefcase className="w-5 h-5" />,
  };

  const filteredDomains = useMemo(() => {
    return domains.filter(d =>
      d.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.description.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [domains, searchQuery]);

  // Associated roles for selected domain
  const currentDomainRoles = useMemo(() => {
    if (!activeDomain) return [];
    return roles.filter(r => r.domainId === activeDomain.id);
  }, [roles, activeDomain]);

  // Domain Actions
  const handleOpenAddDomain = () => {
    setDomainName('');
    setDomainDesc('');
    setDomainIcon('Code');
    setIsAddDomainOpen(true);
  };

  const handleOpenEditDomain = (domain: JobDomain) => {
    setDomainToEdit(domain);
    setDomainName(domain.name);
    setDomainDesc(domain.description);
    setDomainIcon(domain.iconName);
  };

  const handleSaveDomain = (e: React.FormEvent) => {
    e.preventDefault();
    if (!domainName.trim()) {
      toast.warning('Validation', 'Domain name cannot be blank.');
      return;
    }

    if (domainToEdit) {
      ResuNovaStore.updateDomain(domainToEdit.id, {
        name: domainName.trim(),
        description: domainDesc.trim(),
        iconName: domainIcon
      });
      toast.success('Domain Updated', `Changes to "${domainName}" saved.`);
      setDomainToEdit(null);
    } else {
      ResuNovaStore.addDomain({
        name: domainName.trim(),
        description: domainDesc.trim(),
        iconName: domainIcon
      });
      toast.success('Domain Created', `Domain "${domainName}" added successfully.`);
      setIsAddDomainOpen(false);
    }
    reloadAll();
  };

  const handleDeleteDomainConfirm = () => {
    if (!domainToDelete) return;
    const res = ResuNovaStore.deleteDomain(domainToDelete.id);
    if (!res.success) {
      toast.error('Deletion Blocked', res.error || 'Cannot delete domain with active roles.');
    } else {
      toast.success('Domain Deleted', `"${domainToDelete.name}" was removed.`);
      if (activeDomain?.id === domainToDelete.id) {
        setActiveDomain(null);
      }
      reloadAll();
    }
    setDomainToDelete(null);
  };

  // Role Actions
  const handleOpenAddRole = () => {
    if (!activeDomain) return;
    setRoleTitle('');
    setRoleDesc('');
    setRoleLevel('Mid');
    setSelectedSkillIds([]);
    setIsAddRoleOpen(true);
  };

  const handleOpenEditRole = (role: JobRole) => {
    setRoleToEdit(role);
    setRoleTitle(role.title);
    setRoleDesc(role.description);
    setRoleLevel(role.level);
    setSelectedSkillIds(role.requiredSkills.map(s => s.skillId));
  };

  const handleSaveRole = (e: React.FormEvent) => {
    e.preventDefault();
    if (!roleTitle.trim() || !activeDomain) return;

    const assignedSkills = selectedSkillIds.map(sId => {
      const sk = skills.find(s => s.id === sId);
      return {
        skillId: sId,
        skillName: sk?.name || sId,
        importance: sk?.importance || ('High' as SkillImportance),
        weight: sk?.weight || 2.5
      };
    });

    if (roleToEdit) {
      ResuNovaStore.updateRole(roleToEdit.id, {
        title: roleTitle.trim(),
        description: roleDesc.trim(),
        level: roleLevel,
        requiredSkills: assignedSkills
      });
      toast.success('Role Updated', `Job role "${roleTitle}" updated.`);
      setRoleToEdit(null);
    } else {
      ResuNovaStore.addRole({
        domainId: activeDomain.id,
        domainName: activeDomain.name,
        title: roleTitle.trim(),
        description: roleDesc.trim(),
        level: roleLevel,
        requiredSkills: assignedSkills,
        status: 'active'
      });
      toast.success('Role Added', `Job role "${roleTitle}" assigned to ${activeDomain.name}.`);
      setIsAddRoleOpen(false);
    }
    reloadAll();
  };

  const handleDeleteRoleConfirm = () => {
    if (!roleToDelete) return;
    ResuNovaStore.deleteRole(roleToDelete.id);
    toast.success('Role Removed', `Job role "${roleToDelete.title}" deleted.`);
    setRoleToDelete(null);
    reloadAll();
  };

  const toggleSkillSelection = (skillId: string) => {
    setSelectedSkillIds(prev =>
      prev.includes(skillId) ? prev.filter(id => id !== skillId) : [...prev, skillId]
    );
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* If drilling down into a domain's roles */}
      {activeDomain ? (
        <div className="space-y-6">
          {/* Back button and Domain header */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <button
                onClick={() => setActiveDomain(null)}
                className="p-2 rounded-xl text-slate-500 hover:text-[#6D5DFB] hover:bg-[#F1EEFF] transition-colors"
                title="Back to all domains"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <div className="w-10 h-10 rounded-xl bg-[#F1EEFF] text-[#6D5DFB] flex items-center justify-center shrink-0">
                {domainIconsMap[activeDomain.iconName] || <Briefcase className="w-5 h-5" />}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-lg font-bold text-[#111827]">{activeDomain.name}</h2>
                  <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-50 text-[#16A34A] border border-emerald-200">
                    Active Track
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-0.5">{activeDomain.description}</p>
              </div>
            </div>

            <div className="flex items-center gap-2 self-end sm:self-auto">
              <button
                onClick={handleOpenAddRole}
                className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-white bg-[#6D5DFB] hover:bg-[#5B4BE3] rounded-xl transition-colors shadow-xs"
              >
                <Plus className="w-4 h-4" />
                <span>Add Job Role</span>
              </button>
            </div>
          </div>

          {/* Roles Table/List */}
          <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-[#111827]">
                  Associated Job Roles ({currentDomainRoles.length})
                </h3>
                <p className="text-xs text-[#6B7280]">
                  Required skills define the resume ATS scoring benchmark
                </p>
              </div>
            </div>

            {currentDomainRoles.length === 0 ? (
              <div className="p-12 text-center text-slate-400">
                <p className="text-sm font-semibold text-slate-700 mb-1">No Job Roles Assigned</p>
                <p className="text-xs mb-4">Add your first job role under {activeDomain.name}.</p>
                <button
                  onClick={handleOpenAddRole}
                  className="px-3.5 py-1.5 text-xs font-bold text-[#6D5DFB] bg-[#F1EEFF] rounded-lg"
                >
                  Create Job Role
                </button>
              </div>
            ) : (
              <div className="divide-y divide-slate-100">
                {currentDomainRoles.map(role => (
                  <div key={role.id} className="p-5 hover:bg-slate-50/70 transition-colors">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="text-sm font-bold text-[#111827]">{role.title}</h4>
                          <span className={`px-2 py-0.5 text-[10px] font-bold rounded-md font-mono ${
                            role.level === 'Junior' ? 'bg-blue-50 text-blue-700' :
                            role.level === 'Mid' ? 'bg-indigo-50 text-indigo-700' :
                            role.level === 'Senior' ? 'bg-purple-50 text-[#8B5CF6]' :
                            'bg-rose-50 text-rose-700'
                          }`}>
                            {role.level} Level
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 mt-1 max-w-2xl">{role.description}</p>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          onClick={() => handleOpenEditRole(role)}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-[#6D5DFB] hover:bg-[#F1EEFF] transition-colors"
                          title="Edit role & assigned skills"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => setRoleToDelete(role)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-[#DC2626] hover:bg-red-50 transition-colors"
                          title="Delete role"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    {/* Assigned Required Skills */}
                    <div className="mt-3 pt-3 border-t border-slate-100">
                      <span className="text-[11px] font-semibold text-slate-400 block mb-1.5">
                        Required Skills ({role.requiredSkills.length}):
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {role.requiredSkills.map(req => (
                          <span
                            key={req.skillId}
                            className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs bg-slate-50 border border-slate-200 text-[#1F2937]"
                          >
                            <span className="font-medium">{req.skillName}</span>
                            <span className="text-[10px] font-mono text-slate-400 font-bold">
                              {req.weight}x
                            </span>
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      ) : (
        /* Domains List / Grid View */
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                placeholder="Search job domains or descriptions..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full bg-white border border-slate-200 rounded-xl pl-9 pr-3 py-2 text-xs text-[#1F2937] placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
              />
            </div>

            <button
              onClick={handleOpenAddDomain}
              className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-white bg-[#6D5DFB] hover:bg-[#5B4BE3] rounded-xl transition-colors shadow-xs shrink-0 self-start sm:self-auto"
            >
              <Plus className="w-4 h-4" />
              <span>Add Job Domain</span>
            </button>
          </div>

          {/* Domains Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {filteredDomains.map(domain => (
              <div
                key={domain.id}
                className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs hover:border-[#6D5DFB]/40 hover:shadow-md transition-all flex flex-col justify-between group"
              >
                <div>
                  <div className="flex items-start justify-between mb-3">
                    <div className="w-10 h-10 rounded-xl bg-[#F1EEFF] text-[#6D5DFB] flex items-center justify-center shrink-0 shadow-xs group-hover:scale-105 transition-transform">
                      {domainIconsMap[domain.iconName] || <Briefcase className="w-5 h-5" />}
                    </div>
                    <div className="flex items-center gap-1">
                      <button
                        onClick={e => {
                          e.stopPropagation();
                          handleOpenEditDomain(domain);
                        }}
                        className="p-1 rounded-lg text-slate-400 hover:text-[#6D5DFB] hover:bg-slate-100 transition-colors"
                        title="Edit domain"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={e => {
                          e.stopPropagation();
                          setDomainToDelete(domain);
                        }}
                        className="p-1 rounded-lg text-slate-400 hover:text-[#DC2626] hover:bg-red-50 transition-colors"
                        title="Delete domain"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  <h3 className="text-base font-bold text-[#111827] group-hover:text-[#6D5DFB] transition-colors leading-snug">
                    {domain.name}
                  </h3>
                  <p className="text-xs text-slate-500 mt-1 line-clamp-2 leading-relaxed">
                    {domain.description}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100">
                  <div className="flex items-center justify-between text-xs text-slate-500 font-mono mb-3">
                    <span className="flex items-center gap-1 font-semibold text-slate-700">
                      <Layers className="w-3.5 h-3.5 text-[#6D5DFB]" />
                      {domain.rolesCount} Roles
                    </span>
                    <span className="flex items-center gap-1">
                      <Zap className="w-3.5 h-3.5 text-amber-500" />
                      {domain.skillsCount} Skills
                    </span>
                  </div>

                  <button
                    onClick={() => setActiveDomain(domain)}
                    className="w-full py-1.5 px-3 text-xs font-bold text-[#6D5DFB] bg-[#F1EEFF] hover:bg-[#E8E4FF] rounded-xl transition-colors flex items-center justify-center gap-1"
                  >
                    <span>Inspect Roles & Skills</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Add / Edit Domain Modal */}
      <Modal
        isOpen={isAddDomainOpen || !!domainToEdit}
        onClose={() => {
          setIsAddDomainOpen(false);
          setDomainToEdit(null);
        }}
        title={domainToEdit ? 'Edit Job Domain' : 'Create Job Domain'}
        subtitle="Defines career discipline and skill taxonomy grouping in ResuNova."
        maxWidth="md"
        footer={
          <>
            <button
              type="button"
              onClick={() => {
                setIsAddDomainOpen(false);
                setDomainToEdit(null);
              }}
              className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSaveDomain}
              className="px-4 py-2 text-xs font-semibold text-white bg-[#6D5DFB] hover:bg-[#5B4BE3] rounded-lg transition-colors"
            >
              {domainToEdit ? 'Save Changes' : 'Create Domain'}
            </button>
          </>
        }
      >
        <form onSubmit={handleSaveDomain} className="space-y-3.5">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Domain Name *
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Embedded Systems & IoT"
              value={domainName}
              onChange={e => setDomainName(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-[#1F2937] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Description
            </label>
            <textarea
              rows={3}
              placeholder="Brief description of the domain scope and engineering requirements..."
              value={domainDesc}
              onChange={e => setDomainDesc(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-[#1F2937] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Icon Symbol
            </label>
            <select
              value={domainIcon}
              onChange={e => setDomainIcon(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-[#1F2937] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
            >
              <option value="Code">Code (Software)</option>
              <option value="Globe">Globe (Web)</option>
              <option value="Database">Database (Data)</option>
              <option value="Cpu">Cpu (AI / ML)</option>
              <option value="ShieldAlert">Shield (Cybersecurity)</option>
              <option value="Cloud">Cloud (Infrastructure)</option>
              <option value="Layers">Layers (Backend / Enterprise)</option>
              <option value="Layout">Layout (UI / UX)</option>
              <option value="Briefcase">Briefcase (General)</option>
            </select>
          </div>
        </form>
      </Modal>

      {/* Add / Edit Job Role Modal */}
      <Modal
        isOpen={isAddRoleOpen || !!roleToEdit}
        onClose={() => {
          setIsAddRoleOpen(false);
          setRoleToEdit(null);
        }}
        title={roleToEdit ? `Edit Job Role: ${roleToEdit.title}` : `Add Job Role to ${activeDomain?.name}`}
        subtitle="Assign required skills to calibrate ATS mathematical scoring weights."
        maxWidth="2xl"
        footer={
          <>
            <button
              type="button"
              onClick={() => {
                setIsAddRoleOpen(false);
                setRoleToEdit(null);
              }}
              className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSaveRole}
              className="px-4 py-2 text-xs font-semibold text-white bg-[#6D5DFB] hover:bg-[#5B4BE3] rounded-lg transition-colors"
            >
              {roleToEdit ? 'Save Role Changes' : 'Create Role'}
            </button>
          </>
        }
      >
        <form onSubmit={handleSaveRole} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Role Title *
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Lead Kubernetes Platform Engineer"
                value={roleTitle}
                onChange={e => setRoleTitle(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-[#1F2937] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Seniority Level
              </label>
              <select
                value={roleLevel}
                onChange={e => setRoleLevel(e.target.value as RoleLevel)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-[#1F2937] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
              >
                <option value="Junior">Junior (0 - 2 yrs)</option>
                <option value="Mid">Mid Level (2 - 5 yrs)</option>
                <option value="Senior">Senior (5+ yrs)</option>
                <option value="Lead">Lead / Architect</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Role Description & Candidate Expectations
            </label>
            <textarea
              rows={2}
              placeholder="What core architectural responsibilities and system scales are required?"
              value={roleDesc}
              onChange={e => setRoleDesc(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-[#1F2937] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
            />
          </div>

          {/* Skill Assignment Picker */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-xs font-bold text-slate-700">
                Assign Required Skills ({selectedSkillIds.length} Selected)
              </label>
              <span className="text-[11px] text-slate-400">
                Click to toggle requirement
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-48 overflow-y-auto p-2 border border-slate-200 rounded-xl bg-slate-50">
              {skills.map(skill => {
                const isSelected = selectedSkillIds.includes(skill.id);
                return (
                  <button
                    type="button"
                    key={skill.id}
                    onClick={() => toggleSkillSelection(skill.id)}
                    className={`p-2 rounded-lg text-left text-xs transition-colors border flex items-center justify-between gap-1.5 ${
                      isSelected
                        ? 'bg-[#F1EEFF] border-[#6D5DFB] text-[#6D5DFB] font-semibold'
                        : 'bg-white border-slate-200 text-slate-700 hover:border-slate-300'
                    }`}
                  >
                    <span className="truncate">{skill.name}</span>
                    <span className="font-mono text-[10px] text-slate-400 shrink-0">
                      {skill.weight}w
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </form>
      </Modal>

      {/* Delete Domain Confirm Dialog */}
      <ConfirmDialog
        isOpen={!!domainToDelete}
        onClose={() => setDomainToDelete(null)}
        onConfirm={handleDeleteDomainConfirm}
        title="Delete Job Domain?"
        message={`Are you sure you want to delete "${domainToDelete?.name}"? The system prevents deletion if active job roles or analyses depend on this domain.`}
        confirmText="Confirm Delete"
        variant="danger"
      />

      {/* Delete Role Confirm Dialog */}
      <ConfirmDialog
        isOpen={!!roleToDelete}
        onClose={() => setRoleToDelete(null)}
        onConfirm={handleDeleteRoleConfirm}
        title="Delete Job Role?"
        message={`Are you sure you want to delete "${roleToDelete?.title}"?`}
        confirmText="Delete Role"
        variant="danger"
      />
    </div>
  );
};
