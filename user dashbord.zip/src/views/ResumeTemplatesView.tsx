import React, { useState, useMemo } from 'react';
import {
  FileText,
  Search,
  Eye,
  Check,
  Tag,
  Plus,
  Copy,
  Edit3,
  Trash2,
  EyeOff,
  Globe,
  Lock,
  ArrowRight,
  Sparkles
} from 'lucide-react';
import { ResuNovaStore } from '../services/storage';
import { ResumeTemplate, TemplateStatus } from '../types';
import { renderResumeTemplate, DEFAULT_SAMPLE_RESUME } from '../components/templates/ResumeTemplateRenderers';
import { ResumeEditor } from '../components/templates/ResumeEditor';
import { TemplateFormModal } from '../components/templates/TemplateFormModal';
import { TemplateConfirmDialog, ConfirmActionType } from '../components/templates/TemplateConfirmDialog';
import { Modal } from '../components/common/Modal';
import { useToast } from '../context/ToastContext';

export const ResumeTemplatesView: React.FC = () => {
  const [templates, setTemplates] = useState<ResumeTemplate[]>(() => ResuNovaStore.getTemplates());

  // Filter state
  const [tierFilter, setTierFilter] = useState<'all' | 'free' | 'premium'>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'Published' | 'Draft' | 'Unpublished'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Interactive Resume Editor mode
  const [editingResumeTemplate, setEditingResumeTemplate] = useState<ResumeTemplate | null>(null);

  // Template Form Modal (Create / Edit)
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const [formInitialTemplate, setFormInitialTemplate] = useState<ResumeTemplate | null>(null);

  // Confirmation Dialog (Unpublish / Safe Delete)
  const [confirmDialogState, setConfirmDialogState] = useState<{
    isOpen: boolean;
    actionType: ConfirmActionType;
    template: ResumeTemplate | null;
  }>({
    isOpen: false,
    actionType: 'unpublish',
    template: null
  });

  // Preview Modal
  const [previewTemplate, setPreviewTemplate] = useState<ResumeTemplate | null>(null);

  const toast = useToast();

  const refreshTemplates = () => {
    setTemplates(ResuNovaStore.getTemplates());
  };

  // Dynamic automatic calculation of template counts
  // Total Templates = all templates (Published, Draft, Unpublished)
  const totalCount = templates.length;
  // Published (Live) = templates currently live and available to users
  const publishedCount = templates.filter(t => t.status === 'Published').length;
  // Drafts / In-Progress = templates saved as drafts
  const draftCount = templates.filter(t => t.status === 'Draft').length;
  // Unpublished = templates previously active that are hidden
  const unpublishedCount = templates.filter(t => t.status === 'Unpublished').length;

  // Filtered Templates based on tier, status, and search query
  const filteredTemplates = useMemo(() => {
    return templates.filter(t => {
      // Tier filter (All, Free, Premium)
      const matchesTier =
        tierFilter === 'all' ||
        (tierFilter === 'free' && t.tier === 'free') ||
        (tierFilter === 'premium' && t.tier === 'premium');

      // Status filter (All, Published, Draft, Unpublished)
      const matchesStatus =
        statusFilter === 'all' ||
        t.status === statusFilter;

      // Search query across title, category, audience, description, roles
      const q = searchQuery.toLowerCase().trim();
      const matchesSearch =
        !q ||
        t.title.toLowerCase().includes(q) ||
        t.category.toLowerCase().includes(q) ||
        t.intendedUser.toLowerCase().includes(q) ||
        t.description.toLowerCase().includes(q) ||
        (t.intendedRoles && t.intendedRoles.some(r => r.toLowerCase().includes(q)));

      return matchesTier && matchesStatus && matchesSearch;
    });
  }, [templates, tierFilter, statusFilter, searchQuery]);

  // --- Administrative Handlers ---

  const handleOpenCreateModal = () => {
    setFormInitialTemplate(null);
    setIsFormModalOpen(true);
  };

  const handleOpenEditModal = (template: ResumeTemplate) => {
    setFormInitialTemplate(template);
    setIsFormModalOpen(true);
  };

  const handleSaveTemplate = (templateData: Partial<ResumeTemplate>, targetStatus: TemplateStatus) => {
    if (formInitialTemplate) {
      // Update existing template
      const updated = ResuNovaStore.updateTemplate(formInitialTemplate.id, {
        ...templateData,
        status: targetStatus
      });
      if (updated) {
        toast.success(
          'Template Updated',
          `"${updated.title}" saved successfully as ${targetStatus}.`
        );
      }
    } else {
      // Create new template
      const created = ResuNovaStore.addTemplate({
        title: templateData.title || 'Untitled Template',
        category: templateData.category || 'Software Engineering',
        domainId: 'dom-1',
        domainName: 'Software Engineering',
        description: templateData.description || '',
        status: targetStatus,
        format: 'PDF',
        accentColor: templateData.accentColor || '#6D5DFB',
        themeFont: templateData.themeFont || 'sans',
        tier: templateData.tier || 'free',
        priceInr: templateData.priceInr || 0,
        intendedUser: templateData.intendedUser || 'Software Engineers',
        intendedRoles: templateData.intendedRoles || ['Software Engineer'],
        layout: templateData.layout || 'single-column',
        enabledSections: templateData.enabledSections,
        features: templateData.features || ['ATS Parser Compliant', 'Clean Layout'],
        templateKey: templateData.templateKey || 'custom-single',
        previewSnippet: templateData.previewSnippet || {
          name: DEFAULT_SAMPLE_RESUME.fullName,
          targetRole: 'Software Engineer',
          summary: DEFAULT_SAMPLE_RESUME.summary,
          skillsSample: DEFAULT_SAMPLE_RESUME.technicalSkills.slice(0, 5),
          experienceSample: DEFAULT_SAMPLE_RESUME.experience[0]?.bullets[0] || ''
        }
      });
      toast.success(
        'Template Created',
        `"${created.title}" successfully added as ${targetStatus}.`
      );
    }
    refreshTemplates();
  };

  const handleDuplicate = (template: ResumeTemplate) => {
    const copy = ResuNovaStore.duplicateTemplate(template.id);
    if (copy) {
      toast.info('Template Cloned', `Created draft copy: "${copy.title}"`);
      refreshTemplates();
    }
  };

  const handleTogglePublish = (template: ResumeTemplate) => {
    if (template.status === 'Published') {
      // Unpublishing a live published template requires a confirmation dialog
      setConfirmDialogState({
        isOpen: true,
        actionType: 'unpublish',
        template
      });
    } else {
      // Publishing a draft or unpublished template requires confirmation as requested
      setConfirmDialogState({
        isOpen: true,
        actionType: 'publish',
        template
      });
    }
  };

  const handleRequestDelete = (template: ResumeTemplate) => {
    setConfirmDialogState({
      isOpen: true,
      actionType: 'delete',
      template
    });
  };

  const handleConfirmDialogAction = () => {
    const { actionType, template } = confirmDialogState;
    if (!template) return;

    if (actionType === 'publish') {
      const pub = ResuNovaStore.publishTemplate(template.id);
      if (pub) {
        toast.success('Template Published', `"${pub.title}" is now published.`);
        refreshTemplates();
      }
    } else if (actionType === 'unpublish') {
      const res = ResuNovaStore.unpublishTemplate(template.id);
      if (res) {
        toast.warning(
          'Template Unpublished',
          `"${template.title}" unpublished. Status changed to Unpublished.`
        );
        refreshTemplates();
      }
    } else if (actionType === 'delete') {
      const result = ResuNovaStore.deleteTemplate(template.id);
      if (result.success) {
        if (result.softDeleted) {
          toast.info('Template Archived', result.warning || `"${template.title}" archived safely.`);
        } else {
          toast.success('Template Deleted', `"${template.title}" removed.`);
        }
        refreshTemplates();
      }
    }
  };

  // If admin is currently testing/using the template in the live Resume Editor
  if (editingResumeTemplate) {
    return (
      <ResumeEditor
        template={editingResumeTemplate}
        onBackToGallery={() => setEditingResumeTemplate(null)}
      />
    );
  }

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* 1. Header Toolbar with Create New Template Button */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
        <div>
          <h1 className="text-2xl font-extrabold text-[#111827] tracking-tight">
            Resume Templates
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Manage, create, and configure Free and Premium ATS resume templates.
          </p>
        </div>

        <button
          type="button"
          onClick={handleOpenCreateModal}
          className="px-4 py-2.5 text-xs font-bold text-white bg-gradient-to-r from-[#6D5DFB] to-[#5B4BE3] hover:from-[#5B4BE3] hover:to-[#4C3BCF] rounded-xl transition-all shadow-md shadow-[#6D5DFB]/25 flex items-center justify-center gap-1.5 shrink-0 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4 stroke-[2.5]" />
          <span>Create New Template</span>
        </button>
      </div>

      {/* 2. Top Summary KPI Cards (Clickable dynamic filters calculated strictly from storage) */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {/* Total Templates */}
        <button
          type="button"
          onClick={() => setStatusFilter('all')}
          className={`text-left p-4 rounded-2xl border transition-all cursor-pointer ${
            statusFilter === 'all'
              ? 'bg-violet-50/40 border-[#6D5DFB] ring-2 ring-[#6D5DFB]/30 shadow-xs'
              : 'bg-white border-slate-200/80 hover:border-slate-300 hover:shadow-xs'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-slate-400 block text-[11px] font-semibold uppercase tracking-wider">
              Total Templates
            </span>
            {statusFilter === 'all' && (
              <span className="w-2 h-2 rounded-full bg-[#6D5DFB]" />
            )}
          </div>
          <span className="text-2xl font-extrabold font-mono text-[#111827] mt-1 block">
            {totalCount}
          </span>
          <span className="text-[11px] text-slate-500 mt-0.5 block">
            All system templates
          </span>
        </button>

        {/* Published (Live) */}
        <button
          type="button"
          onClick={() => setStatusFilter('Published')}
          className={`text-left p-4 rounded-2xl border transition-all cursor-pointer ${
            statusFilter === 'Published'
              ? 'bg-emerald-50/40 border-emerald-500 ring-2 ring-emerald-500/30 shadow-xs'
              : 'bg-white border-slate-200/80 hover:border-slate-300 hover:shadow-xs'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-emerald-600 block text-[11px] font-semibold uppercase tracking-wider">
              Published (Live)
            </span>
            {statusFilter === 'Published' && (
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
            )}
          </div>
          <span className="text-2xl font-extrabold font-mono text-emerald-600 mt-1 block">
            {publishedCount}
          </span>
          <span className="text-[11px] text-slate-500 mt-0.5 block">
            Active in User Catalogue
          </span>
        </button>

        {/* Drafts / In-Progress */}
        <button
          type="button"
          onClick={() => setStatusFilter('Draft')}
          className={`text-left p-4 rounded-2xl border transition-all cursor-pointer ${
            statusFilter === 'Draft'
              ? 'bg-amber-50/40 border-amber-500 ring-2 ring-amber-500/30 shadow-xs'
              : 'bg-white border-slate-200/80 hover:border-slate-300 hover:shadow-xs'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-amber-600 block text-[11px] font-semibold uppercase tracking-wider">
              Drafts / In-Progress
            </span>
            {statusFilter === 'Draft' && (
              <span className="w-2 h-2 rounded-full bg-amber-500" />
            )}
          </div>
          <span className="text-2xl font-extrabold font-mono text-amber-600 mt-1 block">
            {draftCount}
          </span>
          <span className="text-[11px] text-slate-500 mt-0.5 block">
            Saved drafts & staging
          </span>
        </button>

        {/* Unpublished */}
        <button
          type="button"
          onClick={() => setStatusFilter('Unpublished')}
          className={`text-left p-4 rounded-2xl border transition-all cursor-pointer ${
            statusFilter === 'Unpublished'
              ? 'bg-slate-100/70 border-slate-500 ring-2 ring-slate-400/30 shadow-xs'
              : 'bg-white border-slate-200/80 hover:border-slate-300 hover:shadow-xs'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-slate-500 block text-[11px] font-semibold uppercase tracking-wider">
              Unpublished
            </span>
            {statusFilter === 'Unpublished' && (
              <span className="w-2 h-2 rounded-full bg-slate-500" />
            )}
          </div>
          <span className="text-2xl font-extrabold font-mono text-slate-700 mt-1 block">
            {unpublishedCount}
          </span>
          <span className="text-[11px] text-slate-500 mt-0.5 block">
            Hidden from catalogue
          </span>
        </button>
      </div>

      {/* 3. Filter and Search Bar */}
      <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3.5">
        <div className="flex flex-wrap items-center gap-2">
          {/* Tier Filter: All, Free, Premium */}
          <div className="flex items-center p-1 bg-slate-100 rounded-xl border border-slate-200/60 text-xs">
            <button
              type="button"
              onClick={() => setTierFilter('all')}
              className={`px-3 py-1.5 font-bold rounded-lg transition-all ${
                tierFilter === 'all'
                  ? 'bg-white text-[#6D5DFB] shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All Tiers
            </button>
            <button
              type="button"
              onClick={() => setTierFilter('free')}
              className={`px-3 py-1.5 font-bold rounded-lg transition-all flex items-center gap-1.5 ${
                tierFilter === 'free'
                  ? 'bg-white text-emerald-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
              <span>Free</span>
            </button>
            <button
              type="button"
              onClick={() => setTierFilter('premium')}
              className={`px-3 py-1.5 font-bold rounded-lg transition-all flex items-center gap-1.5 ${
                tierFilter === 'premium'
                  ? 'bg-white text-[#6D5DFB] shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Lock className="w-3 h-3 text-[#6D5DFB]" />
              <span>Premium</span>
            </button>
          </div>

          {/* Status Filter: All, Published, Draft, Unpublished */}
          <div className="flex items-center p-1 bg-slate-100 rounded-xl border border-slate-200/60 text-xs">
            <button
              type="button"
              onClick={() => setStatusFilter('all')}
              className={`px-2.5 py-1.5 font-bold rounded-lg transition-all ${
                statusFilter === 'all'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All Status
            </button>
            <button
              type="button"
              onClick={() => setStatusFilter('Published')}
              className={`px-2.5 py-1.5 font-bold rounded-lg transition-all text-emerald-700 ${
                statusFilter === 'Published'
                  ? 'bg-white shadow-xs font-extrabold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Published
            </button>
            <button
              type="button"
              onClick={() => setStatusFilter('Draft')}
              className={`px-2.5 py-1.5 font-bold rounded-lg transition-all text-amber-700 ${
                statusFilter === 'Draft'
                  ? 'bg-white shadow-xs font-extrabold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Draft
            </button>
            <button
              type="button"
              onClick={() => setStatusFilter('Unpublished')}
              className={`px-2.5 py-1.5 font-bold rounded-lg transition-all text-slate-600 ${
                statusFilter === 'Unpublished'
                  ? 'bg-white shadow-xs font-extrabold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Unpublished
            </button>
          </div>
        </div>

        {/* Search Input */}
        <div className="relative min-w-[240px] flex-1 max-w-sm">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            placeholder="Search templates, intended roles..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full bg-white border border-slate-200 rounded-xl pl-9 pr-3 py-2 text-xs text-[#1F2937] placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
          />
        </div>
      </div>

      {/* 4. Templates Gallery Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredTemplates.map(template => {
          const isFree = template.tier === 'free';
          const isPublished = template.status === 'Published';
          const isDraft = template.status === 'Draft';

          return (
            <div
              key={template.id}
              className={`bg-white rounded-2xl border shadow-xs overflow-hidden flex flex-col justify-between transition-all group ${
                isDraft
                  ? 'border-amber-200/90 bg-amber-50/20'
                  : template.status === 'Unpublished'
                  ? 'border-slate-200/80 opacity-90'
                  : 'border-slate-200/80 hover:border-[#6D5DFB]/40 hover:shadow-md'
              }`}
            >
              <div>
                {/* Miniature HTML/CSS Preview Card */}
                <div
                  className="p-3 bg-slate-50 border-b border-slate-100 cursor-pointer relative overflow-hidden group-hover:bg-slate-100/70 transition-colors"
                  onClick={() => setPreviewTemplate(template)}
                  title="Click to preview template"
                >
                  <div className="h-56 bg-white rounded-lg shadow-xs border border-slate-200/90 overflow-hidden relative pointer-events-none select-none">
                    {/* Rendered miniature template component */}
                    <div className="scale-[0.40] origin-top-left w-[250%] -mr-[150%]">
                      {renderResumeTemplate(template.templateKey, DEFAULT_SAMPLE_RESUME, true, {
                        accentColor: template.accentColor,
                        layout: template.layout,
                        font: template.themeFont,
                        enabledSections: template.enabledSections
                      })}
                    </div>

                    {/* Gradient Fade Overlay at bottom */}
                    <div className="absolute inset-x-0 bottom-0 h-14 bg-gradient-to-t from-white via-white/80 to-transparent flex items-end justify-center pb-2">
                      <span className="text-[10px] font-bold text-slate-600 bg-white/90 backdrop-blur-xs px-2.5 py-0.5 rounded-full border border-slate-200 shadow-xs">
                        Click to Preview
                      </span>
                    </div>

                    {/* Status Badge (Draft, Published, Unpublished) */}
                    <div className="absolute top-2 left-2">
                      {isPublished ? (
                        <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-emerald-600 text-white shadow-xs flex items-center gap-1">
                          <Check className="w-3 h-3 stroke-[3]" />
                          Published
                        </span>
                      ) : isDraft ? (
                        <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-amber-500 text-white shadow-xs">
                          Draft
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-slate-600 text-white shadow-xs flex items-center gap-1">
                          <EyeOff className="w-3 h-3" />
                          Unpublished
                        </span>
                      )}
                    </div>

                    {/* Layout indicator badge */}
                    <div className="absolute top-2 right-2 bg-[#111827]/80 backdrop-blur-xs text-white px-2 py-0.5 rounded-md text-[10px] font-mono shadow-xs">
                      {template.layout === 'two-column' ? '2-Column' : '1-Column'}
                    </div>
                  </div>
                </div>

                {/* Card Content */}
                <div className="p-5 space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="text-base font-extrabold text-[#111827] truncate">
                      {template.title}
                    </h3>

                    {/* Tier badge */}
                    {isFree ? (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-emerald-50 text-emerald-700 border border-emerald-200 shrink-0">
                        Free
                      </span>
                    ) : (
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-[#F1EEFF] text-[#6D5DFB] border border-[#6D5DFB]/30 shrink-0 flex items-center gap-1">
                        <Lock className="w-3 h-3" />
                        Premium &bull; ₹{template.priceInr || 299}
                      </span>
                    )}
                  </div>

                  <div className="text-[11px] font-semibold text-[#6D5DFB] flex items-center gap-1.5">
                    <Tag className="w-3.5 h-3.5 shrink-0" />
                    <span className="truncate">{template.intendedUser}</span>
                  </div>

                  <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                    {template.description}
                  </p>

                  {/* Highlights tag pills */}
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {template.features.slice(0, 3).map((feat, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 text-[10px] font-medium"
                      >
                        {feat}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Card Footer Actions (Full Admin Controls with zero purchase requirements) */}
              <div className="px-5 pb-5 pt-3 border-t border-slate-100 space-y-2">
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setPreviewTemplate(template)}
                    className="flex-1 py-1.5 px-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors flex items-center justify-center gap-1"
                    title="Preview template"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>Preview</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleOpenEditModal(template)}
                    className="flex-1 py-1.5 px-2 text-xs font-semibold text-[#6D5DFB] bg-[#F1EEFF] hover:bg-[#E8E4FF] rounded-lg transition-colors flex items-center justify-center gap-1"
                    title="Edit template fields and styling"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                    <span>Edit</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleDuplicate(template)}
                    className="py-1.5 px-2.5 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
                    title="Duplicate as new Draft"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>

                  <button
                    type="button"
                    onClick={() => handleRequestDelete(template)}
                    className="py-1.5 px-2.5 text-xs font-semibold text-red-600 hover:text-red-700 bg-red-50 hover:bg-red-100 rounded-lg transition-colors"
                    title="Delete template"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Publish / Unpublish Toggle Action + Test in Editor */}
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleTogglePublish(template)}
                    className={`flex-1 py-1.5 px-3 text-xs font-bold rounded-lg transition-colors flex items-center justify-center gap-1.5 ${
                      isPublished
                        ? 'text-amber-800 bg-amber-50 hover:bg-amber-100 border border-amber-200'
                        : 'text-white bg-emerald-600 hover:bg-emerald-700 shadow-xs'
                    }`}
                  >
                    {isPublished ? (
                      <>
                        <EyeOff className="w-3.5 h-3.5" />
                        <span>Unpublish</span>
                      </>
                    ) : (
                      <>
                        <Globe className="w-3.5 h-3.5" />
                        <span>Publish</span>
                      </>
                    )}
                  </button>

                  {/* Admin Direct Use / Test Editor Button (No purchase required) */}
                  <button
                    type="button"
                    onClick={() => setEditingResumeTemplate(template)}
                    className="py-1.5 px-3 text-xs font-semibold text-[#6D5DFB] bg-[#F1EEFF] hover:bg-[#E8E4FF] rounded-lg transition-colors"
                    title="Test directly in Resume Editor without purchasing"
                  >
                    Use in Editor
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {filteredTemplates.length === 0 && (
        <div className="py-16 text-center bg-white rounded-2xl border border-slate-200/80 p-8 shadow-xs max-w-xl mx-auto">
          <div className="w-14 h-14 bg-slate-100 rounded-2xl flex items-center justify-center mx-auto mb-4 text-slate-400">
            <FileText className="w-7 h-7" />
          </div>

          <h3 className="text-base font-bold text-[#111827]">
            {searchQuery.trim()
              ? 'No templates match your search.'
              : statusFilter === 'Unpublished'
              ? 'No unpublished templates found.'
              : statusFilter === 'Draft'
              ? 'No draft templates found.'
              : statusFilter === 'Published'
              ? 'No published templates found.'
              : 'No templates found.'}
          </h3>

          <p className="text-xs text-slate-500 mt-1.5 max-w-md mx-auto leading-relaxed">
            {searchQuery.trim()
              ? `No templates matched "${searchQuery}". Check for typos or try clearing the search filter.`
              : statusFilter === 'Unpublished'
              ? 'Templates hidden from the User Catalogue will appear here.'
              : statusFilter === 'Draft'
              ? 'Saved draft and in-progress templates will appear here.'
              : statusFilter === 'Published'
              ? 'No templates are currently published in the User Catalogue.'
              : 'Try resetting your status and tier filters to view all templates.'}
          </p>

          <div className="mt-5 flex items-center justify-center gap-3">
            <button
              type="button"
              onClick={() => {
                setStatusFilter('all');
                setTierFilter('all');
                setSearchQuery('');
              }}
              className="px-4 py-2 text-xs font-bold text-white bg-[#6D5DFB] hover:bg-[#5B4BE3] rounded-xl transition-all shadow-sm flex items-center gap-1.5"
            >
              <span>View All Templates</span>
            </button>
          </div>
        </div>
      )}

      {/* Admin Full Inspection & Preview Modal */}
      {previewTemplate && (
        <Modal
          isOpen={Boolean(previewTemplate)}
          onClose={() => setPreviewTemplate(null)}
          title={`Preview: ${previewTemplate.title}`}
          maxWidth="3xl"
        >
          <div className="space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3 bg-[#F1EEFF] p-3 rounded-xl border border-[#6D5DFB]/20 text-xs">
              <div className="flex items-center gap-2">
                <span className="font-bold text-[#111827]">{previewTemplate.title}</span>
                <span className="text-slate-400">&bull;</span>
                <span className="text-slate-600">{previewTemplate.intendedUser}</span>
                <span className="text-slate-400">&bull;</span>
                <span className="font-mono text-[#6D5DFB] font-bold">
                  {previewTemplate.tier === 'free' ? 'Free Template' : `Premium (₹${previewTemplate.priceInr})`}
                </span>
                <span className="text-slate-400">&bull;</span>
                <span className="font-semibold text-slate-700">Status: {previewTemplate.status}</span>
              </div>

              <button
                onClick={() => {
                  const t = previewTemplate;
                  setPreviewTemplate(null);
                  setEditingResumeTemplate(t);
                }}
                className="px-4 py-1.5 text-xs font-bold text-white bg-[#6D5DFB] hover:bg-[#5B4BE3] rounded-lg transition-colors flex items-center gap-1.5"
              >
                <span>Open in Resume Editor</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="max-h-[600px] overflow-y-auto p-4 bg-slate-100 rounded-xl border border-slate-200 shadow-inner">
              {renderResumeTemplate(previewTemplate.templateKey, DEFAULT_SAMPLE_RESUME, false, {
                accentColor: previewTemplate.accentColor,
                layout: previewTemplate.layout,
                font: previewTemplate.themeFont,
                enabledSections: previewTemplate.enabledSections
              })}
            </div>
          </div>
        </Modal>
      )}

      {/* Template Form Modal (Create & Edit) */}
      <TemplateFormModal
        isOpen={isFormModalOpen}
        onClose={() => setIsFormModalOpen(false)}
        onSave={handleSaveTemplate}
        initialTemplate={formInitialTemplate}
      />

      {/* Confirmation Dialog (Unpublish & Safe Delete) */}
      <TemplateConfirmDialog
        isOpen={confirmDialogState.isOpen}
        onClose={() => setConfirmDialogState(prev => ({ ...prev, isOpen: false }))}
        onConfirm={handleConfirmDialogAction}
        actionType={confirmDialogState.actionType}
        template={confirmDialogState.template}
      />
    </div>
  );
};
