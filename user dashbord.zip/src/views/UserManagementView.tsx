import React, { useState, useMemo } from 'react';
import {
  Users,
  Search,
  Filter,
  Plus,
  Download,
  Trash2,
  CheckCircle,
  XCircle,
  Eye,
  Shield,
  FileSearch,
  Mail,
  Calendar,
  Building,
  MoreVertical,
  Check,
  AlertCircle
} from 'lucide-react';
import { ResuNovaStore } from '../services/storage';
import { User, ResumeAnalysis } from '../types';
import { Modal } from '../components/common/Modal';
import { ConfirmDialog } from '../components/common/ConfirmDialog';
import { useToast } from '../context/ToastContext';

interface UserManagementViewProps {
  onInspectAnalysis?: (analysis: ResumeAnalysis) => void;
  initialSelectedUser?: User | null;
  onClearInitialUser?: () => void;
}

export const UserManagementView: React.FC<UserManagementViewProps> = ({
  onInspectAnalysis,
  initialSelectedUser,
  onClearInitialUser
}) => {
  const [users, setUsers] = useState<User[]>(() => ResuNovaStore.getUsers());
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'inactive'>('all');
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 5;

  // Selected User for Details Modal
  const [selectedUser, setSelectedUser] = useState<User | null>(initialSelectedUser || null);

  React.useEffect(() => {
    if (initialSelectedUser) {
      setSelectedUser(initialSelectedUser);
    }
  }, [initialSelectedUser]);

  // User Deletion State
  const [userToDelete, setUserToDelete] = useState<User | null>(null);

  // Add User Modal State
  const [isAddUserOpen, setIsAddUserOpen] = useState(false);
  const [newUserName, setNewUserName] = useState('');
  const [newUserEmail, setNewUserEmail] = useState('');
  const [newUserRole, setNewUserRole] = useState('Student Candidate');
  const [newUserUniversity, setNewUserUniversity] = useState('');

  const toast = useToast();

  const reloadUsers = () => {
    setUsers(ResuNovaStore.getUsers());
  };

  // Filtered and Paginated Users
  const filteredUsers = useMemo(() => {
    return users.filter(user => {
      const matchesSearch =
        user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (user.university && user.university.toLowerCase().includes(searchQuery.toLowerCase()));

      const matchesStatus =
        statusFilter === 'all' || user.status === statusFilter;

      return matchesSearch && matchesStatus;
    });
  }, [users, searchQuery, statusFilter]);

  const totalPages = Math.max(1, Math.ceil(filteredUsers.length / pageSize));
  const paginatedUsers = filteredUsers.slice(
    (currentPage - 1) * pageSize,
    currentPage * pageSize
  );

  // Actions
  const handleToggleStatus = (user: User) => {
    const updated = ResuNovaStore.toggleUserStatus(user.id);
    if (updated) {
      toast.success(
        `User ${updated.status === 'active' ? 'Activated' : 'Deactivated'}`,
        `${user.name}'s account is now ${updated.status}.`
      );
      reloadUsers();
    }
  };

  const handleDeleteConfirm = () => {
    if (!userToDelete) return;
    const ok = ResuNovaStore.deleteUser(userToDelete.id);
    if (ok) {
      toast.success('User Deleted', `Account for ${userToDelete.name} has been removed.`);
      reloadUsers();
      setUserToDelete(null);
    } else {
      toast.error('Deletion Failed', 'Unable to delete user.');
    }
  };

  const handleAddUserSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUserName.trim() || !newUserEmail.trim()) {
      toast.warning('Validation Error', 'Name and email are required fields.');
      return;
    }

    ResuNovaStore.addUser({
      name: newUserName.trim(),
      email: newUserEmail.trim(),
      role: newUserRole,
      university: newUserUniversity.trim() || 'ResuNova Student Network',
      status: 'active',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'
    });

    toast.success('User Created', `Invited ${newUserName} successfully.`);
    setIsAddUserOpen(false);
    setNewUserName('');
    setNewUserEmail('');
    setNewUserUniversity('');
    reloadUsers();
  };

  const handleExportCSV = () => {
    const headers = ['User ID', 'Name', 'Email', 'Role', 'Status', 'Registration Date', 'Resumes Analyzed', 'University'];
    const rows = filteredUsers.map(u => [
      u.id,
      `"${u.name}"`,
      `"${u.email}"`,
      `"${u.role}"`,
      u.status,
      u.registrationDate,
      u.resumesAnalyzed,
      `"${u.university || ''}"`
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `resunova_users_export_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast.success('Export Ready', `Downloaded ${filteredUsers.length} user records to CSV.`);
  };

  // Get user analyses for the details modal
  const userAnalyses = useMemo(() => {
    if (!selectedUser) return [];
    return ResuNovaStore.getAnalyses().filter(a => a.userId === selectedUser.id || a.userEmail === selectedUser.email);
  }, [selectedUser]);

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Top action bar: Search, Filter tabs, Export, Add User */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2 flex-1 max-w-md">
          <div className="relative w-full">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              placeholder="Search by name, email, university..."
              value={searchQuery}
              onChange={e => {
                setSearchQuery(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full bg-white border border-slate-200 rounded-xl pl-9 pr-3 py-2 text-xs text-[#1F2937] placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
            />
          </div>

          {/* Status filter segmented control */}
          <div className="flex items-center p-1 bg-slate-100 rounded-xl border border-slate-200/60 shrink-0">
            {(['all', 'active', 'inactive'] as const).map(s => (
              <button
                key={s}
                onClick={() => {
                  setStatusFilter(s);
                  setCurrentPage(1);
                }}
                className={`px-2.5 py-1 text-xs font-semibold rounded-lg capitalize transition-colors ${
                  statusFilter === s
                    ? 'bg-white text-[#6D5DFB] shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-xl transition-colors shadow-xs"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={() => setIsAddUserOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-white bg-[#6D5DFB] hover:bg-[#5B4BE3] rounded-xl transition-colors shadow-xs"
          >
            <Plus className="w-4 h-4" />
            <span>Add User</span>
          </button>
        </div>
      </div>

      {/* Main Table Card */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 uppercase font-semibold border-b border-slate-200/80">
              <tr>
                <th className="py-3 px-4">User ID</th>
                <th className="py-3 px-4">Candidate Name</th>
                <th className="py-3 px-4">Email</th>
                <th className="py-3 px-4">Registration Date</th>
                <th className="py-3 px-4 text-center">Resumes Analyzed</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {paginatedUsers.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400">
                    <p className="font-semibold text-slate-600 mb-1">No users found</p>
                    <p className="text-xs">Try adjusting your search query or filter settings.</p>
                  </td>
                </tr>
              ) : (
                paginatedUsers.map(user => (
                  <tr key={user.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-[#6D5DFB]">
                      {user.id}
                    </td>
                    <td className="py-3 px-4 font-semibold text-[#111827]">
                      <div className="flex items-center gap-2.5">
                        <div className="w-7 h-7 rounded-full bg-slate-100 border border-slate-200 flex items-center justify-center font-bold text-slate-600 text-[10px]">
                          {user.name.split(' ').map(n => n[0]).join('')}
                        </div>
                        <div>
                          <span>{user.name}</span>
                          {user.university && (
                            <span className="block text-[10px] text-slate-400 font-normal truncate max-w-[140px]">
                              {user.university}
                            </span>
                          )}
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-600">
                      {user.email}
                    </td>
                    <td className="py-3 px-4 text-slate-500 font-mono">
                      {user.registrationDate}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span className="font-mono font-bold text-[#111827] tabular-nums bg-slate-100 px-2 py-0.5 rounded-full">
                        {user.resumesAnalyzed}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <button
                        onClick={() => handleToggleStatus(user)}
                        title="Click to toggle status"
                        className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full font-bold text-[10px] uppercase tracking-wider transition-colors ${
                          user.status === 'active'
                            ? 'bg-emerald-50 text-[#16A34A] border border-emerald-200 hover:bg-emerald-100'
                            : 'bg-slate-100 text-slate-500 border border-slate-200 hover:bg-slate-200'
                        }`}
                      >
                        <span className={`w-1.5 h-1.5 rounded-full ${user.status === 'active' ? 'bg-[#16A34A]' : 'bg-slate-400'}`} />
                        {user.status}
                      </button>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => setSelectedUser(user)}
                          className="p-1.5 rounded-lg text-slate-600 hover:text-[#6D5DFB] hover:bg-[#F1EEFF] transition-colors"
                          title="View user details & history"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => setUserToDelete(user)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-[#DC2626] hover:bg-red-50 transition-colors"
                          title="Delete user account"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination footer */}
        <div className="px-5 py-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
          <span>
            Showing <strong className="text-slate-800 font-mono">{filteredUsers.length === 0 ? 0 : (currentPage - 1) * pageSize + 1}</strong> to{' '}
            <strong className="text-slate-800 font-mono">
              {Math.min(currentPage * pageSize, filteredUsers.length)}
            </strong>{' '}
            of <strong className="text-slate-800 font-mono">{filteredUsers.length}</strong> candidates
          </span>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setCurrentPage(p => Math.max(p - 1, 1))}
              disabled={currentPage === 1}
              className="px-2.5 py-1 border border-slate-200 rounded-lg font-medium hover:bg-slate-50 disabled:opacity-40 transition-colors"
            >
              Previous
            </button>
            <span className="font-mono px-2 font-semibold text-slate-700">
              {currentPage} / {totalPages}
            </span>
            <button
              onClick={() => setCurrentPage(p => Math.min(p + 1, totalPages))}
              disabled={currentPage === totalPages}
              className="px-2.5 py-1 border border-slate-200 rounded-lg font-medium hover:bg-slate-50 disabled:opacity-40 transition-colors"
            >
              Next
            </button>
          </div>
        </div>
      </div>

      {/* User Details Modal (Protects raw resume text while showing metrics) */}
      {selectedUser && (
        <Modal
          isOpen={!!selectedUser}
          onClose={() => setSelectedUser(null)}
          title={`Candidate Profile: ${selectedUser.name}`}
          subtitle={`Account ID: ${selectedUser.id} · Registered ${selectedUser.registrationDate}`}
          maxWidth="2xl"
          footer={
            <div className="flex items-center justify-between w-full">
              <span className="text-[11px] text-slate-400 flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5 text-[#16A34A]" />
                PII Privacy Protected: Resume documents encrypted in MySQL
              </span>
              <button
                onClick={() => setSelectedUser(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
              >
                Close
              </button>
            </div>
          }
        >
          <div className="space-y-4">
            {/* User Info Bar */}
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/70 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-[#6D5DFB] to-[#8B5CF6] text-white flex items-center justify-center font-bold text-base shadow-xs">
                  {selectedUser.name.split(' ').map(n => n[0]).join('')}
                </div>
                <div>
                  <h4 className="text-base font-bold text-[#111827]">{selectedUser.name}</h4>
                  <p className="text-xs text-slate-500 font-mono">{selectedUser.email}</p>
                  <p className="text-xs text-slate-600 mt-0.5">{selectedUser.university}</p>
                </div>
              </div>

              <div className="text-right">
                <span className={`inline-block px-2.5 py-0.5 rounded-full font-bold text-xs uppercase tracking-wider ${
                  selectedUser.status === 'active' ? 'bg-emerald-50 text-[#16A34A] border border-emerald-200' : 'bg-slate-200 text-slate-600'
                }`}>
                  {selectedUser.status}
                </span>
                <p className="text-[11px] text-slate-400 mt-1">
                  Last active: {selectedUser.lastActive}
                </p>
              </div>
            </div>

            {/* Analysis History */}
            <div>
              <h5 className="text-xs font-bold text-[#111827] uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <FileSearch className="w-4 h-4 text-[#6D5DFB]" />
                Resume Analysis Records ({userAnalyses.length})
              </h5>

              {userAnalyses.length === 0 ? (
                <div className="p-6 text-center text-slate-400 bg-slate-50/50 rounded-xl border border-dashed border-slate-200 text-xs">
                  This user has not submitted any resumes for ATS analysis yet.
                </div>
              ) : (
                <div className="space-y-2 max-h-56 overflow-y-auto">
                  {userAnalyses.map(analysis => (
                    <div
                      key={analysis.id}
                      className="p-3 bg-white border border-slate-200 rounded-xl flex items-center justify-between gap-3 text-xs"
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-[#6D5DFB]">{analysis.id}</span>
                          <span className="font-semibold text-slate-900">{analysis.jobRoleTitle}</span>
                        </div>
                        <p className="text-slate-500 text-[11px] mt-0.5">
                          {analysis.fileName} · Scanned on {analysis.analysisDate}
                        </p>
                      </div>

                      <div className="flex items-center gap-3">
                        <div className="text-right">
                          <span className={`font-mono font-bold text-sm ${
                            analysis.atsScore >= 80 ? 'text-[#16A34A]' : 'text-[#F59E0B]'
                          }`}>
                            {analysis.atsScore}%
                          </span>
                          <span className="block text-[10px] text-slate-400">ATS Match</span>
                        </div>

                        {onInspectAnalysis && (
                          <button
                            onClick={() => {
                              setSelectedUser(null);
                              onInspectAnalysis(analysis);
                            }}
                            className="px-2.5 py-1 text-xs font-semibold text-[#6D5DFB] bg-[#F1EEFF] hover:bg-[#E8E4FF] rounded-lg transition-colors"
                          >
                            Inspect
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </Modal>
      )}

      {/* Add User Modal */}
      <Modal
        isOpen={isAddUserOpen}
        onClose={() => setIsAddUserOpen(false)}
        title="Invite / Create Candidate User"
        subtitle="Registers a new candidate into ResuNova's MySQL user cohort."
        maxWidth="md"
        footer={
          <>
            <button
              type="button"
              onClick={() => setIsAddUserOpen(false)}
              className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleAddUserSubmit}
              className="px-4 py-2 text-xs font-semibold text-white bg-[#6D5DFB] hover:bg-[#5B4BE3] rounded-lg transition-colors"
            >
              Create Account
            </button>
          </>
        }
      >
        <form onSubmit={handleAddUserSubmit} className="space-y-3.5">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Full Name *
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Maya Lin"
              value={newUserName}
              onChange={e => setNewUserName(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-[#1F2937] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Email Address *
            </label>
            <input
              type="email"
              required
              placeholder="e.g. maya.lin@berkeley.edu"
              value={newUserEmail}
              onChange={e => setNewUserEmail(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-[#1F2937] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              University / Institution
            </label>
            <input
              type="text"
              placeholder="e.g. UC Berkeley Computer Science"
              value={newUserUniversity}
              onChange={e => setNewUserUniversity(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-[#1F2937] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Candidate Role
            </label>
            <select
              value={newUserRole}
              onChange={e => setNewUserRole(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-[#1F2937] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
            >
              <option value="Student Candidate">Student Candidate</option>
              <option value="Job Seeker">Job Seeker</option>
              <option value="Graduate Student">Graduate Student</option>
              <option value="Alumni">Alumni</option>
            </select>
          </div>
        </form>
      </Modal>

      {/* Delete User Confirmation Dialog */}
      <ConfirmDialog
        isOpen={!!userToDelete}
        onClose={() => setUserToDelete(null)}
        onConfirm={handleDeleteConfirm}
        title="Delete Candidate Account?"
        message={`Are you sure you want to permanently delete the account for "${userToDelete?.name}" (${userToDelete?.email})? All associated resume analysis records will be removed.`}
        confirmText="Delete Account"
        variant="danger"
      />
    </div>
  );
};
