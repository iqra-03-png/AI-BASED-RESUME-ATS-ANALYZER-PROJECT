import React, { useState, useMemo } from 'react';
import {
  HelpCircle,
  Search,
  Plus,
  Filter,
  Edit2,
  Trash2,
  ChevronDown,
  ChevronUp,
  CheckCircle2,
  Layers,
  MessageSquare
} from 'lucide-react';
import { ResuNovaStore } from '../services/storage';
import { InterviewQuestion, QuestionCategory, JobDomain, JobRole } from '../types';
import { Modal } from '../components/common/Modal';
import { ConfirmDialog } from '../components/common/ConfirmDialog';
import { useToast } from '../context/ToastContext';

export const InterviewQuestionsView: React.FC = () => {
  const [questions, setQuestions] = useState<InterviewQuestion[]>(() =>
    ResuNovaStore.getQuestions()
  );
  const [domains] = useState<JobDomain[]>(() => ResuNovaStore.getDomains());
  const [roles] = useState<JobRole[]>(() => ResuNovaStore.getRoles());

  const [searchQuery, setSearchQuery] = useState('');
  const [categoryTab, setCategoryTab] = useState<QuestionCategory | 'All'>('All');
  const [domainFilter, setDomainFilter] = useState<string>('all');
  const [difficultyFilter, setDifficultyFilter] = useState<string>('all');

  const [expandedId, setExpandedId] = useState<string | null>(null);

  // Modal states
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [questionToEdit, setQuestionToEdit] = useState<InterviewQuestion | null>(null);
  const [questionToDelete, setQuestionToDelete] = useState<InterviewQuestion | null>(null);

  // Form states
  const [formQuestion, setFormQuestion] = useState('');
  const [formAnswer, setFormAnswer] = useState('');
  const [formCategory, setFormCategory] = useState<QuestionCategory>('Technical');
  const [formDomainId, setFormDomainId] = useState<string>('all');
  const [formDifficulty, setFormDifficulty] = useState<'Easy' | 'Medium' | 'Hard'>('Medium');

  const toast = useToast();

  const reloadQuestions = () => {
    setQuestions(ResuNovaStore.getQuestions());
  };

  const filteredQuestions = useMemo(() => {
    return questions.filter(q => {
      const matchesSearch =
        q.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
        q.sampleAnswer.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesCat = categoryTab === 'All' || q.category === categoryTab;
      const matchesDomain = domainFilter === 'all' || q.domainId === domainFilter;
      const matchesDiff = difficultyFilter === 'all' || q.difficulty === difficultyFilter;

      return matchesSearch && matchesCat && matchesDomain && matchesDiff;
    });
  }, [questions, searchQuery, categoryTab, domainFilter, difficultyFilter]);

  const handleOpenAdd = () => {
    setFormQuestion('');
    setFormAnswer('');
    setFormCategory('Technical');
    setFormDomainId('all');
    setFormDifficulty('Medium');
    setIsAddModalOpen(true);
  };

  const handleOpenEdit = (q: InterviewQuestion) => {
    setQuestionToEdit(q);
    setFormQuestion(q.question);
    setFormAnswer(q.sampleAnswer);
    setFormCategory(q.category);
    setFormDomainId(q.domainId);
    setFormDifficulty(q.difficulty);
  };

  const handleSaveQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formQuestion.trim() || !formAnswer.trim()) {
      toast.warning('Validation', 'Question and model answer are required.');
      return;
    }

    const domainName =
      formDomainId === 'all'
        ? 'All Domains'
        : domains.find(d => d.id === formDomainId)?.name || 'General';

    if (questionToEdit) {
      ResuNovaStore.updateQuestion(questionToEdit.id, {
        question: formQuestion.trim(),
        sampleAnswer: formAnswer.trim(),
        category: formCategory,
        domainId: formDomainId,
        domainName,
        difficulty: formDifficulty
      });
      toast.success('Question Updated', 'Changes saved successfully.');
      setQuestionToEdit(null);
    } else {
      ResuNovaStore.addQuestion({
        question: formQuestion.trim(),
        sampleAnswer: formAnswer.trim(),
        category: formCategory,
        domainId: formDomainId,
        domainName,
        difficulty: formDifficulty,
        status: 'active'
      });
      toast.success('Question Added', 'Interview question added to repository.');
      setIsAddModalOpen(false);
    }
    reloadQuestions();
  };

  const handleDeleteConfirm = () => {
    if (!questionToDelete) return;
    ResuNovaStore.deleteQuestion(questionToDelete.id);
    toast.success('Question Deleted', 'Removed from question repository.');
    setQuestionToDelete(null);
    reloadQuestions();
  };

  const handleToggleStatus = (q: InterviewQuestion) => {
    ResuNovaStore.toggleQuestionStatus(q.id);
    reloadQuestions();
  };

  const toggleExpand = (id: string) => {
    setExpandedId(prev => (prev === id ? null : id));
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Questions Metric Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs text-xs">
        <div>
          <span className="text-slate-400 block text-[11px] font-medium">Total Question Bank</span>
          <span className="text-lg font-bold font-mono text-[#111827]">{questions.length}</span>
        </div>
        <div>
          <span className="text-slate-400 block text-[11px] font-medium">Technical Questions</span>
          <span className="text-lg font-bold font-mono text-blue-600">
            {questions.filter(q => q.category === 'Technical').length}
          </span>
        </div>
        <div>
          <span className="text-slate-400 block text-[11px] font-medium">Behavioral</span>
          <span className="text-lg font-bold font-mono text-[#8B5CF6]">
            {questions.filter(q => q.category === 'Behavioral').length}
          </span>
        </div>
        <div>
          <span className="text-slate-400 block text-[11px] font-medium">HR & Situational</span>
          <span className="text-lg font-bold font-mono text-emerald-600">
            {questions.filter(q => q.category === 'HR' || q.category === 'Situational').length}
          </span>
        </div>
      </div>

      {/* Top Controls: Search, Category Tabs, Add Button */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        {/* Category Tabs */}
        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl overflow-x-auto">
          {(['All', 'Technical', 'HR', 'Behavioral', 'Situational'] as const).map(cat => (
            <button
              key={cat}
              onClick={() => setCategoryTab(cat)}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors whitespace-nowrap ${
                categoryTab === cat
                  ? 'bg-white text-[#6D5DFB] shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <button
          onClick={handleOpenAdd}
          className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-white bg-[#6D5DFB] hover:bg-[#5B4BE3] rounded-xl transition-colors shadow-xs shrink-0 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Add Question</span>
        </button>
      </div>

      {/* Secondary Search & Domain Filter Bar */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative min-w-[220px] flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            placeholder="Search questions or keywords..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full bg-white border border-slate-200 rounded-xl pl-9 pr-3 py-2 text-xs text-[#1F2937] placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
          />
        </div>

        <select
          value={domainFilter}
          onChange={e => setDomainFilter(e.target.value)}
          className="bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-700 focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
        >
          <option value="all">All Domains</option>
          {domains.map(d => (
            <option key={d.id} value={d.id}>
              {d.name}
            </option>
          ))}
        </select>

        <select
          value={difficultyFilter}
          onChange={e => setDifficultyFilter(e.target.value)}
          className="bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-700 focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
        >
          <option value="all">All Difficulties</option>
          <option value="Easy">Easy</option>
          <option value="Medium">Medium</option>
          <option value="Hard">Hard</option>
        </select>
      </div>

      {/* Questions List */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-[#111827]">
              Interview Preparation Bank ({filteredQuestions.length})
            </h3>
            <p className="text-xs text-[#6B7280]">
              Candidate mock questions mapped to job domain skills
            </p>
          </div>
        </div>

        {filteredQuestions.length === 0 ? (
          <div className="p-12 text-center text-slate-400">
            <p className="font-semibold text-slate-700 mb-1">No questions found</p>
            <p className="text-xs">Try selecting a different category or clearing search terms.</p>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {filteredQuestions.map(q => {
              const isExpanded = expandedId === q.id;
              return (
                <div key={q.id} className="p-5 hover:bg-slate-50/70 transition-colors">
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2 mb-1.5">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                          q.category === 'Technical' ? 'bg-blue-50 text-blue-700' :
                          q.category === 'Behavioral' ? 'bg-purple-50 text-[#8B5CF6]' :
                          q.category === 'HR' ? 'bg-emerald-50 text-emerald-700' :
                          'bg-amber-50 text-amber-700'
                        }`}>
                          {q.category}
                        </span>

                        <span className="text-[11px] text-slate-500 font-medium">
                          {q.domainName}
                        </span>

                        <span className={`px-2 py-0.2 rounded text-[10px] font-mono font-semibold ${
                          q.difficulty === 'Easy' ? 'bg-slate-100 text-slate-600' :
                          q.difficulty === 'Medium' ? 'bg-amber-50 text-amber-700' :
                          'bg-red-50 text-red-700'
                        }`}>
                          {q.difficulty}
                        </span>
                      </div>

                      <h4
                        onClick={() => toggleExpand(q.id)}
                        className="text-sm font-bold text-[#111827] cursor-pointer hover:text-[#6D5DFB] transition-colors leading-snug"
                      >
                        {q.question}
                      </h4>
                    </div>

                    <div className="flex items-center gap-2 shrink-0 self-end sm:self-start">
                      <button
                        onClick={() => toggleExpand(q.id)}
                        className="px-2.5 py-1 text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors flex items-center gap-1"
                      >
                        <span>{isExpanded ? 'Hide Answer' : 'View Answer'}</span>
                        {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                      </button>
                      <button
                        onClick={() => handleOpenEdit(q)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-[#6D5DFB] hover:bg-[#F1EEFF] transition-colors"
                        title="Edit question"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setQuestionToDelete(q)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-[#DC2626] hover:bg-red-50 transition-colors"
                        title="Delete question"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Expanded Model Answer */}
                  {isExpanded && (
                    <div className="mt-3.5 pt-3 border-t border-slate-100 text-xs bg-slate-50/70 p-3.5 rounded-xl border border-slate-200/60 animate-in fade-in duration-100">
                      <span className="font-bold text-[#6D5DFB] uppercase tracking-wider text-[10px] block mb-1">
                        High-Scoring Candidate Model Answer:
                      </span>
                      <p className="text-slate-700 leading-relaxed font-sans">
                        {q.sampleAnswer}
                      </p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Add / Edit Question Modal */}
      <Modal
        isOpen={isAddModalOpen || !!questionToEdit}
        onClose={() => {
          setIsAddModalOpen(false);
          setQuestionToEdit(null);
        }}
        title={questionToEdit ? 'Edit Interview Question' : 'Add Interview Question'}
        subtitle="Used for simulated interview prep and ATS recommendation feedback."
        maxWidth="lg"
        footer={
          <>
            <button
              type="button"
              onClick={() => {
                setIsAddModalOpen(false);
                setQuestionToEdit(null);
              }}
              className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSaveQuestion}
              className="px-4 py-2 text-xs font-semibold text-white bg-[#6D5DFB] hover:bg-[#5B4BE3] rounded-lg transition-colors"
            >
              {questionToEdit ? 'Save Changes' : 'Add Question'}
            </button>
          </>
        }
      >
        <form onSubmit={handleSaveQuestion} className="space-y-3.5">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Interview Question *
            </label>
            <textarea
              required
              rows={2}
              placeholder="e.g. How does the event loop in Node.js handle non-blocking asynchronous I/O?"
              value={formQuestion}
              onChange={e => setFormQuestion(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-[#1F2937] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Sample Model Answer *
            </label>
            <textarea
              required
              rows={4}
              placeholder="Structured STAR response or technical explanation guidelines..."
              value={formAnswer}
              onChange={e => setFormAnswer(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-[#1F2937] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Category
              </label>
              <select
                value={formCategory}
                onChange={e => setFormCategory(e.target.value as QuestionCategory)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-[#1F2937] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
              >
                <option value="Technical">Technical</option>
                <option value="Behavioral">Behavioral</option>
                <option value="HR">HR & Background</option>
                <option value="Situational">Situational</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Domain Association
              </label>
              <select
                value={formDomainId}
                onChange={e => setFormDomainId(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-[#1F2937] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
              >
                <option value="all">All Domains (General)</option>
                {domains.map(d => (
                  <option key={d.id} value={d.id}>
                    {d.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Difficulty Level
              </label>
              <select
                value={formDifficulty}
                onChange={e => setFormDifficulty(e.target.value as any)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-[#1F2937] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
              >
                <option value="Easy">Easy</option>
                <option value="Medium">Medium</option>
                <option value="Hard">Hard</option>
              </select>
            </div>
          </div>
        </form>
      </Modal>

      {/* Delete Confirmation Dialog */}
      <ConfirmDialog
        isOpen={!!questionToDelete}
        onClose={() => setQuestionToDelete(null)}
        onConfirm={handleDeleteConfirm}
        title="Delete Interview Question?"
        message="Are you sure you want to remove this question from the active interview repository?"
        confirmText="Confirm Delete"
        variant="danger"
      />
    </div>
  );
};
