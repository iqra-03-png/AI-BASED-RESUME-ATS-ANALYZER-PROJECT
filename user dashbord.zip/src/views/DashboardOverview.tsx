import React from 'react';
import {
  Users,
  FileSearch,
  Briefcase,
  Award,
  ArrowRight,
  Clock,
  ChevronRight,
  FileCheck,
  CheckCircle2,
  AlertTriangle,
  Layers,
  Inbox
} from 'lucide-react';
import { StatCard } from '../components/common/StatCard';
import { ResuNovaStore } from '../services/storage';
import { NavItemKey } from '../components/layout/Sidebar';
import { User, ResumeAnalysis } from '../types';

interface DashboardOverviewProps {
  onNavigate: (tab: NavItemKey) => void;
  onViewUser: (user: User) => void;
  onViewAnalysis: (analysis: ResumeAnalysis) => void;
}

export const DashboardOverview: React.FC<DashboardOverviewProps> = ({
  onNavigate,
  onViewUser,
  onViewAnalysis
}) => {
  const users = ResuNovaStore.getUsers();
  const analyses = ResuNovaStore.getAnalyses();
  const domains = ResuNovaStore.getDomains();

  // Strict Calculation Rules
  const totalUsers = users.length;
  const completedAnalyses = analyses.filter(a => a.status === 'Completed');
  const failedAnalyses = analyses.filter(a => a.status === 'Failed');
  const totalAnalyses = analyses.length;

  const validScores = completedAnalyses
    .map(a => a.atsScore)
    .filter(s => typeof s === 'number' && !isNaN(s));
  const avgAtsScore =
    validScores.length > 0
      ? Math.round(validScores.reduce((acc, s) => acc + s, 0) / validScores.length)
      : 0;

  const totalDomains = domains.length;

  // Latest analysis for the compact summary banner
  const latestAnalysis: ResumeAnalysis | undefined = analyses.length > 0 ? analyses[0] : undefined;

  // Popular domains calculated strictly by grouped target domains from stored analyses
  const domainCounts: Record<string, number> = {};
  analyses.forEach(a => {
    const domainName = a.jobDomainName || 'General Engineering';
    domainCounts[domainName] = (domainCounts[domainName] || 0) + 1;
  });

  const totalScans = analyses.length || 1;
  const popularDomains = Object.entries(domainCounts)
    .map(([name, count]) => ({
      name,
      count,
      percentage: Math.round((count / totalScans) * 100)
    }))
    .sort((a, b) => b.count - a.count);

  const maxDomainCount = Math.max(...popularDomains.map(d => d.count), 1);

  const recentUsers = users.slice(0, 5);
  const recentAnalyses = analyses.slice(0, 5);

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Top Header: Breadcrumb and Title as depicted in reference design */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium mb-1">
            <span>ResuNova</span>
            <span className="text-slate-400">/</span>
            <span className="text-[#6D5DFB] font-semibold">Platform / Overview</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#111827] tracking-tight">
            Dashboard Overview
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Monitor users, resume analysis, and platform performance.
          </p>
        </div>

        {/* Quick Demo Data Badge */}
        <div className="self-start sm:self-auto flex items-center gap-2 bg-purple-50/70 border border-purple-200/60 px-3 py-1.5 rounded-xl text-xs text-[#6D5DFB]">
          <span className="w-2 h-2 rounded-full bg-[#6D5DFB] animate-pulse"></span>
          <span className="font-semibold">Local Storage Engine Active</span>
        </div>
      </div>

      {/* 1. Four Primary Summary Cards in One Row on Desktop */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Users */}
        <StatCard
          title="Total Users"
          value={totalUsers}
          subtext="Registered candidate accounts"
          icon={<Users className="w-5 h-5" />}
          iconBgColor="bg-[#F1EEFF] text-[#6D5DFB]"
          onClick={() => onNavigate('users')}
        />

        {/* Total Resumes Analysed */}
        <StatCard
          title="Total Resumes Analysed"
          value={totalAnalyses}
          subtext={`${completedAnalyses.length} completed · ${failedAnalyses.length} failed`}
          icon={<FileSearch className="w-5 h-5" />}
          iconBgColor="bg-blue-50 text-blue-600"
          onClick={() => onNavigate('analyses')}
        />

        {/* Average ATS Score */}
        <StatCard
          title="Average ATS Score"
          value={`${avgAtsScore}%`}
          subtext="From completed evaluations"
          icon={<Award className="w-5 h-5" />}
          iconBgColor="bg-purple-50 text-[#8B5CF6]"
          accentGlow={true}
          onClick={() => onNavigate('reports')}
        />

        {/* Total Job Domains */}
        <StatCard
          title="Total Job Domains"
          value={totalDomains}
          subtext={`${totalDomains} active career tracks`}
          icon={<Briefcase className="w-5 h-5" />}
          iconBgColor="bg-indigo-50 text-indigo-600"
          onClick={() => onNavigate('domains')}
        />
      </div>

      {/* 2. Compact Latest Resume Analysis Section */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-4 sm:p-5">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-3.5">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-[#F1EEFF] text-[#6D5DFB] flex items-center justify-center">
              <FileCheck className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-[#111827]">Latest Resume Analysis</h2>
              <p className="text-[11px] text-slate-500">Most recent candidate submission processed by ResuNova ATS engine</p>
            </div>
          </div>

          <button
            onClick={() => onNavigate('analyses')}
            className="text-xs font-semibold text-[#6D5DFB] hover:text-[#5B4BE3] flex items-center gap-1 transition-colors"
          >
            <span>View All Analyses</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {latestAnalysis ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3.5 items-center bg-slate-50/60 rounded-xl p-3.5 border border-slate-100">
            {/* Candidate */}
            <div>
              <span className="block text-[10px] uppercase font-bold tracking-wider text-slate-400 mb-0.5">
                Candidate Name
              </span>
              <p className="text-xs font-bold text-[#111827] truncate">
                {latestAnalysis.userName}
              </p>
              <span className="text-[11px] text-slate-400 font-mono">ID: {latestAnalysis.id}</span>
            </div>

            {/* Target Job Role */}
            <div>
              <span className="block text-[10px] uppercase font-bold tracking-wider text-slate-400 mb-0.5">
                Target Role & Domain
              </span>
              <p className="text-xs font-semibold text-slate-800 truncate">
                {latestAnalysis.jobRoleTitle}
              </p>
              <span className="text-[11px] text-slate-500 truncate block">
                {latestAnalysis.jobDomainName}
              </span>
            </div>

            {/* Analysis Date */}
            <div>
              <span className="block text-[10px] uppercase font-bold tracking-wider text-slate-400 mb-0.5">
                Analysis Date
              </span>
              <div className="flex items-center gap-1.5 text-xs text-slate-600 font-medium">
                <Clock className="w-3.5 h-3.5 text-slate-400" />
                <span>{latestAnalysis.analysisDate}</span>
              </div>
            </div>

            {/* ATS Score */}
            <div>
              <span className="block text-[10px] uppercase font-bold tracking-wider text-slate-400 mb-0.5">
                ATS Score
              </span>
              <div className="flex items-center gap-2">
                <span
                  className={`text-base font-extrabold font-mono tabular-nums ${
                    latestAnalysis.status === 'Failed'
                      ? 'text-[#DC2626]'
                      : latestAnalysis.atsScore >= 80
                      ? 'text-[#16A34A]'
                      : latestAnalysis.atsScore >= 60
                      ? 'text-[#F59E0B]'
                      : 'text-[#DC2626]'
                  }`}
                >
                  {latestAnalysis.status === 'Failed' ? 'N/A' : `${latestAnalysis.atsScore}%`}
                </span>
                <span className="text-[10px] text-slate-400">Match score</span>
              </div>
            </div>

            {/* Status & Action */}
            <div className="flex items-center justify-between sm:justify-end gap-3">
              <span
                className={`px-2.5 py-1 rounded-full text-[11px] font-bold inline-flex items-center gap-1 ${
                  latestAnalysis.status === 'Completed'
                    ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                    : latestAnalysis.status === 'Processing'
                    ? 'bg-blue-50 text-blue-700 border border-blue-200'
                    : 'bg-red-50 text-red-700 border border-red-200'
                }`}
              >
                {latestAnalysis.status === 'Completed' ? (
                  <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                ) : (
                  <AlertTriangle className="w-3 h-3 text-red-600" />
                )}
                <span>{latestAnalysis.status}</span>
              </span>

              <button
                onClick={() => onViewAnalysis(latestAnalysis)}
                className="px-3 py-1.5 text-xs font-semibold text-[#6D5DFB] bg-[#F1EEFF] hover:bg-[#E8E4FF] rounded-lg transition-colors shrink-0"
              >
                Inspect
              </button>
            </div>
          </div>
        ) : (
          <div className="py-8 flex flex-col items-center justify-center text-center">
            <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center text-slate-400 mb-2">
              <Inbox className="w-6 h-6" />
            </div>
            <p className="text-sm font-semibold text-slate-700">No Resume Analyses Recorded</p>
            <p className="text-xs text-slate-400 mt-0.5 max-w-sm">
              When candidates submit their resumes for automated ATS scoring, the latest evaluation result will be displayed here.
            </p>
          </div>
        )}
      </div>

      {/* 3. Main Dashboard Sections — Two-Column Layout (Responsive: Stack on mobile/tablet, 2 columns on desktop) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column (lg:col-span-7): Recent User Registrations + Recent Resume Analyses */}
        <div className="lg:col-span-7 space-y-6">
          {/* Table A: Recent User Registrations */}
          <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-[#111827]">Recent User Registrations</h3>
                <p className="text-xs text-[#6B7280]">Latest candidate and student sign-ups</p>
              </div>
              <button
                onClick={() => onNavigate('users')}
                className="text-xs font-semibold text-[#6D5DFB] hover:text-[#5B4BE3] flex items-center gap-1 transition-colors"
              >
                <span>View All</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-slate-50/70 border-b border-slate-100 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                    <th className="py-2.5 px-4">User</th>
                    <th className="py-2.5 px-4 hidden sm:table-cell">Target Role</th>
                    <th className="py-2.5 px-4 hidden md:table-cell">Registered</th>
                    <th className="py-2.5 px-4 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {recentUsers.map(user => (
                    <tr key={user.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2.5">
                          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-[#6D5DFB]/15 to-[#8B5CF6]/25 text-[#6D5DFB] font-bold flex items-center justify-center shrink-0 text-xs">
                            {user.name.charAt(0)}
                          </div>
                          <div className="min-w-0">
                            <p className="font-semibold text-[#111827] truncate max-w-[150px]">{user.name}</p>
                            <p className="text-slate-400 text-[11px] truncate max-w-[150px] font-mono">{user.email}</p>
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-4 hidden sm:table-cell text-slate-600">
                        <span className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-slate-100 text-slate-700">
                          {user.role}
                        </span>
                      </td>
                      <td className="py-3 px-4 hidden md:table-cell text-slate-500 font-mono text-[11px]">
                        {user.registrationDate}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <button
                          onClick={() => onViewUser(user)}
                          className="px-2.5 py-1 text-xs font-semibold text-[#6D5DFB] bg-[#F1EEFF] hover:bg-[#E8E4FF] rounded-lg transition-colors"
                        >
                          Inspect
                        </button>
                      </td>
                    </tr>
                  ))}
                  {recentUsers.length === 0 && (
                    <tr>
                      <td colSpan={4} className="py-6 text-center text-slate-400">
                        No registered users found.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Table B: Recent Resume Analyses */}
          <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-[#111827]">Recent Resume Analyses</h3>
                <p className="text-xs text-[#6B7280]">Calculated ATS scores and evaluation results</p>
              </div>
              <button
                onClick={() => onNavigate('analyses')}
                className="text-xs font-semibold text-[#6D5DFB] hover:text-[#5B4BE3] flex items-center gap-1 transition-colors"
              >
                <span>View All Scans</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-slate-50/70 border-b border-slate-100 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                    <th className="py-2.5 px-4">Candidate & ID</th>
                    <th className="py-2.5 px-4 hidden sm:table-cell">Target Role</th>
                    <th className="py-2.5 px-4 text-center">Score</th>
                    <th className="py-2.5 px-4 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {recentAnalyses.map(analysis => (
                    <tr key={analysis.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3 px-4">
                        <div className="min-w-0">
                          <p className="font-semibold text-[#111827] truncate max-w-[150px]">
                            {analysis.userName}
                          </p>
                          <span className="font-mono text-[10px] text-[#6D5DFB]">
                            {analysis.id}
                          </span>
                        </div>
                      </td>
                      <td className="py-3 px-4 hidden sm:table-cell text-slate-600">
                        <span className="truncate max-w-[160px] block" title={analysis.jobRoleTitle}>
                          {analysis.jobRoleTitle}
                        </span>
                        <span className="text-[10px] text-slate-400 block truncate">
                          {analysis.jobDomainName}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span
                          className={`text-xs font-extrabold font-mono tabular-nums px-2 py-0.5 rounded-full ${
                            analysis.status === 'Failed'
                              ? 'bg-red-50 text-[#DC2626]'
                              : analysis.atsScore >= 80
                              ? 'bg-emerald-50 text-[#16A34A]'
                              : analysis.atsScore >= 60
                              ? 'bg-amber-50 text-[#F59E0B]'
                              : 'bg-red-50 text-[#DC2626]'
                          }`}
                        >
                          {analysis.status === 'Failed' ? 'FAILED' : `${analysis.atsScore}%`}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <button
                          onClick={() => onViewAnalysis(analysis)}
                          className="px-2.5 py-1 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
                        >
                          View
                        </button>
                      </td>
                    </tr>
                  ))}
                  {recentAnalyses.length === 0 && (
                    <tr>
                      <td colSpan={4} className="py-6 text-center text-slate-400">
                        No resume evaluations found.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Right Column (lg:col-span-5): Popular Job Domains */}
        <div className="lg:col-span-5">
          <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-5 flex flex-col justify-between h-full">
            <div>
              <div className="flex items-center justify-between pb-3.5 border-b border-slate-100 mb-4">
                <div>
                  <h3 className="text-sm font-bold text-[#111827]">Popular Job Domains</h3>
                  <p className="text-xs text-[#6B7280]">Target domains ranked by candidate demand</p>
                </div>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#F1EEFF] text-[#6D5DFB]">
                  {domains.length} Active Tracks
                </span>
              </div>

              {/* Proportional Progress Bars */}
              <div className="space-y-4">
                {popularDomains.slice(0, 6).map((item, idx) => {
                  const barWidthPct = Math.max(Math.round((item.count / maxDomainCount) * 100), 6);
                  const barColors = [
                    '#6D5DFB', // Primary violet
                    '#8B5CF6', // Purple
                    '#3B82F6', // Blue
                    '#06B6D4', // Cyan
                    '#10B981', // Emerald
                    '#F59E0B'  // Amber
                  ];
                  const barColor = barColors[idx % barColors.length];

                  return (
                    <div
                      key={item.name}
                      onClick={() => onNavigate('domains')}
                      className="group cursor-pointer p-2 -mx-2 rounded-xl hover:bg-slate-50 transition-colors"
                    >
                      <div className="flex items-center justify-between text-xs mb-1.5">
                        <span className="font-semibold text-slate-800 group-hover:text-[#6D5DFB] transition-colors truncate max-w-[210px]">
                          {item.name}
                        </span>
                        <div className="flex items-center gap-2 font-mono text-xs">
                          <span className="font-bold text-[#111827]">{item.count} scans</span>
                          <span className="text-[11px] text-slate-400">({item.percentage}%)</span>
                        </div>
                      </div>

                      {/* Progress Bar Container */}
                      <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                        <div
                          className="h-full rounded-full transition-all duration-500 ease-out group-hover:brightness-110"
                          style={{
                            width: `${barWidthPct}%`,
                            backgroundColor: barColor
                          }}
                        />
                      </div>
                    </div>
                  );
                })}

                {popularDomains.length === 0 && (
                  <div className="py-8 text-center text-slate-400 text-xs">
                    No domain data recorded yet.
                  </div>
                )}
              </div>
            </div>

            {/* Bottom Action Footer */}
            <div className="mt-6 pt-4 border-t border-slate-100">
              <button
                onClick={() => onNavigate('domains')}
                className="w-full py-2.5 px-3 text-xs font-bold text-[#6D5DFB] bg-[#F1EEFF] hover:bg-[#E8E4FF] rounded-xl transition-colors flex items-center justify-center gap-1.5"
              >
                <Briefcase className="w-4 h-4" />
                <span>Manage All Job Domains & Roles</span>
                <ChevronRight className="w-4 h-4 ml-0.5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
