import React, { useState } from 'react';
import {
  UserCheck,
  Key,
  Shield,
  Eye,
  EyeOff,
  Save,
  CheckCircle2,
  AlertTriangle,
  Lock,
  Smartphone,
  Globe,
  Clock,
  LogOut,
  Server,
  Database
} from 'lucide-react';
import { ResuNovaStore } from '../services/storage';
import { AdminProfile } from '../types';
import { ConfirmDialog } from '../components/common/ConfirmDialog';
import { useToast } from '../context/ToastContext';

interface AdminProfileViewProps {
  onLogout: () => void;
  onOpenFlaskModal: () => void;
}

export const AdminProfileView: React.FC<AdminProfileViewProps> = ({
  onLogout,
  onOpenFlaskModal,
}) => {
  const [profile, setProfile] = useState<AdminProfile>(() => ResuNovaStore.getAdminProfile());

  // Profile Edit fields
  const [name, setName] = useState(profile.name);
  const [email, setEmail] = useState(profile.email);
  const [department, setDepartment] = useState(profile.department);

  // Change Password fields
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  // 2FA & Security toggles
  const [twoFactor, setTwoFactor] = useState(profile.twoFactorEnabled);
  const [sessionTimeout, setSessionTimeout] = useState(profile.sessionTimeoutMinutes);

  const [isLogoutConfirmOpen, setIsLogoutConfirmOpen] = useState(false);

  const toast = useToast();

  const handleUpdateProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim()) {
      toast.warning('Validation', 'Name and email are required.');
      return;
    }

    const updated = ResuNovaStore.updateAdminProfile({
      name: name.trim(),
      email: email.trim(),
      department: department.trim()
    });

    setProfile(updated);
    toast.success('Profile Saved', 'Administrative details updated in database.');
  };

  const calculatePasswordStrength = (pwd: string): { score: number; label: string; color: string } => {
    if (!pwd) return { score: 0, label: 'Empty', color: 'bg-slate-200' };
    let score = 0;
    if (pwd.length >= 8) score += 1;
    if (pwd.length >= 12) score += 1;
    if (/[A-Z]/.test(pwd)) score += 1;
    if (/[0-9]/.test(pwd)) score += 1;
    if (/[^A-Za-z0-9]/.test(pwd)) score += 1;

    if (score <= 2) return { score, label: 'Weak', color: 'bg-red-500' };
    if (score <= 3) return { score, label: 'Fair', color: 'bg-amber-500' };
    if (score <= 4) return { score, label: 'Strong', color: 'bg-blue-500' };
    return { score, label: 'Very Strong', color: 'bg-emerald-500' };
  };

  const strength = calculatePasswordStrength(newPassword);

  const handleChangePassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentPassword) {
      toast.warning('Verification', 'Please enter your current administrator password.');
      return;
    }
    if (newPassword.length < 8) {
      toast.warning('Security Rule', 'New password must be at least 8 characters.');
      return;
    }
    if (newPassword !== confirmPassword) {
      toast.error('Mismatch', 'New password and confirmation do not match.');
      return;
    }

    // In a real Flask backend, check_password_hash() verifies current password
    toast.success(
      'Password Updated',
      'Administrator credentials updated and active sessions rotated.'
    );
    setCurrentPassword('');
    setNewPassword('');
    setConfirmPassword('');
  };

  const handleToggle2FA = () => {
    const nextVal = !twoFactor;
    setTwoFactor(nextVal);
    ResuNovaStore.updateAdminProfile({ twoFactorEnabled: nextVal });
    toast.success(
      `2FA ${nextVal ? 'Enabled' : 'Disabled'}`,
      `Two-factor authentication is now ${nextVal ? 'active' : 'inactive'}.`
    );
  };

  const handleTimeoutChange = (val: number) => {
    setSessionTimeout(val);
    ResuNovaStore.updateAdminProfile({ sessionTimeoutMinutes: val });
    toast.success('Session Rule Saved', `Automatic inactivity logout set to ${val} minutes.`);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Admin Profile Header Card */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-5">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-[#6D5DFB] via-[#8B5CF6] to-[#4F46E5] text-white flex items-center justify-center font-bold text-2xl shadow-md shadow-[#6D5DFB]/20 shrink-0">
            I
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold text-[#111827]">{profile.name}</h2>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-[#F1EEFF] text-[#6D5DFB] border border-[#6D5DFB]/30">
                {profile.role}
              </span>
            </div>
            <p className="text-xs text-slate-500 font-mono mt-0.5">{profile.email}</p>
            <p className="text-xs text-slate-600 mt-1">{profile.department}</p>
          </div>
        </div>

        <div className="flex items-center gap-2.5 self-end sm:self-auto">
          <button
            onClick={onOpenFlaskModal}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-[#6D5DFB] bg-[#F1EEFF] hover:bg-[#E8E4FF] rounded-xl transition-colors border border-[#6D5DFB]/20"
          >
            <Server className="w-3.5 h-3.5" />
            <span>Flask & MySQL Specs</span>
          </button>
          <button
            onClick={() => setIsLogoutConfirmOpen(true)}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-[#DC2626] bg-red-50 hover:bg-red-100 rounded-xl transition-colors border border-red-200"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Log Out</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Section 1: Edit Account Information */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-[#111827] mb-1 flex items-center gap-2">
              <UserCheck className="w-4 h-4 text-[#6D5DFB]" />
              Account Information
            </h3>
            <p className="text-xs text-[#6B7280] mb-4">
              Update administrative display identity and institutional department
            </p>

            <form onSubmit={handleUpdateProfile} className="space-y-3.5">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Administrator Name
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={e => setName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-[#1F2937] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Email Address
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-[#1F2937] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Department / Institution Unit
                </label>
                <input
                  type="text"
                  value={department}
                  onChange={e => setDepartment(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-[#1F2937] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Administrative Privilege
                </label>
                <input
                  type="text"
                  disabled
                  value="Full Cluster Superadmin (RBAC: Tier 1)"
                  className="w-full bg-slate-100 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-500 font-mono"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-[#6D5DFB] hover:bg-[#5B4BE3] rounded-xl transition-colors shadow-xs"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Save Profile Updates</span>
                </button>
              </div>
            </form>
          </div>
        </div>

        {/* Section 2: Change Password Form */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-[#111827] mb-1 flex items-center gap-2">
              <Key className="w-4 h-4 text-[#6D5DFB]" />
              Change Administrator Password
            </h3>
            <p className="text-xs text-[#6B7280] mb-4">
              Requires verification of current password and enforces bcrypt salted complexity
            </p>

            <form onSubmit={handleChangePassword} className="space-y-3.5">
              {/* Current Password */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Current Password *
                </label>
                <div className="relative">
                  <input
                    type={showCurrent ? 'text' : 'password'}
                    required
                    placeholder="Enter current administrative password"
                    value={currentPassword}
                    onChange={e => setCurrentPassword(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-3 pr-9 py-2 text-xs text-[#1F2937] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
                  />
                  <button
                    type="button"
                    onClick={() => setShowCurrent(!showCurrent)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    {showCurrent ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* New Password */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  New Password *
                </label>
                <div className="relative">
                  <input
                    type={showNew ? 'text' : 'password'}
                    required
                    placeholder="At least 8 characters with numbers & symbols"
                    value={newPassword}
                    onChange={e => setNewPassword(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-3 pr-9 py-2 text-xs text-[#1F2937] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
                  />
                  <button
                    type="button"
                    onClick={() => setShowNew(!showNew)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    {showNew ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>

                {/* Password Strength Indicator */}
                {newPassword && (
                  <div className="mt-2">
                    <div className="flex items-center justify-between text-[11px] mb-1">
                      <span className="text-slate-500">Strength:</span>
                      <span className="font-bold text-slate-700">{strength.label}</span>
                    </div>
                    <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden flex gap-0.5">
                      {[1, 2, 3, 4, 5].map(step => (
                        <div
                          key={step}
                          className={`h-full flex-1 rounded-full transition-all duration-300 ${
                            step <= strength.score ? strength.color : 'bg-slate-200'
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Confirm Password */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Confirm New Password *
                </label>
                <div className="relative">
                  <input
                    type={showConfirm ? 'text' : 'password'}
                    required
                    placeholder="Re-enter new password"
                    value={confirmPassword}
                    onChange={e => setConfirmPassword(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-3 pr-9 py-2 text-xs text-[#1F2937] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirm(!showConfirm)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    {showConfirm ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-[#111827] hover:bg-slate-800 rounded-xl transition-colors shadow-xs"
                >
                  <Lock className="w-3.5 h-3.5" />
                  <span>Update Password</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>

      {/* Security Policies & Active Sessions */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
        <h3 className="text-sm font-bold text-[#111827] mb-1 flex items-center gap-2">
          <Shield className="w-4 h-4 text-[#16A34A]" />
          Platform Security Governance & Authentication Settings
        </h3>
        <p className="text-xs text-[#6B7280] mb-4">
          Session controls, rate limiting safeguards, and authorized devices
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pb-4 border-b border-slate-100">
          {/* 2FA Toggle */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center justify-between">
            <div>
              <div className="flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-[#6D5DFB]" />
                <h4 className="text-xs font-bold text-[#111827]">Two-Factor Authentication</h4>
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                Enforces TOTP code validation for admin logins
              </p>
            </div>
            <button
              onClick={handleToggle2FA}
              className={`w-12 h-6 rounded-full transition-colors relative p-0.5 ${
                twoFactor ? 'bg-[#16A34A]' : 'bg-slate-300'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  twoFactor ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Session Timeout */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center justify-between">
            <div>
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-[#6D5DFB]" />
                <h4 className="text-xs font-bold text-[#111827]">Inactivity Session Timeout</h4>
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                Automatically invalidates JWT token after inactivity
              </p>
            </div>
            <select
              value={sessionTimeout}
              onChange={e => handleTimeoutChange(Number(e.target.value))}
              className="bg-white border border-slate-200 rounded-lg px-2 py-1 text-xs text-slate-700 font-mono font-bold focus:outline-none"
            >
              <option value={15}>15 mins</option>
              <option value={30}>30 mins</option>
              <option value={60}>60 mins</option>
              <option value={120}>120 mins</option>
            </select>
          </div>
        </div>

        {/* Active Sessions List */}
        <div className="mt-4">
          <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
            Active Administrative Sessions (2)
          </h4>
          <div className="space-y-2">
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/70 flex items-center justify-between text-xs">
              <div className="flex items-center gap-3">
                <Globe className="w-4 h-4 text-[#16A34A]" />
                <div>
                  <span className="font-bold text-[#111827]">Chrome 128 · macOS Sonoma</span>
                  <span className="text-slate-400 font-mono text-[11px] block">
                    IP: 192.168.1.104 · Current Session
                  </span>
                </div>
              </div>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-emerald-50 text-[#16A34A] border border-emerald-200">
                Active Now
              </span>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/70 flex items-center justify-between text-xs">
              <div className="flex items-center gap-3">
                <Globe className="w-4 h-4 text-slate-400" />
                <div>
                  <span className="font-bold text-[#111827]">Firefox 130 · Ubuntu Linux Workstation</span>
                  <span className="text-slate-400 font-mono text-[11px] block">
                    IP: 10.0.4.12 · Last active 3h ago
                  </span>
                </div>
              </div>
              <span className="text-[11px] text-slate-400 font-mono">Standby</span>
            </div>
          </div>
        </div>
      </div>

      {/* Logout Confirmation */}
      <ConfirmDialog
        isOpen={isLogoutConfirmOpen}
        onClose={() => setIsLogoutConfirmOpen(false)}
        onConfirm={() => {
          setIsLogoutConfirmOpen(false);
          onLogout();
        }}
        title="Log Out of ResuNova?"
        message="Are you sure you want to end your active administrative JWT session? You will be returned to the secure sign-in portal."
        confirmText="Log Out"
        variant="warning"
      />
    </div>
  );
};
