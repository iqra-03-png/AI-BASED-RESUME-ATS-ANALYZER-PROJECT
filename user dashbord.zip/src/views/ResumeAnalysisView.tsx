import React, { useState, useMemo } from 'react';
import {
  FileSearch,
  Search,
  Filter,
  Download,
  Trash2,
  RefreshCw,
  Eye,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Award,
  Zap,
  Clock,
  FileText,
  ShieldAlert,
  ChevronRight,
  TrendingUp,
  Sliders
} from 'lucide-react';
import { ResuNovaStore } from '../services/storage';
import { ResumeAnalysis, AnalysisStatus, JobDomain } from '../types';
import { Modal } from '../components/common/Modal';
import { ConfirmDialog } from '../components/common/ConfirmDialog';
import { useToast } from '../context/ToastContext';

interface ResumeAnalysisViewProps {
  initialSelectedAnalysis?: ResumeAnalysis | null;
  onClearInitialSelection?: () => void;
}

export const ResumeAnalysisView: React.FC<ResumeAnalysisViewProps> = ({
  initialSelectedAnalysis,
  onClearInitialSelection
}) => {
  const [analyses, setAnalyses] = useState<ResumeAnalysis[]>(() => ResuNovaStore.getAnalyses());
  const [domains] = useState<JobDomain[]>(() => ResuNovaStore.getDomains());

  const [searchQuery, setSearchQuery] = useState('');
  const [domainFilter, setDomainFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [scoreFilter, setScoreFilter] = useState<string>('all');

  const [selectedAnalysis, setSelectedAnalysis] = useState<ResumeAnalysis | null>(
    initialSelectedAnalysis || null
  );
  const [analysisToDelete, setAnalysisToDelete] = useState<ResumeAnalysis | null>(null);
  const [isRetrying, setIsRetrying] = useState(false);

  const toast = useToast();

  const reloadAnalyses = () => {
    setAnalyses(ResuNovaStore.getAnalyses());
  };

  const filteredAnalyses = useMemo(() => {
    return analyses.filter(item => {
      const matchesSearch =
        item.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.userName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.userEmail.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.jobRoleTitle.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesDomain =
        domainFilter === 'all' || item.jobDomainId === domainFilter;

      const matchesStatus =
        statusFilter === 'all' || item.status === statusFilter;

      let matchesScore = true;
      if (scoreFilter === 'high') matchesScore = item.atsScore >= 80;
      else if (scoreFilter === 'mid') matchesScore = item.atsScore >= 60 && item.atsScore < 80;
      else if (scoreFilter === 'low') matchesScore = item.atsScore < 60;

      return matchesSearch && matchesDomain && matchesStatus && matchesScore;
    });
  }, [analyses, searchQuery, domainFilter, statusFilter, scoreFilter]);

  const handleRetry = (id: string) => {
    setIsRetrying(true);
    setTimeout(() => {
      const updated = ResuNovaStore.retryAnalysis(id);
      setIsRetrying(false);
      if (updated) {
        toast.success(
          'Reprocessing Succeeded',
          `Analysis ${id} normalized through NLP fallback parser. Score: ${updated.atsScore}%`
        );
        setSelectedAnalysis(updated);
        reloadAnalyses();
      } else {
        toast.error('Reprocess Error', 'Could not re-evaluate analysis.');
      }
    }, 800);
  };

  const handleDeleteConfirm = () => {
    if (!analysisToDelete) return;
    ResuNovaStore.deleteAnalysis(analysisToDelete.id);
    toast.success('Record Deleted', `Analysis ${analysisToDelete.id} removed from database.`);
    if (selectedAnalysis?.id === analysisToDelete.id) {
      setSelectedAnalysis(null);
    }
    setAnalysisToDelete(null);
    reloadAnalyses();
  };

  const handleExportCSV = () => {
    const headers = [
      'Analysis ID',
      'User Name',
      'Email',
      'Domain',
      'Job Role',
      'ATS Score',
      'Status',
      'Analysis Date',
      'Matched Skills Count',
      'Missing Skills Count'
    ];
    const rows = filteredAnalyses.map(a => [
      a.id,
      `"${a.userName}"`,
      `"${a.userEmail}"`,
      `"${a.jobDomainName}"`,
      `"${a.jobRoleTitle}"`,
      a.atsScore,
      a.status,
      a.analysisDate,
      a.matchedSkills.length,
      a.missingSkills.length
    ]);
    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute(
      'download',
      `resunova_ats_analyses_${new Date().toISOString().slice(0, 10)}.csv`
    );
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast.success('Export Generated', `Exported ${filteredAnalyses.length} analysis logs to CSV.`);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Search and Filters Header */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2 flex-1">
          <div className="relative min-w-[200px] flex-1 max-w-xs">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              placeholder="Search ID, user, role..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full bg-white border border-slate-200 rounded-xl pl-9 pr-3 py-2 text-xs text-[#1F2937] placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
            />
          </div>

          <select
            value={domainFilter}
            onChange={e => setDomainFilter(e.target.value)}
            className="bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-700 focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
          >
            <option value="all">All Domains</option>
            {domains.map(d => (
              <option key={d.id} value={d.id}>
                {d.name}
              </option>
            ))}
          </select>

          <select
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value)}
            className="bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-700 focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
          >
            <option value="all">All Statuses</option>
            <option value="Completed">Completed</option>
            <option value="Failed">Failed / Flagged</option>
          </select>

          <select
            value={scoreFilter}
            onChange={e => setScoreFilter(e.target.value)}
            className="bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-700 focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
          >
            <option value="all">All Score Tiers</option>
            <option value="high">High ATS (&ge; 80%)</option>
            <option value="mid">Mid ATS (60% - 79%)</option>
            <option value="low">Low ATS (&lt; 60%)</option>
          </select>
        </div>

        <button
          onClick={handleExportCSV}
          className="flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-xl transition-colors shadow-xs shrink-0 self-start sm:self-auto"
        >
          <Download className="w-3.5 h-3.5 text-slate-500" />
          <span>Export CSV</span>
        </button>
      </div>

      {/* Main Analysis Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 uppercase font-semibold border-b border-slate-200/80">
              <tr>
                <th className="py-3 px-4">Analysis ID</th>
                <th className="py-3 px-4">Candidate</th>
                <th className="py-3 px-4">Target Role & Domain</th>
                <th className="py-3 px-4 text-center">ATS Score</th>
                <th className="py-3 px-4">Analysis Date</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredAnalyses.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400">
                    <p className="font-semibold text-slate-600 mb-1">No analysis records found</p>
                    <p className="text-xs">Adjust your search or score tier filter.</p>
                  </td>
                </tr>
              ) : (
                filteredAnalyses.map(item => (
                  <tr key={item.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-[#6D5DFB]">
                      {item.id}
                    </td>
                    <td className="py-3 px-4 font-semibold text-[#111827]">
                      <div>
                        <span>{item.userName}</span>
                        <span className="block text-[11px] text-slate-400 font-mono font-normal">
                          {item.userEmail}
                        </span>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <span className="font-medium text-slate-800 block">
                        {item.jobRoleTitle}
                      </span>
                      <span className="text-[11px] text-slate-400 block">
                        {item.jobDomainName}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span
                        className={`inline-block font-mono font-bold text-sm tabular-nums px-2.5 py-0.5 rounded-lg ${
                          item.status === 'Failed'
                            ? 'bg-red-50 text-[#DC2626] border border-red-200'
                            : item.atsScore >= 80
                            ? 'bg-emerald-50 text-[#16A34A] border border-emerald-200'
                            : item.atsScore >= 60
                            ? 'bg-amber-50 text-[#F59E0B] border border-amber-200'
                            : 'bg-red-50 text-[#DC2626] border border-red-200'
                        }`}
                      >
                        {item.status === 'Failed' ? 'FAILED' : `${item.atsScore}%`}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-500">
                      {item.analysisDate}
                    </td>
                    <td className="py-3 px-4">
                      <span
                        className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                          item.status === 'Completed'
                            ? 'bg-emerald-50 text-[#16A34A] border border-emerald-200'
                            : 'bg-red-50 text-[#DC2626] border border-red-200'
                        }`}
                      >
                        <span
                          className={`w-1.5 h-1.5 rounded-full ${
                            item.status === 'Completed' ? 'bg-[#16A34A]' : 'bg-[#DC2626]'
                          }`}
                        />
                        {item.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => setSelectedAnalysis(item)}
                          className="px-2.5 py-1 text-xs font-semibold text-[#6D5DFB] bg-[#F1EEFF] hover:bg-[#E8E4FF] rounded-lg transition-colors"
                        >
                          Inspect
                        </button>
                        <button
                          onClick={() => setAnalysisToDelete(item)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-[#DC2626] hover:bg-red-50 transition-colors"
                          title="Delete record"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Detailed Analysis Modal */}
      {selectedAnalysis && (
        <Modal
          isOpen={!!selectedAnalysis}
          onClose={() => {
            setSelectedAnalysis(null);
            if (onClearInitialSelection) onClearInitialSelection();
          }}
          title={`ATS Evaluation: ${selectedAnalysis.id}`}
          subtitle={`${selectedAnalysis.jobRoleTitle} · Candidate: ${selectedAnalysis.userName}`}
          maxWidth="3xl"
          footer={
            <div className="flex items-center justify-between w-full">
              {selectedAnalysis.status === 'Failed' ? (
                <button
                  type="button"
                  disabled={isRetrying}
                  onClick={() => handleRetry(selectedAnalysis.id)}
                  className="flex items-center gap-2 px-3.5 py-2 text-xs font-bold text-white bg-[#6D5DFB] hover:bg-[#5B4BE3] rounded-lg transition-colors disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isRetrying ? 'animate-spin' : ''}`} />
                  <span>{isRetrying ? 'Reprocessing OCR...' : 'Retry Failed NLP Parse'}</span>
                </button>
              ) : (
                <span className="text-[11px] text-slate-400 font-mono">
                  Scanned in {selectedAnalysis.processingTimeMs}ms · File: {selectedAnalysis.fileName} ({selectedAnalysis.fileSizeKb} KB)
                </span>
              )}

              <button
                type="button"
                onClick={() => {
                  setSelectedAnalysis(null);
                  if (onClearInitialSelection) onClearInitialSelection();
                }}
                className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
              >
                Close
              </button>
            </div>
          }
        >
          <div className="space-y-5">
            {/* Top Score Banner */}
            <div className="p-5 rounded-2xl bg-gradient-to-r from-slate-900 to-[#172554] text-white flex flex-col sm:flex-row items-center justify-between gap-5 shadow-sm">
              <div className="flex items-center gap-4">
                {/* Circular Score Gauge */}
                <div className="relative w-20 h-20 shrink-0 flex items-center justify-center">
                  <svg viewBox="0 0 36 36" className="w-full h-full transform -rotate-90">
                    <path
                      d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                      fill="none"
                      stroke="rgba(255,255,255,0.15)"
                      strokeWidth="3.5"
                    />
                    <path
                      d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                      fill="none"
                      stroke={
                        selectedAnalysis.status === 'Failed'
                          ? '#EF4444'
                          : selectedAnalysis.atsScore >= 80
                          ? '#10B981'
                          : '#F59E0B'
                      }
                      strokeWidth="3.5"
                      strokeDasharray={`${selectedAnalysis.status === 'Failed' ? 10 : selectedAnalysis.atsScore}, 100`}
                    />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <span className="font-mono font-extrabold text-xl text-white">
                      {selectedAnalysis.status === 'Failed' ? '!' : `${selectedAnalysis.atsScore}%`}
                    </span>
                  </div>
                </div>

                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-lg font-bold text-white">
                      Overall ATS Match Score
                    </h3>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                      selectedAnalysis.status === 'Completed' ? 'bg-[#16A34A]/30 text-emerald-300' : 'bg-red-500/30 text-red-300'
                    }`}>
                      {selectedAnalysis.status}
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 mt-1 max-w-md">
                    {selectedAnalysis.summaryFeedback}
                  </p>
                </div>
              </div>

              {selectedAnalysis.failureReason && (
                <div className="bg-red-950/60 border border-red-500/30 p-3 rounded-xl max-w-xs text-xs text-red-200">
                  <span className="font-bold block mb-0.5 text-red-300">Failure Diagnostic:</span>
                  {selectedAnalysis.failureReason}
                </div>
              )}
            </div>

            {/* Score Breakdown Rubric */}
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
              <h4 className="text-xs font-bold text-[#111827] uppercase tracking-wider mb-3">
                Scoring Rubric Breakdown
              </h4>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div className="bg-white p-3 rounded-lg border border-slate-200/80">
                  <span className="text-slate-500 text-[11px] block">Skill Match (40%)</span>
                  <span className="font-mono font-bold text-base text-[#111827]">
                    {selectedAnalysis.scoreBreakdown.skillMatch} / 40
                  </span>
                </div>
                <div className="bg-white p-3 rounded-lg border border-slate-200/80">
                  <span className="text-slate-500 text-[11px] block">Keyword Density (25%)</span>
                  <span className="font-mono font-bold text-base text-[#111827]">
                    {selectedAnalysis.scoreBreakdown.keywordDensity} / 25
                  </span>
                </div>
                <div className="bg-white p-3 rounded-lg border border-slate-200/80">
                  <span className="text-slate-500 text-[11px] block">Structure (20%)</span>
                  <span className="font-mono font-bold text-base text-[#111827]">
                    {selectedAnalysis.scoreBreakdown.sectionStructure} / 20
                  </span>
                </div>
                <div className="bg-white p-3 rounded-lg border border-slate-200/80">
                  <span className="text-slate-500 text-[11px] block">Formatting (15%)</span>
                  <span className="font-mono font-bold text-base text-[#111827]">
                    {selectedAnalysis.scoreBreakdown.formatting} / 15
                  </span>
                </div>
              </div>
            </div>

            {/* Matched & Missing Skills Comparison */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Matched Skills */}
              <div className="p-4 bg-emerald-50/50 rounded-xl border border-emerald-200/80">
                <h4 className="text-xs font-bold text-[#16A34A] uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4" />
                  Matched Skills ({selectedAnalysis.matchedSkills.length})
                </h4>
                {selectedAnalysis.matchedSkills.length === 0 ? (
                  <p className="text-xs text-slate-400 italic">No skills matched.</p>
                ) : (
                  <div className="space-y-2">
                    {selectedAnalysis.matchedSkills.map((sk, i) => (
                      <div key={i} className="p-2.5 bg-white rounded-lg border border-emerald-100 text-xs">
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-bold text-slate-900">{sk.name}</span>
                          <span className="font-mono text-[10px] text-emerald-600 font-bold">
                            {sk.weight}x
                          </span>
                        </div>
                        <p className="text-slate-500 text-[11px] italic leading-tight">
                          "{sk.foundContext}"
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Missing Skills */}
              <div className="p-4 bg-red-50/50 rounded-xl border border-red-200/80">
                <h4 className="text-xs font-bold text-[#DC2626] uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4" />
                  Missing Required Skills ({selectedAnalysis.missingSkills.length})
                </h4>
                {selectedAnalysis.missingSkills.length === 0 ? (
                  <p className="text-xs text-emerald-700 font-medium">
                    All benchmark role skills are present in the resume!
                  </p>
                ) : (
                  <div className="space-y-2">
                    {selectedAnalysis.missingSkills.map((sk, i) => (
                      <div key={i} className="p-2.5 bg-white rounded-lg border border-red-100 text-xs">
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-bold text-slate-900">{sk.name}</span>
                          <span className="text-[10px] uppercase font-bold text-red-600 px-1 bg-red-50 rounded">
                            {sk.importance} Priority
                          </span>
                        </div>
                        <p className="text-slate-600 text-[11px] leading-tight">
                          {sk.recommendation}
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </Modal>
      )}

      {/* Delete Confirmation */}
      <ConfirmDialog
        isOpen={!!analysisToDelete}
        onClose={() => setAnalysisToDelete(null)}
        onConfirm={handleDeleteConfirm}
        title="Delete Resume Analysis Record?"
        message={`Are you sure you want to permanently remove analysis ${analysisToDelete?.id} for ${analysisToDelete?.userName}?`}
        confirmText="Confirm Delete"
        variant="danger"
      />
    </div>
  );
};
