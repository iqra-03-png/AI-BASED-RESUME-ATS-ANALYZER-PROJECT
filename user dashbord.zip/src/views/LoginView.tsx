import React, { useState } from 'react';
import {
  Lock,
  Mail,
  Eye,
  EyeOff,
  ArrowRight,
  ShieldCheck,
  Server,
  Sparkles,
  Key,
  User as UserIcon,
  Building,
  CheckCircle2,
  UserPlus
} from 'lucide-react';
import { useToast } from '../context/ToastContext';
import { ResuNovaStore } from '../services/storage';

interface LoginViewProps {
  onLoginSuccess: () => void;
}

export const LoginView: React.FC<LoginViewProps> = ({ onLoginSuccess }) => {
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signin');

  // Sign In State
  const [email, setEmail] = useState('admin@resunova.ai');
  const [password, setPassword] = useState('ResuNova@2026!');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);

  // Sign Up / Create Account State
  const [signupName, setSignupName] = useState('');
  const [signupEmail, setSignupEmail] = useState('');
  const [signupDepartment, setSignupDepartment] = useState('Academic Career & Placement Technologies');
  const [signupRole, setSignupRole] = useState<'Super Admin' | 'ATS Evaluation Lead' | 'Academic Faculty Admin'>('Super Admin');
  const [signupPassword, setSignupPassword] = useState('');
  const [signupConfirmPassword, setSignupConfirmPassword] = useState('');
  const [showSignupPassword, setShowSignupPassword] = useState(false);
  const [agreedToTerms, setAgreedToTerms] = useState(true);

  const toast = useToast();

  const handleSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password.trim()) {
      toast.warning('Input Required', 'Please enter administrative email and password.');
      return;
    }

    setIsLoading(true);

    // Simulate real JWT authentication roundtrip with Flask backend
    setTimeout(() => {
      setIsLoading(false);
      if (email.toLowerCase() === 'admin@resunova.ai' || email.includes('@')) {
        toast.success(
          'Authentication Verified',
          'JWT session token issued. Welcome to ResuNova Administration.'
        );
        onLoginSuccess();
      } else {
        toast.error('Invalid Credentials', 'Administrative authorization denied.');
      }
    }, 600);
  };

  const handleSignUp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!signupName.trim()) {
      toast.warning('Validation', 'Please enter administrator full name.');
      return;
    }
    if (!signupEmail.trim() || !signupEmail.includes('@')) {
      toast.warning('Validation', 'Please enter a valid administrative email.');
      return;
    }
    if (signupPassword.length < 8) {
      toast.warning('Password Rule', 'Password must be at least 8 characters long.');
      return;
    }
    if (signupPassword !== signupConfirmPassword) {
      toast.error('Password Mismatch', 'Password and confirm password do not match.');
      return;
    }
    if (!agreedToTerms) {
      toast.warning('Terms Required', 'Please accept institutional security governance.');
      return;
    }

    setIsLoading(true);

    setTimeout(() => {
      setIsLoading(false);
      // Persist administrator details
      ResuNovaStore.updateAdminProfile({
        name: signupName.trim(),
        email: signupEmail.trim(),
        role: signupRole,
        department: signupDepartment.trim(),
        lastLogin: new Date().toISOString().replace('T', ' ').slice(0, 16) + ' UTC'
      });

      toast.success(
        'Account Registered',
        `Administrator account created for ${signupName.trim()}. Session authenticated.`
      );
      onLoginSuccess();
    }, 700);
  };

  const handleFillDemo = () => {
    setEmail('admin@resunova.ai');
    setPassword('ResuNova@2026!');
    toast.info('Demo Credentials Loaded', 'Standard faculty presentation administrator account applied.');
  };

  return (
    <div className="min-h-screen bg-[#111827] flex flex-col justify-center py-10 sm:px-6 lg:px-8 relative overflow-hidden select-none">
      {/* Ambient Radial Gradient Glows (Navy + Electric Violet) */}
      <div className="absolute top-0 -left-40 w-96 h-96 bg-[#6D5DFB]/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 -right-40 w-96 h-96 bg-[#8B5CF6]/15 rounded-full blur-3xl pointer-events-none" />

      <div className="sm:mx-auto sm:w-full sm:max-w-md relative z-10 text-center">
        {/* Brand Logo: Document + Upward Growth + AI Spark */}
        <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-tr from-[#6D5DFB] via-[#8B5CF6] to-[#4F46E5] text-white shadow-xl shadow-[#6D5DFB]/30 mb-4">
          <svg
            viewBox="0 0 24 24"
            className="w-7 h-7 text-white"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
            <polyline points="14 2 14 8 20 8" />
            <path d="M8 15l3-3 2 2 4-5" />
            <polyline points="14 9 17 9 17 12" />
          </svg>
        </div>

        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          ResuNova
        </h1>
        <p className="mt-1 text-xs sm:text-sm text-slate-400 font-medium">
          AI Resume ATS Intelligence &bull; Administration Console
        </p>
      </div>

      <div className="mt-6 sm:mx-auto sm:w-full sm:max-w-md relative z-10 px-4 sm:px-0">
        <div className="bg-white/95 backdrop-blur-md py-7 px-6 sm:px-10 shadow-2xl rounded-3xl border border-slate-700/30">
          {/* Sign In vs Create Account Tabs */}
          <div className="flex bg-[#F1EEFF] p-1 rounded-xl mb-6">
            <button
              type="button"
              onClick={() => setAuthMode('signin')}
              className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
                authMode === 'signin'
                  ? 'bg-white text-[#6D5DFB] shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Sign In
            </button>
            <button
              type="button"
              onClick={() => setAuthMode('signup')}
              className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
                authMode === 'signup'
                  ? 'bg-white text-[#6D5DFB] shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Create Account
            </button>
          </div>

          {authMode === 'signin' ? (
            /* Sign In Form */
            <form className="space-y-4" onSubmit={handleSignIn}>
              <div>
                <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider mb-1">
                  Admin Email Address
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    placeholder="admin@resunova.ai"
                    className="w-full bg-[#F7F8FC] border border-slate-200 rounded-xl pl-9 pr-3 py-2.5 text-xs text-[#1F2937] placeholder-slate-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider mb-1">
                  Password
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    placeholder="Enter administrator password"
                    className="w-full bg-[#F7F8FC] border border-slate-200 rounded-xl pl-9 pr-9 py-2.5 text-xs text-[#1F2937] placeholder-slate-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between text-xs pt-1">
                <label className="flex items-center gap-2 cursor-pointer text-slate-600">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={e => setRememberMe(e.target.checked)}
                    className="rounded border-slate-300 text-[#6D5DFB] focus:ring-[#6D5DFB]"
                  />
                  <span>Remember session</span>
                </label>

                <button
                  type="button"
                  onClick={handleFillDemo}
                  className="text-xs font-bold text-[#6D5DFB] hover:text-[#5B4BE3] hover:underline"
                >
                  Fill Faculty Demo
                </button>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-[#6D5DFB] to-[#7C3AED] hover:from-[#5B4BE3] hover:to-[#6D28D9] transition-all shadow-md shadow-[#6D5DFB]/30 disabled:opacity-50"
                >
                  {isLoading ? (
                    <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                    <>
                      <span>Sign In to Admin Dashboard</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>

              <p className="text-center text-xs text-slate-500 pt-2">
                Don't have an administrator account?{' '}
                <button
                  type="button"
                  onClick={() => setAuthMode('signup')}
                  className="font-bold text-[#6D5DFB] hover:underline"
                >
                  Create one now
                </button>
              </p>
            </form>
          ) : (
            /* Create Account Form */
            <form className="space-y-3.5" onSubmit={handleSignUp}>
              <div>
                <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider mb-1">
                  Full Name
                </label>
                <div className="relative">
                  <UserIcon className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    required
                    value={signupName}
                    onChange={e => setSignupName(e.target.value)}
                    placeholder="e.g. Dr. Alex Mercer"
                    className="w-full bg-[#F7F8FC] border border-slate-200 rounded-xl pl-9 pr-3 py-2 text-xs text-[#1F2937] placeholder-slate-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider mb-1">
                  Administrative Email
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="email"
                    required
                    value={signupEmail}
                    onChange={e => setSignupEmail(e.target.value)}
                    placeholder="alex.mercer@resunova.ai"
                    className="w-full bg-[#F7F8FC] border border-slate-200 rounded-xl pl-9 pr-3 py-2 text-xs text-[#1F2937] placeholder-slate-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider mb-1">
                    Role
                  </label>
                  <select
                    value={signupRole}
                    onChange={e => setSignupRole(e.target.value as any)}
                    className="w-full bg-[#F7F8FC] border border-slate-200 rounded-xl px-2.5 py-2 text-xs text-[#1F2937] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
                  >
                    <option value="Super Admin">Super Admin</option>
                    <option value="ATS Evaluation Lead">ATS Evaluation Lead</option>
                    <option value="Academic Faculty Admin">Academic Faculty Admin</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider mb-1">
                    Department
                  </label>
                  <input
                    type="text"
                    value={signupDepartment}
                    onChange={e => setSignupDepartment(e.target.value)}
                    className="w-full bg-[#F7F8FC] border border-slate-200 rounded-xl px-2.5 py-2 text-xs text-[#1F2937] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider mb-1">
                  Password (min. 8 characters)
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type={showSignupPassword ? 'text' : 'password'}
                    required
                    value={signupPassword}
                    onChange={e => setSignupPassword(e.target.value)}
                    placeholder="Create strong password"
                    className="w-full bg-[#F7F8FC] border border-slate-200 rounded-xl pl-9 pr-9 py-2 text-xs text-[#1F2937] placeholder-slate-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
                  />
                  <button
                    type="button"
                    onClick={() => setShowSignupPassword(!showSignupPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    {showSignupPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider mb-1">
                  Confirm Password
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="password"
                    required
                    value={signupConfirmPassword}
                    onChange={e => setSignupConfirmPassword(e.target.value)}
                    placeholder="Re-enter password"
                    className="w-full bg-[#F7F8FC] border border-slate-200 rounded-xl pl-9 pr-3 py-2 text-xs text-[#1F2937] placeholder-slate-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
                  />
                </div>
              </div>

              <div className="pt-1">
                <label className="flex items-start gap-2 cursor-pointer text-xs text-slate-600">
                  <input
                    type="checkbox"
                    checked={agreedToTerms}
                    onChange={e => setAgreedToTerms(e.target.checked)}
                    className="mt-0.5 rounded border-slate-300 text-[#6D5DFB] focus:ring-[#6D5DFB]"
                  />
                  <span>
                    I confirm administrative role credentials & institutional data governance.
                  </span>
                </label>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-[#6D5DFB] to-[#7C3AED] hover:from-[#5B4BE3] hover:to-[#6D28D9] transition-all shadow-md shadow-[#6D5DFB]/30 disabled:opacity-50"
                >
                  {isLoading ? (
                    <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                    <>
                      <UserPlus className="w-4 h-4" />
                      <span>Register & Access Dashboard</span>
                    </>
                  )}
                </button>
              </div>

              <p className="text-center text-xs text-slate-500 pt-1">
                Already have an administrator account?{' '}
                <button
                  type="button"
                  onClick={() => setAuthMode('signin')}
                  className="font-bold text-[#6D5DFB] hover:underline"
                >
                  Sign In here
                </button>
              </p>
            </form>
          )}

          {/* Quick Info Box */}
          <div className="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
            <span className="flex items-center gap-1.5 text-slate-600 font-semibold">
              <ShieldCheck className="w-4 h-4 text-[#16A34A]" />
              JWT Protected Route
            </span>
            <span className="font-mono text-slate-400">
              Flask 3.1 &bull; MySQL 8.0
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
