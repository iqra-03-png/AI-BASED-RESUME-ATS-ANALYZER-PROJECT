import React, { useState, useMemo } from 'react';
import {
  Zap,
  Search,
  Plus,
  Filter,
  Edit2,
  Trash2,
  Sliders,
  CheckCircle2,
  AlertCircle,
  Layers,
  ArrowUpDown
} from 'lucide-react';
import { ResuNovaStore } from '../services/storage';
import { Skill, SkillImportance, JobDomain } from '../types';
import { Modal } from '../components/common/Modal';
import { ConfirmDialog } from '../components/common/ConfirmDialog';
import { useToast } from '../context/ToastContext';

export const SkillsManagementView: React.FC = () => {
  const [skills, setSkills] = useState<Skill[]>(() => ResuNovaStore.getSkills());
  const [domains, setDomains] = useState<JobDomain[]>(() => ResuNovaStore.getDomains());

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDomainFilter, setSelectedDomainFilter] = useState<string>('all');
  const [selectedImportanceFilter, setSelectedImportanceFilter] = useState<string>('all');

  // Modal states
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [skillToEdit, setSkillToEdit] = useState<Skill | null>(null);
  const [skillToDelete, setSkillToDelete] = useState<Skill | null>(null);

  // Form states
  const [skillName, setSkillName] = useState('');
  const [skillCategory, setSkillCategory] = useState<Skill['category']>('Technical');
  const [skillDesc, setSkillDesc] = useState('');
  const [skillImportance, setSkillImportance] = useState<SkillImportance>('High');
  const [skillWeight, setSkillWeight] = useState<number>(2.5);
  const [selectedDomainIds, setSelectedDomainIds] = useState<string[]>([]);

  const toast = useToast();

  const reloadSkills = () => {
    setSkills(ResuNovaStore.getSkills());
    setDomains(ResuNovaStore.getDomains());
  };

  const filteredSkills = useMemo(() => {
    return skills.filter(skill => {
      const matchesSearch =
        skill.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        skill.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        skill.category.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesDomain =
        selectedDomainFilter === 'all' || skill.domainIds.includes(selectedDomainFilter);

      const matchesImportance =
        selectedImportanceFilter === 'all' || skill.importance === selectedImportanceFilter;

      return matchesSearch && matchesDomain && matchesImportance;
    });
  }, [skills, searchQuery, selectedDomainFilter, selectedImportanceFilter]);

  const handleOpenAdd = () => {
    setSkillName('');
    setSkillCategory('Technical');
    setSkillDesc('');
    setSkillImportance('High');
    setSkillWeight(2.5);
    setSelectedDomainIds([]);
    setIsAddModalOpen(true);
  };

  const handleOpenEdit = (skill: Skill) => {
    setSkillToEdit(skill);
    setSkillName(skill.name);
    setSkillCategory(skill.category);
    setSkillDesc(skill.description);
    setSkillImportance(skill.importance);
    setSkillWeight(skill.weight);
    setSelectedDomainIds(skill.domainIds);
  };

  const handleSaveSkill = (e: React.FormEvent) => {
    e.preventDefault();
    if (!skillName.trim()) {
      toast.warning('Validation', 'Skill name is required.');
      return;
    }

    if (skillToEdit) {
      ResuNovaStore.updateSkill(skillToEdit.id, {
        name: skillName.trim(),
        category: skillCategory,
        description: skillDesc.trim(),
        importance: skillImportance,
        weight: Number(skillWeight),
        domainIds: selectedDomainIds
      });
      toast.success('Skill Updated', `"${skillName}" settings updated.`);
      setSkillToEdit(null);
    } else {
      ResuNovaStore.addSkill({
        name: skillName.trim(),
        category: skillCategory,
        description: skillDesc.trim(),
        importance: skillImportance,
        weight: Number(skillWeight),
        domainIds: selectedDomainIds
      });
      toast.success('Skill Added', `"${skillName}" normalized in skills catalog.`);
      setIsAddModalOpen(false);
    }
    reloadSkills();
  };

  const handleDeleteConfirm = () => {
    if (!skillToDelete) return;
    const res = ResuNovaStore.deleteSkill(skillToDelete.id);
    if (!res.success) {
      toast.error('Deletion Blocked', res.error || 'Skill is assigned to active roles.');
    } else {
      toast.success('Skill Removed', `"${skillToDelete.name}" deleted.`);
      reloadSkills();
    }
    setSkillToDelete(null);
  };

  const toggleDomainSelection = (dId: string) => {
    setSelectedDomainIds(prev =>
      prev.includes(dId) ? prev.filter(id => id !== dId) : [...prev, dId]
    );
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Skills Metric Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs text-xs">
        <div>
          <span className="text-slate-400 block text-[11px] font-medium">Total Normalized Skills</span>
          <span className="text-lg font-bold font-mono text-[#111827]">{skills.length}</span>
        </div>
        <div>
          <span className="text-slate-400 block text-[11px] font-medium">High Priority Requirements</span>
          <span className="text-lg font-bold font-mono text-[#DC2626]">
            {skills.filter(s => s.importance === 'High').length}
          </span>
        </div>
        <div>
          <span className="text-slate-400 block text-[11px] font-medium">Medium Priority</span>
          <span className="text-lg font-bold font-mono text-[#F59E0B]">
            {skills.filter(s => s.importance === 'Medium').length}
          </span>
        </div>
        <div>
          <span className="text-slate-400 block text-[11px] font-medium">Covered Domains</span>
          <span className="text-lg font-bold font-mono text-[#6D5DFB]">{domains.length}</span>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2 flex-1">
          <div className="relative min-w-[220px] flex-1 max-w-xs">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              placeholder="Search skills, categories..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full bg-white border border-slate-200 rounded-xl pl-9 pr-3 py-2 text-xs text-[#1F2937] placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
            />
          </div>

          {/* Domain Filter */}
          <select
            value={selectedDomainFilter}
            onChange={e => setSelectedDomainFilter(e.target.value)}
            className="bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-700 focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
          >
            <option value="all">All Domains (8)</option>
            {domains.map(d => (
              <option key={d.id} value={d.id}>
                {d.name}
              </option>
            ))}
          </select>

          {/* Importance Filter */}
          <select
            value={selectedImportanceFilter}
            onChange={e => setSelectedImportanceFilter(e.target.value)}
            className="bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-700 focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
          >
            <option value="all">All Importance</option>
            <option value="High">High Priority</option>
            <option value="Medium">Medium Priority</option>
            <option value="Low">Low Priority</option>
          </select>
        </div>

        <button
          onClick={handleOpenAdd}
          className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-white bg-[#6D5DFB] hover:bg-[#5B4BE3] rounded-xl transition-colors shadow-xs shrink-0 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Skill</span>
        </button>
      </div>

      {/* Skills Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 uppercase font-semibold border-b border-slate-200/80">
              <tr>
                <th className="py-3 px-4">Skill Name</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Associated Domains</th>
                <th className="py-3 px-4">Importance</th>
                <th className="py-3 px-4 text-center">ATS Weight</th>
                <th className="py-3 px-4 text-center">Roles Using</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredSkills.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400">
                    <p className="font-semibold text-slate-600 mb-1">No skills match the criteria</p>
                    <p className="text-xs">Try selecting a different domain or clearing your search.</p>
                  </td>
                </tr>
              ) : (
                filteredSkills.map(skill => {
                  const domainNames = skill.domainIds
                    .map(dId => domains.find(d => d.id === dId)?.name)
                    .filter(Boolean);

                  return (
                    <tr key={skill.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3 px-4 font-bold text-[#111827]">
                        <div>
                          <span>{skill.name}</span>
                          <span className="block text-[11px] text-slate-400 font-normal line-clamp-1 max-w-xs mt-0.5">
                            {skill.description}
                          </span>
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <span className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-slate-100 text-slate-700">
                          {skill.category}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex flex-wrap gap-1 max-w-xs">
                          {domainNames.map((dName, i) => (
                            <span
                              key={i}
                              className="text-[10px] px-1.5 py-0.5 bg-slate-50 border border-slate-200 text-slate-600 rounded"
                            >
                              {dName}
                            </span>
                          ))}
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <span
                          className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                            skill.importance === 'High'
                              ? 'bg-red-50 text-[#DC2626] border border-red-200'
                              : skill.importance === 'Medium'
                              ? 'bg-amber-50 text-[#F59E0B] border border-amber-200'
                              : 'bg-slate-100 text-slate-600 border border-slate-200'
                          }`}
                        >
                          {skill.importance}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span className="font-mono font-bold text-[#6D5DFB] tabular-nums bg-[#F1EEFF] px-2 py-0.5 rounded-md">
                          {skill.weight.toFixed(1)}x
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span className="font-mono text-slate-700 font-semibold tabular-nums">
                          {skill.rolesUsingCount}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => handleOpenEdit(skill)}
                            className="p-1.5 rounded-lg text-slate-500 hover:text-[#6D5DFB] hover:bg-[#F1EEFF] transition-colors"
                            title="Edit skill parameters"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => setSkillToDelete(skill)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-[#DC2626] hover:bg-red-50 transition-colors"
                            title="Delete skill"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Skill Modal */}
      <Modal
        isOpen={isAddModalOpen || !!skillToEdit}
        onClose={() => {
          setIsAddModalOpen(false);
          setSkillToEdit(null);
        }}
        title={skillToEdit ? `Edit Skill: ${skillToEdit.name}` : 'Add Normalized Skill'}
        subtitle="Configures keyword match taxonomy and weight in ATS algorithms."
        maxWidth="lg"
        footer={
          <>
            <button
              type="button"
              onClick={() => {
                setIsAddModalOpen(false);
                setSkillToEdit(null);
              }}
              className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSaveSkill}
              className="px-4 py-2 text-xs font-semibold text-white bg-[#6D5DFB] hover:bg-[#5B4BE3] rounded-lg transition-colors"
            >
              {skillToEdit ? 'Save Changes' : 'Create Skill'}
            </button>
          </>
        }
      >
        <form onSubmit={handleSaveSkill} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Skill Name *
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Apache Kafka"
                value={skillName}
                onChange={e => setSkillName(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-[#1F2937] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Category
              </label>
              <select
                value={skillCategory}
                onChange={e => setSkillCategory(e.target.value as Skill['category'])}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-[#1F2937] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
              >
                <option value="Technical">Technical Language</option>
                <option value="Framework">Framework / Library</option>
                <option value="Database">Database & Storage</option>
                <option value="Cloud">Cloud Services</option>
                <option value="DevOps">DevOps & Containers</option>
                <option value="Tooling">Tooling & VCS</option>
                <option value="Soft Skills">Soft Skills & Methodologies</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Description & NLP Matching Context
            </label>
            <textarea
              rows={2}
              placeholder="Keywords, semantic variants, or token embeddings..."
              value={skillDesc}
              onChange={e => setSkillDesc(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-[#1F2937] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Importance Tier
              </label>
              <select
                value={skillImportance}
                onChange={e => setSkillImportance(e.target.value as SkillImportance)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-[#1F2937] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#6D5DFB]/30 focus:border-[#6D5DFB]"
              >
                <option value="High">High (Must-Have Requirement)</option>
                <option value="Medium">Medium (Recommended)</option>
                <option value="Low">Low (Nice-to-Have)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Mathematical Weight (1.0 - 3.0)
              </label>
              <div className="flex items-center gap-3">
                <input
                  type="range"
                  min="1.0"
                  max="3.0"
                  step="0.1"
                  value={skillWeight}
                  onChange={e => setSkillWeight(parseFloat(e.target.value))}
                  className="flex-1 accent-[#6D5DFB]"
                />
                <span className="font-mono font-bold text-xs text-[#6D5DFB] bg-[#F1EEFF] px-2 py-1 rounded-md min-w-[42px] text-center">
                  {skillWeight.toFixed(1)}x
                </span>
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              Assign to Job Domains
            </label>
            <div className="grid grid-cols-2 gap-2 max-h-36 overflow-y-auto p-2 border border-slate-200 rounded-xl bg-slate-50">
              {domains.map(d => {
                const isChecked = selectedDomainIds.includes(d.id);
                return (
                  <button
                    type="button"
                    key={d.id}
                    onClick={() => toggleDomainSelection(d.id)}
                    className={`p-2 rounded-lg text-left text-xs transition-colors border ${
                      isChecked
                        ? 'bg-[#F1EEFF] border-[#6D5DFB] text-[#6D5DFB] font-semibold'
                        : 'bg-white border-slate-200 text-slate-700 hover:border-slate-300'
                    }`}
                  >
                    {d.name}
                  </button>
                );
              })}
            </div>
          </div>
        </form>
      </Modal>

      {/* Delete Confirmation */}
      <ConfirmDialog
        isOpen={!!skillToDelete}
        onClose={() => setSkillToDelete(null)}
        onConfirm={handleDeleteConfirm}
        title="Delete Normalized Skill?"
        message={`Are you sure you want to remove "${skillToDelete?.name}"? The system will check if any active job roles currently require this skill.`}
        confirmText="Confirm Delete"
        variant="danger"
      />
    </div>
  );
};
