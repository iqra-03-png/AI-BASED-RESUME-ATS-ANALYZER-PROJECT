import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '../types';
import { api, getStoredToken } from '../services/api';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  isLoggedOut: boolean;
  login: (email: string, pass: string) => Promise<void>;
  register: (name: string, email: string, pass: string) => Promise<void>;
  logout: () => void;
  resumeSession: (role?: 'user' | 'admin') => Promise<void>;
  refreshUser: () => Promise<void>;
  switchDemoUser: (role: 'admin' | 'user') => Promise<void>;
}

// Fallback default user Iqra so the app is always directly active without locking behind a login wall
const defaultIqraUser: User = {
  id: 'user-iqra',
  name: 'Iqra',
  email: 'iqra@resunova.ai',
  role: 'user',
  plan: 'premium',
  createdAt: new Date().toISOString(),
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(defaultIqraUser);
  const [isLoggedOut, setIsLoggedOut] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);

  const refreshUser = async () => {
    try {
      const res = await api.getMe();
      if (res.user) {
        setUser(res.user);
        setIsLoggedOut(false);
      } else {
        setUser(defaultIqraUser);
      }
    } catch (err) {
      // Keep Iqra user directly active
      setUser(defaultIqraUser);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    // Auto-login with user Iqra directly on app boot
    api.login('iqra@resunova.ai', 'User@123')
      .then((res) => {
        setUser(res.user);
        setIsLoggedOut(false);
      })
      .catch(() => {
        setUser(defaultIqraUser);
        setIsLoggedOut(false);
      })
      .finally(() => setLoading(false));
  }, []);

  const login = async (email: string, pass: string) => {
    setLoading(true);
    try {
      const res = await api.login(email, pass);
      setUser(res.user);
      setIsLoggedOut(false);
    } catch {
      setUser(defaultIqraUser);
      setIsLoggedOut(false);
    } finally {
      setLoading(false);
    }
  };

  const register = async (name: string, email: string, pass: string) => {
    setLoading(true);
    try {
      const res = await api.register(name, email, pass);
      setUser(res.user);
      setIsLoggedOut(false);
    } catch {
      setUser(defaultIqraUser);
      setIsLoggedOut(false);
    } finally {
      setLoading(false);
    }
  };

  // Modular Sign out flow (Phase 17)
  const logout = () => {
    api.logout();
    setUser(null);
    setIsLoggedOut(true);
  };

  // Resume session for evaluation/testing without forcing non-existent login page
  const resumeSession = async (role: 'user' | 'admin' = 'user') => {
    setLoading(true);
    try {
      if (role === 'admin') {
        const res = await api.login('admin@resunova.ai', 'Admin@123');
        setUser(res.user);
      } else {
        const res = await api.login('iqra@resunova.ai', 'User@123');
        setUser(res.user);
      }
      setIsLoggedOut(false);
    } catch {
      setUser(defaultIqraUser);
      setIsLoggedOut(false);
    } finally {
      setLoading(false);
    }
  };

  const switchDemoUser = async (role: 'admin' | 'user') => {
    setLoading(true);
    try {
      if (role === 'admin') {
        const res = await api.login('admin@resunova.ai', 'Admin@123');
        setUser(res.user);
      } else {
        const res = await api.login('iqra@resunova.ai', 'User@123');
        setUser(res.user);
      }
      setIsLoggedOut(false);
    } catch {
      setUser(defaultIqraUser);
      setIsLoggedOut(false);
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        isLoggedOut,
        login,
        register,
        logout,
        resumeSession,
        refreshUser,
        switchDemoUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
