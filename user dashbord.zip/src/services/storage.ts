import {
  User,
  JobDomain,
  JobRole,
  Skill,
  ResumeAnalysis,
  InterviewQuestion,
  ResumeTemplate,
  AuditLog,
  AdminProfile,
  DashboardStats
} from '../types';

const STORAGE_KEYS = {
  USERS: 'resunova_users_v1',
  DOMAINS: 'resunova_domains_v1',
  ROLES: 'resunova_roles_v1',
  SKILLS: 'resunova_skills_v1',
  ANALYSES: 'resunova_analyses_v1',
  QUESTIONS: 'resunova_questions_v1',
  TEMPLATES: 'resunova_templates_v1',
  AUDIT_LOGS: 'resunova_audit_logs_v1',
  ADMIN_PROFILE: 'resunova_admin_profile_v1',
  AUTH_TOKEN: 'resunova_jwt_token',
};

// Initial Seed Data
const INITIAL_ADMIN: AdminProfile = {
  id: 'adm-001',
  name: 'Iram',
  email: 'admin@resunova.ai',
  role: 'Super Admin',
  avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
  lastLogin: '2026-10-28 17:42 UTC',
  twoFactorEnabled: true,
  sessionTimeoutMinutes: 60,
  department: 'Academic Computing & Career Technologies',
};

const INITIAL_USERS: User[] = [
  {
    id: 'usr-101',
    name: 'Aarav Sharma',
    email: 'aarav.sharma@stanford.edu',
    role: 'Student Candidate',
    status: 'active',
    registrationDate: '2026-09-12',
    resumesAnalyzed: 4,
    lastActive: '2026-10-27',
    avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80',
    university: 'Stanford University (CS)'
  },
  {
    id: 'usr-102',
    name: 'Emily Watson',
    email: 'emily.watson@mit.edu',
    role: 'Job Seeker',
    status: 'active',
    registrationDate: '2026-09-18',
    resumesAnalyzed: 6,
    lastActive: '2026-10-28',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
    university: 'MIT EECS'
  },
  {
    id: 'usr-103',
    name: 'Devon Vance',
    email: 'devon.vance@berkeley.edu',
    role: 'Graduate Student',
    status: 'active',
    registrationDate: '2026-10-02',
    resumesAnalyzed: 2,
    lastActive: '2026-10-25',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    university: 'UC Berkeley'
  },
  {
    id: 'usr-104',
    name: 'Priya Patel',
    email: 'priya.patel@georgiatech.edu',
    role: 'Job Seeker',
    status: 'inactive',
    registrationDate: '2026-08-14',
    resumesAnalyzed: 1,
    lastActive: '2026-09-02',
    avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
    university: 'Georgia Tech'
  },
  {
    id: 'usr-105',
    name: 'Marcus Chen',
    email: 'm.chen@columbia.edu',
    role: 'Student Candidate',
    status: 'active',
    registrationDate: '2026-10-10',
    resumesAnalyzed: 5,
    lastActive: '2026-10-28',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    university: 'Columbia University'
  },
  {
    id: 'usr-106',
    name: 'Fatima Al-Mansoor',
    email: 'fatima.m@cmu.edu',
    role: 'Job Seeker',
    status: 'active',
    registrationDate: '2026-10-15',
    resumesAnalyzed: 3,
    lastActive: '2026-10-26',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80',
    university: 'Carnegie Mellon University'
  },
  {
    id: 'usr-107',
    name: 'Lucas Silva',
    email: 'lucas.silva@toronto.ca',
    role: 'Alumni',
    status: 'active',
    registrationDate: '2026-07-20',
    resumesAnalyzed: 7,
    lastActive: '2026-10-28',
    avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150&auto=format&fit=crop&q=80',
    university: 'University of Toronto'
  },
  {
    id: 'usr-108',
    name: 'Chloe Tremblay',
    email: 'chloe.t@illinois.edu',
    role: 'Student Candidate',
    status: 'inactive',
    registrationDate: '2026-06-30',
    resumesAnalyzed: 0,
    lastActive: '2026-07-02',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    university: 'UIUC'
  }
];

const INITIAL_DOMAINS: JobDomain[] = [
  {
    id: 'dom-1',
    name: 'Software Development',
    slug: 'software-development',
    description: 'Core software engineering, algorithms, system architecture, and scalable software pipelines.',
    rolesCount: 4,
    skillsCount: 14,
    active: true,
    iconName: 'Code',
    createdAt: '2026-01-15'
  },
  {
    id: 'dom-2',
    name: 'Web Development',
    slug: 'web-development',
    description: 'Modern frontend, backend, fullstack frameworks, APIs, and progressive web ecosystems.',
    rolesCount: 3,
    skillsCount: 12,
    active: true,
    iconName: 'Globe',
    createdAt: '2026-01-15'
  },
  {
    id: 'dom-3',
    name: 'Data Science',
    slug: 'data-science',
    description: 'Statistical analysis, big data extraction, predictive modeling, and business intelligence.',
    rolesCount: 3,
    skillsCount: 11,
    active: true,
    iconName: 'Database',
    createdAt: '2026-01-16'
  },
  {
    id: 'dom-4',
    name: 'Artificial Intelligence',
    slug: 'artificial-intelligence',
    description: 'Deep learning, LLMs, computer vision, natural language processing, and neural networks.',
    rolesCount: 3,
    skillsCount: 13,
    active: true,
    iconName: 'Cpu',
    createdAt: '2026-01-16'
  },
  {
    id: 'dom-5',
    name: 'Cybersecurity',
    slug: 'cybersecurity',
    description: 'Threat modeling, network penetration testing, vulnerability assessment, and zero-trust policies.',
    rolesCount: 2,
    skillsCount: 9,
    active: true,
    iconName: 'ShieldAlert',
    createdAt: '2026-01-18'
  },
  {
    id: 'dom-6',
    name: 'Cloud Computing',
    slug: 'cloud-computing',
    description: 'Cloud architecture, Kubernetes orchestration, serverless microservices, and AWS/GCP infrastructure.',
    rolesCount: 3,
    skillsCount: 10,
    active: true,
    iconName: 'Cloud',
    createdAt: '2026-01-20'
  },
  {
    id: 'dom-7',
    name: 'Java Development',
    slug: 'java-development',
    description: 'Enterprise Java, Spring Boot microservices, JVM optimization, and distributed messaging.',
    rolesCount: 2,
    skillsCount: 8,
    active: true,
    iconName: 'Layers',
    createdAt: '2026-01-22'
  },
  {
    id: 'dom-8',
    name: 'UI/UX Design',
    slug: 'ui-ux-design',
    description: 'Human-computer interaction, design systems, usability heuristics, Figma prototyping, and user journeys.',
    rolesCount: 2,
    skillsCount: 7,
    active: true,
    iconName: 'Layout',
    createdAt: '2026-01-25'
  }
];

const INITIAL_SKILLS: Skill[] = [
  { id: 'skl-01', name: 'Python', category: 'Technical', description: 'General purpose language for backend and AI pipelines', domainIds: ['dom-1', 'dom-3', 'dom-4'], importance: 'High', weight: 2.8, rolesUsingCount: 7, createdAt: '2026-01-15' },
  { id: 'skl-02', name: 'Java', category: 'Technical', description: 'Enterprise object-oriented language for high throughput applications', domainIds: ['dom-1', 'dom-7'], importance: 'High', weight: 2.7, rolesUsingCount: 5, createdAt: '2026-01-15' },
  { id: 'skl-03', name: 'Spring Boot', category: 'Framework', description: 'Java framework for cloud-native microservices', domainIds: ['dom-7', 'dom-1'], importance: 'High', weight: 2.5, rolesUsingCount: 3, createdAt: '2026-01-15' },
  { id: 'skl-04', name: 'React.js', category: 'Framework', description: 'Declarative component-based frontend library', domainIds: ['dom-2'], importance: 'High', weight: 2.9, rolesUsingCount: 4, createdAt: '2026-01-15' },
  { id: 'skl-05', name: 'TypeScript', category: 'Technical', description: 'Typed JavaScript for robust client/server systems', domainIds: ['dom-1', 'dom-2'], importance: 'High', weight: 2.6, rolesUsingCount: 5, createdAt: '2026-01-16' },
  { id: 'skl-06', name: 'Docker & Containers', category: 'DevOps', description: 'Containerization and reproducible microservices', domainIds: ['dom-1', 'dom-2', 'dom-6'], importance: 'High', weight: 2.5, rolesUsingCount: 6, createdAt: '2026-01-16' },
  { id: 'skl-07', name: 'Kubernetes', category: 'DevOps', description: 'Container cluster scheduling and orchestration', domainIds: ['dom-6'], importance: 'High', weight: 2.7, rolesUsingCount: 3, createdAt: '2026-01-16' },
  { id: 'skl-08', name: 'SQL & Relational DBs', category: 'Database', description: 'Complex relational querying, indexing, and joins', domainIds: ['dom-1', 'dom-2', 'dom-3', 'dom-7'], importance: 'High', weight: 2.8, rolesUsingCount: 8, createdAt: '2026-01-16' },
  { id: 'skl-09', name: 'PyTorch', category: 'Framework', description: 'Deep learning framework for tensor calculations and models', domainIds: ['dom-4', 'dom-3'], importance: 'High', weight: 2.8, rolesUsingCount: 4, createdAt: '2026-01-17' },
  { id: 'skl-10', name: 'Natural Language Processing (NLP)', category: 'Technical', description: 'Text tokenization, embeddings, transformers, and sentiment modeling', domainIds: ['dom-4'], importance: 'High', weight: 2.9, rolesUsingCount: 3, createdAt: '2026-01-17' },
  { id: 'skl-11', name: 'AWS Cloud Services', category: 'Cloud', description: 'EC2, S3, RDS, Lambda, and IAM cloud architectural patterns', domainIds: ['dom-6', 'dom-1'], importance: 'High', weight: 2.6, rolesUsingCount: 5, createdAt: '2026-01-17' },
  { id: 'skl-12', name: 'RESTful API Architecture', category: 'Technical', description: 'HTTP verbs, idempotency, status codes, and serialization', domainIds: ['dom-1', 'dom-2', 'dom-7'], importance: 'High', weight: 2.4, rolesUsingCount: 6, createdAt: '2026-01-18' },
  { id: 'skl-13', name: 'Git & Version Control', category: 'Tooling', description: 'Branching, PRs, merge conflict resolution, and CI/CD', domainIds: ['dom-1', 'dom-2', 'dom-3', 'dom-4', 'dom-5', 'dom-6', 'dom-7'], importance: 'High', weight: 2.2, rolesUsingCount: 9, createdAt: '2026-01-18' },
  { id: 'skl-14', name: 'Figma & Design Systems', category: 'Tooling', description: 'Wireframing, auto-layout, interactive prototypes, component libraries', domainIds: ['dom-8', 'dom-2'], importance: 'High', weight: 2.6, rolesUsingCount: 3, createdAt: '2026-01-18' },
  { id: 'skl-15', name: 'Penetration Testing & OWASP', category: 'Technical', description: 'Web application vulnerability assessments and mitigation', domainIds: ['dom-5'], importance: 'High', weight: 2.8, rolesUsingCount: 2, createdAt: '2026-01-19' },
  { id: 'skl-16', name: 'Pandas & NumPy', category: 'Technical', description: 'Data matrix manipulation, vectorized filtering, and feature engineering', domainIds: ['dom-3', 'dom-4'], importance: 'Medium', weight: 2.1, rolesUsingCount: 4, createdAt: '2026-01-19' },
  { id: 'skl-17', name: 'CI/CD Pipelines (GitHub Actions)', category: 'DevOps', description: 'Automated test execution, linting, and zero-downtime deployment', domainIds: ['dom-1', 'dom-6'], importance: 'Medium', weight: 2.0, rolesUsingCount: 4, createdAt: '2026-01-20' },
  { id: 'skl-18', name: 'Microservices Design', category: 'Technical', description: 'Domain-driven design, event queues, and service meshes', domainIds: ['dom-1', 'dom-6', 'dom-7'], importance: 'Medium', weight: 2.2, rolesUsingCount: 4, createdAt: '2026-01-20' },
  { id: 'skl-19', name: 'System Security & Cryptography', category: 'Technical', description: 'TLS, asymmetric encryption, OAuth2, and token security', domainIds: ['dom-5', 'dom-6'], importance: 'Medium', weight: 2.1, rolesUsingCount: 3, createdAt: '2026-01-21' },
  { id: 'skl-20', name: 'Agile & Scrum Methodologies', category: 'Soft Skills', description: 'Sprint rituals, backlog refinement, and cross-functional velocity', domainIds: ['dom-1', 'dom-2', 'dom-8'], importance: 'Low', weight: 1.2, rolesUsingCount: 5, createdAt: '2026-01-21' }
];

const INITIAL_ROLES: JobRole[] = [
  {
    id: 'rol-101',
    domainId: 'dom-1',
    domainName: 'Software Development',
    title: 'Senior Software Engineer',
    description: 'Designs and builds fault-tolerant, high-performance distributed software architectures.',
    level: 'Senior',
    requiredSkills: [
      { skillId: 'skl-01', skillName: 'Python', importance: 'High', weight: 2.8 },
      { skillId: 'skl-08', skillName: 'SQL & Relational DBs', importance: 'High', weight: 2.8 },
      { skillId: 'skl-06', skillName: 'Docker & Containers', importance: 'High', weight: 2.5 },
      { skillId: 'skl-18', skillName: 'Microservices Design', importance: 'Medium', weight: 2.2 }
    ],
    status: 'active',
    updatedAt: '2026-10-15'
  },
  {
    id: 'rol-102',
    domainId: 'dom-2',
    domainName: 'Web Development',
    title: 'Full Stack Web Developer',
    description: 'Develops end-to-end web applications with React on frontend and robust REST APIs on backend.',
    level: 'Mid',
    requiredSkills: [
      { skillId: 'skl-04', skillName: 'React.js', importance: 'High', weight: 2.9 },
      { skillId: 'skl-05', skillName: 'TypeScript', importance: 'High', weight: 2.6 },
      { skillId: 'skl-12', skillName: 'RESTful API Architecture', importance: 'High', weight: 2.4 },
      { skillId: 'skl-08', skillName: 'SQL & Relational DBs', importance: 'Medium', weight: 2.0 }
    ],
    status: 'active',
    updatedAt: '2026-10-18'
  },
  {
    id: 'rol-103',
    domainId: 'dom-4',
    domainName: 'Artificial Intelligence',
    title: 'AI/ML Research Engineer',
    description: 'Researches and deploys neural architectures, generative models, and computer vision pipelines.',
    level: 'Senior',
    requiredSkills: [
      { skillId: 'skl-01', skillName: 'Python', importance: 'High', weight: 2.9 },
      { skillId: 'skl-09', skillName: 'PyTorch', importance: 'High', weight: 2.8 },
      { skillId: 'skl-10', skillName: 'Natural Language Processing (NLP)', importance: 'High', weight: 2.9 },
      { skillId: 'skl-16', skillName: 'Pandas & NumPy', importance: 'Medium', weight: 2.1 }
    ],
    status: 'active',
    updatedAt: '2026-10-20'
  },
  {
    id: 'rol-104',
    domainId: 'dom-7',
    domainName: 'Java Development',
    title: 'Enterprise Java Architect',
    description: 'Builds mission-critical distributed transaction engines using Java, Spring Boot, and Kafka.',
    level: 'Lead',
    requiredSkills: [
      { skillId: 'skl-02', skillName: 'Java', importance: 'High', weight: 2.9 },
      { skillId: 'skl-03', skillName: 'Spring Boot', importance: 'High', weight: 2.8 },
      { skillId: 'skl-08', skillName: 'SQL & Relational DBs', importance: 'High', weight: 2.7 },
      { skillId: 'skl-18', skillName: 'Microservices Design', importance: 'Medium', weight: 2.2 }
    ],
    status: 'active',
    updatedAt: '2026-10-21'
  },
  {
    id: 'rol-105',
    domainId: 'dom-3',
    domainName: 'Data Science',
    title: 'Lead Data Scientist',
    description: 'Translates messy transactional data into validated predictive models and executive dashboards.',
    level: 'Lead',
    requiredSkills: [
      { skillId: 'skl-01', skillName: 'Python', importance: 'High', weight: 2.8 },
      { skillId: 'skl-08', skillName: 'SQL & Relational DBs', importance: 'High', weight: 2.8 },
      { skillId: 'skl-16', skillName: 'Pandas & NumPy', importance: 'High', weight: 2.6 }
    ],
    status: 'active',
    updatedAt: '2026-10-22'
  },
  {
    id: 'rol-106',
    domainId: 'dom-6',
    domainName: 'Cloud Computing',
    title: 'Cloud DevOps Architect',
    description: 'Architects multi-region cloud topology with automated continuous delivery and Kubernetes.',
    level: 'Senior',
    requiredSkills: [
      { skillId: 'skl-11', skillName: 'AWS Cloud Services', importance: 'High', weight: 2.8 },
      { skillId: 'skl-07', skillName: 'Kubernetes', importance: 'High', weight: 2.8 },
      { skillId: 'skl-06', skillName: 'Docker & Containers', importance: 'High', weight: 2.6 },
      { skillId: 'skl-17', skillName: 'CI/CD Pipelines (GitHub Actions)', importance: 'Medium', weight: 2.2 }
    ],
    status: 'active',
    updatedAt: '2026-10-24'
  },
  {
    id: 'rol-107',
    domainId: 'dom-8',
    domainName: 'UI/UX Design',
    title: 'Product UI/UX Designer',
    description: 'Crafts accessible user journeys, high-fidelity prototypes, and design systems.',
    level: 'Mid',
    requiredSkills: [
      { skillId: 'skl-14', skillName: 'Figma & Design Systems', importance: 'High', weight: 2.9 },
      { skillId: 'skl-20', skillName: 'Agile & Scrum Methodologies', importance: 'Medium', weight: 1.8 }
    ],
    status: 'active',
    updatedAt: '2026-10-25'
  }
];

const INITIAL_ANALYSES: ResumeAnalysis[] = [
  {
    id: 'ATS-9041',
    userId: 'usr-101',
    userName: 'Aarav Sharma',
    userEmail: 'aarav.sharma@stanford.edu',
    jobDomainId: 'dom-1',
    jobDomainName: 'Software Development',
    jobRoleId: 'rol-101',
    jobRoleTitle: 'Senior Software Engineer',
    atsScore: 88,
    status: 'Completed',
    analysisDate: '2026-10-28 16:32',
    processingTimeMs: 1420,
    fileName: 'Aarav_Sharma_Resume_2026.pdf',
    fileSizeKb: 342,
    matchedSkills: [
      { name: 'Python', weight: 2.8, foundContext: 'Built real-time distributed microservice processing 40k events/sec with Python and asyncio.' },
      { name: 'SQL & Relational DBs', weight: 2.8, foundContext: 'Optimized PostgreSQL queries, wrote indexing strategies cutting p99 latency by 45%.' },
      { name: 'Docker & Containers', weight: 2.5, foundContext: 'Containerized 12 services using multi-stage Docker builds.' }
    ],
    missingSkills: [
      { name: 'Microservices Design', weight: 2.2, importance: 'Medium', recommendation: 'Highlight concrete service boundary design or event messaging (Kafka/RabbitMQ).' }
    ],
    scoreBreakdown: {
      skillMatch: 36,
      keywordDensity: 23,
      sectionStructure: 18,
      formatting: 11
    },
    summaryFeedback: 'Excellent technical depth and strong quantified impact statements. ATS parsed all sections cleanly.'
  },
  {
    id: 'ATS-9040',
    userId: 'usr-102',
    userName: 'Emily Watson',
    userEmail: 'emily.watson@mit.edu',
    jobDomainId: 'dom-2',
    jobDomainName: 'Web Development',
    jobRoleId: 'rol-102',
    jobRoleTitle: 'Full Stack Web Developer',
    atsScore: 94,
    status: 'Completed',
    analysisDate: '2026-10-28 14:15',
    processingTimeMs: 1180,
    fileName: 'Emily_Watson_Fullstack.pdf',
    fileSizeKb: 280,
    matchedSkills: [
      { name: 'React.js', weight: 2.9, foundContext: 'Engineered complex dashboard using React hooks and optimistic UI mutations.' },
      { name: 'TypeScript', weight: 2.6, foundContext: 'Authored strict TypeScript interfaces for public REST endpoints.' },
      { name: 'RESTful API Architecture', weight: 2.4, foundContext: 'Designed RESTful backend consumed by 100k daily web visitors.' },
      { name: 'SQL & Relational DBs', weight: 2.0, foundContext: 'Implemented relational schemas in MySQL with foreign key integrity.' }
    ],
    missingSkills: [],
    scoreBreakdown: {
      skillMatch: 40,
      keywordDensity: 24,
      sectionStructure: 19,
      formatting: 11
    },
    summaryFeedback: 'Outstanding ATS compatibility. All essential skills matched with high semantic contextual relevance.'
  },
  {
    id: 'ATS-9039',
    userId: 'usr-103',
    userName: 'Devon Vance',
    userEmail: 'devon.vance@berkeley.edu',
    jobDomainId: 'dom-4',
    jobDomainName: 'Artificial Intelligence',
    jobRoleId: 'rol-103',
    jobRoleTitle: 'AI/ML Research Engineer',
    atsScore: 78,
    status: 'Completed',
    analysisDate: '2026-10-27 18:40',
    processingTimeMs: 1890,
    fileName: 'Devon_Vance_AI_CV.pdf',
    fileSizeKb: 410,
    matchedSkills: [
      { name: 'Python', weight: 2.9, foundContext: 'Implemented custom attention layers and loss functions in Python.' },
      { name: 'PyTorch', weight: 2.8, foundContext: 'Fine-tuned LLM architectures using PyTorch and HuggingFace Accelerate.' }
    ],
    missingSkills: [
      { name: 'Natural Language Processing (NLP)', weight: 2.9, importance: 'High', recommendation: 'Include explicit terminology for tokenization, attention mechanisms, and RAG architectures.' },
      { name: 'Pandas & NumPy', weight: 2.1, importance: 'Medium', recommendation: 'Demonstrate data cleaning pipelines and matrix optimization methods.' }
    ],
    scoreBreakdown: {
      skillMatch: 30,
      keywordDensity: 19,
      sectionStructure: 17,
      formatting: 12
    },
    summaryFeedback: 'Strong algorithmic background, but needs more explicit keywords targeting standard NLP evaluation metrics (BLEU, ROUGE).'
  },
  {
    id: 'ATS-9038',
    userId: 'usr-105',
    userName: 'Marcus Chen',
    userEmail: 'm.chen@columbia.edu',
    jobDomainId: 'dom-7',
    jobDomainName: 'Java Development',
    jobRoleId: 'rol-104',
    jobRoleTitle: 'Enterprise Java Architect',
    atsScore: 63,
    status: 'Completed',
    analysisDate: '2026-10-27 11:10',
    processingTimeMs: 1650,
    fileName: 'Marcus_Java_Resume.docx',
    fileSizeKb: 215,
    matchedSkills: [
      { name: 'Java', weight: 2.9, foundContext: 'Developed enterprise Java components with multithreading.' },
      { name: 'SQL & Relational DBs', weight: 2.7, foundContext: 'Maintained relational databases in Oracle and MySQL.' }
    ],
    missingSkills: [
      { name: 'Spring Boot', weight: 2.8, importance: 'High', recommendation: 'Core requirement missing: mention Spring Boot microservice configurations and annotations.' },
      { name: 'Microservices Design', weight: 2.2, importance: 'Medium', recommendation: 'Discuss decoupled architecture and event handling.' }
    ],
    scoreBreakdown: {
      skillMatch: 24,
      keywordDensity: 16,
      sectionStructure: 14,
      formatting: 9
    },
    summaryFeedback: 'Missing critical high-weight framework skill (Spring Boot). Table layouts in DOCX format caused minor OCR parsing degradation.'
  },
  {
    id: 'ATS-9037',
    userId: 'usr-106',
    userName: 'Fatima Al-Mansoor',
    userEmail: 'fatima.m@cmu.edu',
    jobDomainId: 'dom-6',
    jobDomainName: 'Cloud Computing',
    jobRoleId: 'rol-106',
    jobRoleTitle: 'Cloud DevOps Architect',
    atsScore: 91,
    status: 'Completed',
    analysisDate: '2026-10-26 15:22',
    processingTimeMs: 1340,
    fileName: 'Fatima_CloudDevOps.pdf',
    fileSizeKb: 310,
    matchedSkills: [
      { name: 'AWS Cloud Services', weight: 2.8, foundContext: 'Configured AWS ECS, CloudWatch, and Terraform modules.' },
      { name: 'Kubernetes', weight: 2.8, foundContext: 'Managed production EKS cluster hosting 80 microservices.' },
      { name: 'Docker & Containers', weight: 2.6, foundContext: 'Created slim distroless Docker base images reducing image size by 70%.' },
      { name: 'CI/CD Pipelines (GitHub Actions)', weight: 2.2, foundContext: 'Automated test suite and deployment via GitHub Actions.' }
    ],
    missingSkills: [],
    scoreBreakdown: {
      skillMatch: 39,
      keywordDensity: 23,
      sectionStructure: 19,
      formatting: 10
    },
    summaryFeedback: 'Superb cloud engineering resume. Clear technical metric outcomes and clean linear formatting.'
  },
  {
    id: 'ATS-9036',
    userId: 'usr-107',
    userName: 'Lucas Silva',
    userEmail: 'lucas.silva@toronto.ca',
    jobDomainId: 'dom-3',
    jobDomainName: 'Data Science',
    jobRoleId: 'rol-105',
    jobRoleTitle: 'Lead Data Scientist',
    atsScore: 42,
    status: 'Failed',
    analysisDate: '2026-10-25 09:12',
    processingTimeMs: 4200,
    fileName: 'Lucas_Silva_Graphics_CV.pdf',
    fileSizeKb: 1820,
    matchedSkills: [],
    missingSkills: [
      { name: 'Python', weight: 2.8, importance: 'High', recommendation: 'Text in complex graphical columns could not be extracted.' }
    ],
    scoreBreakdown: { skillMatch: 12, keywordDensity: 10, sectionStructure: 10, formatting: 10 },
    failureReason: 'Multi-column image canvas caused PDF text stream detachment. ATS parser could not extract sequential experience tokens.',
    summaryFeedback: 'Parser failure due to graphical raster layout. Candidate advised to use ATS-standard single-column linear layout.'
  }
];

const INITIAL_QUESTIONS: InterviewQuestion[] = [
  {
    id: 'qst-201',
    question: 'How do you handle race conditions in distributed microservices sharing a database?',
    sampleAnswer: 'By implementing optimistic locking with version columns, distributed Redis mutexes (Redlock algorithm), or migrating critical state mutations to an event-sourced ledger architecture.',
    category: 'Technical',
    domainId: 'dom-1',
    domainName: 'Software Development',
    roleId: 'rol-101',
    roleTitle: 'Senior Software Engineer',
    difficulty: 'Hard',
    status: 'active',
    createdAt: '2026-02-01'
  },
  {
    id: 'qst-202',
    question: 'What is inheritance vs composition in Java and when should each be preferred?',
    sampleAnswer: 'Inheritance models an "is-a" relationship, while composition models a "has-a" relationship. Modern software engineering favors composition to prevent tight coupling, brittle base classes, and violation of the Liskov Substitution Principle.',
    category: 'Technical',
    domainId: 'dom-7',
    domainName: 'Java Development',
    roleId: 'rol-104',
    roleTitle: 'Enterprise Java Architect',
    difficulty: 'Medium',
    status: 'active',
    createdAt: '2026-02-02'
  },
  {
    id: 'qst-203',
    question: 'Describe a situation where a critical production bug occurred close to a release deadline. How did you handle it?',
    sampleAnswer: 'Structured using the STAR method: Clarify the immediate containment step (feature toggle / rollback), communicate transparently to stakeholders with real impact telemetry, perform root-cause blameless analysis, and implement preventative regression tests.',
    category: 'Behavioral',
    domainId: 'all',
    domainName: 'All Domains',
    difficulty: 'Medium',
    status: 'active',
    createdAt: '2026-02-04'
  },
  {
    id: 'qst-204',
    question: 'Walk me through how the React Reconciliation algorithm (Fiber) handles dirty component tree updates.',
    sampleAnswer: 'React Fiber splits work into chunks using a cooperative scheduler. It reconciles virtual DOM nodes using unique keys, builds a work-in-progress tree, and commits DOM mutations in a single synchronous pass to avoid tearing.',
    category: 'Technical',
    domainId: 'dom-2',
    domainName: 'Web Development',
    roleId: 'rol-102',
    roleTitle: 'Full Stack Web Developer',
    difficulty: 'Hard',
    status: 'active',
    createdAt: '2026-02-05'
  },
  {
    id: 'qst-205',
    question: 'Tell me about yourself and why you are interested in this specific engineering role.',
    sampleAnswer: 'A concise 90-second trajectory: Technical origins, key university or commercial achievements, the specific problem space that inspires you, and why ResuNova is the natural next step.',
    category: 'HR',
    domainId: 'all',
    domainName: 'All Domains',
    difficulty: 'Easy',
    status: 'active',
    createdAt: '2026-02-06'
  },
  {
    id: 'qst-206',
    question: 'If a product manager requests a high-priority feature that would double database query load right before peak traffic, what do you do?',
    sampleAnswer: 'Collaborate to understand the core business objective. Quantify the throughput impact using latency/load projections, and propose mitigations like query caching with Redis or async batching.',
    category: 'Situational',
    domainId: 'dom-1',
    domainName: 'Software Development',
    difficulty: 'Medium',
    status: 'active',
    createdAt: '2026-02-08'
  },
  {
    id: 'qst-207',
    question: 'Explain the difference between L1 and L2 regularization in machine learning loss functions.',
    sampleAnswer: 'L1 (Lasso) adds the absolute sum of coefficients, driving non-essential feature weights to exactly zero for feature selection. L2 (Ridge) adds squared weights, shrinking parameters smoothly to prevent overfitting.',
    category: 'Technical',
    domainId: 'dom-4',
    domainName: 'Artificial Intelligence',
    roleId: 'rol-103',
    roleTitle: 'AI/ML Research Engineer',
    difficulty: 'Medium',
    status: 'active',
    createdAt: '2026-02-10'
  }
];

const INITIAL_TEMPLATES: ResumeTemplate[] = [
  {
    id: 'tpl-freshstart',
    title: 'FreshStart',
    category: 'Fresher Resume',
    domainId: 'dom-1',
    domainName: 'General & Entry-Level',
    description: 'Simple, clean, single-column design tailored for freshers, college students, and entry-level job seekers with structured academic and project emphasis.',
    downloadsCount: 4120,
    status: 'Published',
    uploadDate: '2026-02-10',
    format: 'PDF',
    accentColor: '#16A34A',
    tier: 'free',
    priceInr: 0,
    intendedUser: 'College Freshers & New Graduates',
    intendedRoles: ['Junior Software Engineer', 'Graduate Trainee', 'Frontend Intern'],
    layout: 'single-column',
    themeFont: 'sans',
    purchasesCount: 0,
    savedResumesCount: 182,
    enabledSections: {
      summary: true,
      education: true,
      skills: true,
      projects: true,
      experience: true,
      certifications: true,
      achievements: true
    },
    features: [
      'Single-Column Clean ATS Layout',
      'Career Objective Section',
      'Academic Projects Showcase',
      'Certifications & Achievements',
      '100% Free Forever'
    ],
    templateKey: 'fresh-start',
    previewSnippet: {
      name: 'Aarav Sharma',
      targetRole: 'Junior Software Engineer',
      summary: 'Aspiring software developer with strong foundational skills in computer science, algorithms, and web technologies seeking an entry-level software engineer role.',
      skillsSample: ['Python', 'JavaScript', 'HTML5/CSS3', 'SQL', 'Git & GitHub'],
      experienceSample: 'Completed academic capstone project: Smart Campus Resource Management System with React and Python.'
    }
  },
  {
    id: 'tpl-techbasic',
    title: 'TechBasic',
    category: 'IT & Developer Resume',
    domainId: 'dom-1',
    domainName: 'Software & IT',
    description: 'ATS-friendly, high-contrast design for IT students and entry-level developers with clear programming skill matrices and internship records.',
    downloadsCount: 3680,
    status: 'Published',
    uploadDate: '2026-02-12',
    format: 'PDF',
    accentColor: '#0284C7',
    tier: 'free',
    priceInr: 0,
    intendedUser: 'IT Students & Entry-Level Developers',
    intendedRoles: ['Associate Backend Developer', 'DevOps Associate', 'QA Engineer'],
    layout: 'single-column',
    themeFont: 'sans',
    purchasesCount: 0,
    savedResumesCount: 145,
    enabledSections: {
      summary: true,
      education: true,
      skills: true,
      projects: true,
      experience: true,
      certifications: true,
      achievements: true
    },
    features: [
      'High-Contrast ATS Parser Friendly',
      'Categorized Technical Skills',
      'Internship & Project Highlights',
      'Programming Languages Grid',
      '100% Free Forever'
    ],
    templateKey: 'tech-basic',
    previewSnippet: {
      name: 'Priya Patel',
      targetRole: 'Associate Backend Developer',
      summary: 'Information Technology graduate passionate about distributed cloud services, database design, and REST APIs.',
      skillsSample: ['Java', 'Spring Boot', 'MySQL', 'Docker', 'Linux/Bash'],
      experienceSample: 'Summer Software Engineering Intern at TechVibe: Built microservice caching layer reducing latency by 35%.'
    }
  },
  {
    id: 'tpl-careeredge',
    title: 'CareerEdge',
    category: 'Professional Career Resume',
    domainId: 'dom-2',
    domainName: 'Corporate & Tech',
    description: 'Modern professional design with refined typography, subtle violet accents, and quantified work experience impact metrics.',
    downloadsCount: 2450,
    status: 'Published',
    uploadDate: '2026-02-18',
    format: 'PDF',
    accentColor: '#6D5DFB',
    tier: 'premium',
    priceInr: 299,
    intendedUser: 'Mid-Level Professionals & Career Changers',
    intendedRoles: ['Full Stack Developer', 'Cloud Engineer', 'Product Manager'],
    layout: 'single-column',
    themeFont: 'sans',
    purchasesCount: 48,
    savedResumesCount: 94,
    enabledSections: {
      summary: true,
      education: true,
      skills: true,
      projects: true,
      experience: true,
      certifications: true,
      achievements: true
    },
    features: [
      'Modern Executive Typography',
      'Quantified Impact Bullets',
      'Subtle Royal Accent Palette',
      'Dual-Section Skill Balancing',
      'Priority ATS Parsing Compatibility'
    ],
    templateKey: 'career-edge',
    previewSnippet: {
      name: 'Emily Watson',
      targetRole: 'Full Stack Web Developer',
      summary: 'Results-driven full-stack developer with 3+ years engineering client-facing web applications and RESTful microservices.',
      skillsSample: ['React.js', 'Node.js', 'TypeScript', 'PostgreSQL', 'Tailwind CSS'],
      experienceSample: 'Engineered high-concurrency client portal serving 120k monthly active users with 99.98% uptime.'
    }
  },
  {
    id: 'tpl-devpro',
    title: 'DevPro',
    category: 'Software Engineering Resume',
    domainId: 'dom-1',
    domainName: 'Software Engineering',
    description: 'Software developer-focused design emphasizing modern tech stacks, GitHub/Portfolio links, open-source projects, and systems engineering.',
    downloadsCount: 2890,
    status: 'Published',
    uploadDate: '2026-02-22',
    format: 'PDF',
    accentColor: '#8B5CF6',
    tier: 'premium',
    priceInr: 399,
    intendedUser: 'Full-Stack, Backend & Frontend Developers',
    intendedRoles: ['Senior Systems Engineer', 'Backend Architect', 'Cloud Specialist'],
    layout: 'single-column',
    themeFont: 'mono',
    purchasesCount: 62,
    savedResumesCount: 110,
    enabledSections: {
      summary: true,
      education: true,
      skills: true,
      projects: true,
      experience: true,
      certifications: true,
      achievements: true
    },
    features: [
      'Developer Stack Highlights',
      'GitHub & Portfolio URL Embedding',
      'Distributed Systems Experience',
      'Multi-Language Matrix',
      'Technical Recruiter Optimized'
    ],
    templateKey: 'dev-pro',
    previewSnippet: {
      name: 'Devon Vance',
      targetRole: 'Senior Cloud Systems Engineer',
      summary: 'Senior systems engineer specialized in Kubernetes orchestration, CI/CD automation, and multi-region AWS cloud architectures.',
      skillsSample: ['Go', 'Python', 'Kubernetes', 'Terraform', 'AWS Lambda'],
      experienceSample: 'Architected automated deployment pipeline executing 150+ canary deployments daily with zero-downtime rollbacks.'
    }
  },
  {
    id: 'tpl-eliteexecutive',
    title: 'EliteExecutive',
    category: 'Executive & Senior Leadership',
    domainId: 'dom-6',
    domainName: 'Executive & Management',
    description: 'Prestigious layout with classic executive hierarchy, key achievement summary metrics, strategic governance, and board-level experience.',
    downloadsCount: 1940,
    status: 'Published',
    uploadDate: '2026-02-26',
    format: 'PDF',
    accentColor: '#111827',
    tier: 'premium',
    priceInr: 499,
    intendedUser: 'Senior Leaders, Directors & Seasoned Executives',
    intendedRoles: ['VP of Technology', 'CTO', 'Engineering Director'],
    layout: 'single-column',
    themeFont: 'serif',
    purchasesCount: 35,
    savedResumesCount: 78,
    enabledSections: {
      summary: true,
      education: true,
      skills: true,
      projects: true,
      experience: true,
      certifications: true,
      achievements: true
    },
    features: [
      'Executive Metric Highlights',
      'Strategic Governance & Leadership',
      'Board & Credential Accreditations',
      'High-Impact Executive Summary',
      'Premium C-Suite Formatting'
    ],
    templateKey: 'elite-executive',
    previewSnippet: {
      name: 'Marcus Sterling',
      targetRole: 'VP of Technology & Product',
      summary: 'Strategic technology executive with 14+ years steering cross-functional engineering organizations, enterprise digital transformation, and P&L growth.',
      skillsSample: ['Enterprise Architecture', 'Strategic Roadmapping', 'Team Leadership (100+)', 'P&L Management ($25M)', 'Cloud Modernization'],
      experienceSample: 'Grew engineering organization from 25 to 110 engineers while expanding ARR from $8M to $36M over 4-year tenure.'
    }
  }
];

const INITIAL_AUDIT_LOGS: AuditLog[] = [
  {
    id: 'log-01',
    adminName: 'Iram',
    action: 'Modified Skill Weight',
    targetType: 'Skill',
    targetName: 'Python (Weight: 2.8)',
    timestamp: '2026-10-28 17:15',
    ipAddress: '192.168.1.104',
    status: 'Success'
  },
  {
    id: 'log-02',
    adminName: 'Iram',
    action: 'Created Job Role',
    targetType: 'Role',
    targetName: 'Product UI/UX Designer',
    timestamp: '2026-10-28 16:50',
    ipAddress: '192.168.1.104',
    status: 'Success'
  },
  {
    id: 'log-03',
    adminName: 'Iram',
    action: 'Deactivated User',
    targetType: 'User',
    targetName: 'Priya Patel (Inactive)',
    timestamp: '2026-10-28 14:20',
    ipAddress: '192.168.1.104',
    status: 'Success'
  },
  {
    id: 'log-04',
    adminName: 'System Cron',
    action: 'Automated Daily Health Check',
    targetType: 'Database',
    targetName: 'MySQL Partition Verify',
    timestamp: '2026-10-28 00:00',
    ipAddress: '127.0.0.1',
    status: 'Success'
  }
];

// Helper to access LocalStorage safely with fallback
function getFromStorage<T>(key: string, defaultVal: T): T {
  try {
    const item = localStorage.getItem(key);
    if (!item) {
      localStorage.setItem(key, JSON.stringify(defaultVal));
      return defaultVal;
    }
    return JSON.parse(item);
  } catch (e) {
    console.warn(`LocalStorage access failed for key ${key}:`, e);
    return defaultVal;
  }
}

function saveToStorage<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    console.error(`LocalStorage save failed for key ${key}:`, e);
  }
}

export const ResuNovaStore = {
  // Initialization
  init() {
    getFromStorage(STORAGE_KEYS.USERS, INITIAL_USERS);
    getFromStorage(STORAGE_KEYS.DOMAINS, INITIAL_DOMAINS);
    getFromStorage(STORAGE_KEYS.ROLES, INITIAL_ROLES);
    getFromStorage(STORAGE_KEYS.SKILLS, INITIAL_SKILLS);
    getFromStorage(STORAGE_KEYS.ANALYSES, INITIAL_ANALYSES);
    getFromStorage(STORAGE_KEYS.QUESTIONS, INITIAL_QUESTIONS);
    getFromStorage(STORAGE_KEYS.TEMPLATES, INITIAL_TEMPLATES);
    getFromStorage(STORAGE_KEYS.AUDIT_LOGS, INITIAL_AUDIT_LOGS);
    getFromStorage(STORAGE_KEYS.ADMIN_PROFILE, INITIAL_ADMIN);
  },

  resetToDefaults() {
    saveToStorage(STORAGE_KEYS.USERS, INITIAL_USERS);
    saveToStorage(STORAGE_KEYS.DOMAINS, INITIAL_DOMAINS);
    saveToStorage(STORAGE_KEYS.ROLES, INITIAL_ROLES);
    saveToStorage(STORAGE_KEYS.SKILLS, INITIAL_SKILLS);
    saveToStorage(STORAGE_KEYS.ANALYSES, INITIAL_ANALYSES);
    saveToStorage(STORAGE_KEYS.QUESTIONS, INITIAL_QUESTIONS);
    saveToStorage(STORAGE_KEYS.TEMPLATES, INITIAL_TEMPLATES);
    saveToStorage(STORAGE_KEYS.AUDIT_LOGS, INITIAL_AUDIT_LOGS);
    saveToStorage(STORAGE_KEYS.ADMIN_PROFILE, INITIAL_ADMIN);
  },

  // Users
  getUsers(): User[] {
    return getFromStorage(STORAGE_KEYS.USERS, INITIAL_USERS);
  },

  toggleUserStatus(userId: string): User | null {
    const users = this.getUsers();
    const idx = users.findIndex(u => u.id === userId);
    if (idx === -1) return null;
    users[idx].status = users[idx].status === 'active' ? 'inactive' : 'active';
    saveToStorage(STORAGE_KEYS.USERS, users);
    this.addAuditLog('Toggled User Status', 'User', `${users[idx].name} -> ${users[idx].status}`);
    return users[idx];
  },

  deleteUser(userId: string): boolean {
    let users = this.getUsers();
    const target = users.find(u => u.id === userId);
    if (!target) return false;
    users = users.filter(u => u.id !== userId);
    saveToStorage(STORAGE_KEYS.USERS, users);
    this.addAuditLog('Deleted User Account', 'User', `${target.name} (${target.email})`);
    return true;
  },

  addUser(user: Omit<User, 'id' | 'registrationDate' | 'resumesAnalyzed' | 'lastActive'>): User {
    const users = this.getUsers();
    const newUser: User = {
      ...user,
      id: `usr-${Date.now().toString().slice(-4)}`,
      registrationDate: new Date().toISOString().split('T')[0],
      resumesAnalyzed: 0,
      lastActive: 'Just now',
    };
    users.unshift(newUser);
    saveToStorage(STORAGE_KEYS.USERS, users);
    this.addAuditLog('Created User', 'User', newUser.name);
    return newUser;
  },

  updateUser(id: string, updates: Partial<User>): User | null {
    const users = this.getUsers();
    const idx = users.findIndex(u => u.id === id);
    if (idx === -1) return null;
    users[idx] = { ...users[idx], ...updates };
    saveToStorage(STORAGE_KEYS.USERS, users);
    this.addAuditLog('Updated User Details', 'User', users[idx].name);
    return users[idx];
  },

  // Job Domains & Roles
  getDomains(): JobDomain[] {
    return getFromStorage(STORAGE_KEYS.DOMAINS, INITIAL_DOMAINS);
  },

  getRoles(): JobRole[] {
    return getFromStorage(STORAGE_KEYS.ROLES, INITIAL_ROLES);
  },

  addDomain(domain: { name: string; description: string; iconName: string }): JobDomain {
    const domains = this.getDomains();
    const newDomain: JobDomain = {
      id: `dom-${Date.now().toString().slice(-4)}`,
      name: domain.name,
      slug: domain.name.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
      description: domain.description,
      rolesCount: 0,
      skillsCount: 0,
      active: true,
      iconName: domain.iconName || 'Briefcase',
      createdAt: new Date().toISOString().split('T')[0]
    };
    domains.push(newDomain);
    saveToStorage(STORAGE_KEYS.DOMAINS, domains);
    this.addAuditLog('Added Job Domain', 'Domain', newDomain.name);
    return newDomain;
  },

  updateDomain(id: string, updates: Partial<JobDomain>): JobDomain | null {
    const domains = this.getDomains();
    const idx = domains.findIndex(d => d.id === id);
    if (idx === -1) return null;
    domains[idx] = { ...domains[idx], ...updates };
    saveToStorage(STORAGE_KEYS.DOMAINS, domains);
    this.addAuditLog('Updated Job Domain', 'Domain', domains[idx].name);
    return domains[idx];
  },

  deleteDomain(id: string): { success: boolean; error?: string } {
    const roles = this.getRoles();
    const associatedRoles = roles.filter(r => r.domainId === id);
    if (associatedRoles.length > 0) {
      return {
        success: false,
        error: `Cannot delete domain because it contains ${associatedRoles.length} active job roles. Reassign or delete roles first.`
      };
    }
    let domains = this.getDomains();
    const target = domains.find(d => d.id === id);
    domains = domains.filter(d => d.id !== id);
    saveToStorage(STORAGE_KEYS.DOMAINS, domains);
    if (target) {
      this.addAuditLog('Deleted Job Domain', 'Domain', target.name);
    }
    return { success: true };
  },

  addRole(role: Omit<JobRole, 'id' | 'updatedAt'>): JobRole {
    const roles = this.getRoles();
    const newRole: JobRole = {
      ...role,
      id: `rol-${Date.now().toString().slice(-4)}`,
      updatedAt: new Date().toISOString().split('T')[0]
    };
    roles.push(newRole);
    saveToStorage(STORAGE_KEYS.ROLES, roles);

    // Update domain rolesCount
    const domains = this.getDomains();
    const dIdx = domains.findIndex(d => d.id === role.domainId);
    if (dIdx !== -1) {
      domains[dIdx].rolesCount += 1;
      saveToStorage(STORAGE_KEYS.DOMAINS, domains);
    }

    this.addAuditLog('Created Job Role', 'Role', `${newRole.title} (${role.domainName})`);
    return newRole;
  },

  updateRole(id: string, updates: Partial<JobRole>): JobRole | null {
    const roles = this.getRoles();
    const idx = roles.findIndex(r => r.id === id);
    if (idx === -1) return null;
    roles[idx] = { ...roles[idx], ...updates, updatedAt: new Date().toISOString().split('T')[0] };
    saveToStorage(STORAGE_KEYS.ROLES, roles);
    this.addAuditLog('Updated Job Role', 'Role', roles[idx].title);
    return roles[idx];
  },

  deleteRole(id: string): boolean {
    let roles = this.getRoles();
    const target = roles.find(r => r.id === id);
    if (!target) return false;
    roles = roles.filter(r => r.id !== id);
    saveToStorage(STORAGE_KEYS.ROLES, roles);

    // Update domain rolesCount
    const domains = this.getDomains();
    const dIdx = domains.findIndex(d => d.id === target.domainId);
    if (dIdx !== -1 && domains[dIdx].rolesCount > 0) {
      domains[dIdx].rolesCount -= 1;
      saveToStorage(STORAGE_KEYS.DOMAINS, domains);
    }

    this.addAuditLog('Deleted Job Role', 'Role', target.title);
    return true;
  },

  // Skills
  getSkills(): Skill[] {
    return getFromStorage(STORAGE_KEYS.SKILLS, INITIAL_SKILLS);
  },

  addSkill(skill: Omit<Skill, 'id' | 'rolesUsingCount' | 'createdAt'>): Skill {
    const skills = this.getSkills();
    const newSkill: Skill = {
      ...skill,
      id: `skl-${Date.now().toString().slice(-4)}`,
      rolesUsingCount: 0,
      createdAt: new Date().toISOString().split('T')[0]
    };
    skills.push(newSkill);
    saveToStorage(STORAGE_KEYS.SKILLS, skills);

    // Recalculate domain skill counts
    this.recalcDomainSkills();

    this.addAuditLog('Added New Skill', 'Skill', newSkill.name);
    return newSkill;
  },

  updateSkill(id: string, updates: Partial<Skill>): Skill | null {
    const skills = this.getSkills();
    const idx = skills.findIndex(s => s.id === id);
    if (idx === -1) return null;
    skills[idx] = { ...skills[idx], ...updates };
    saveToStorage(STORAGE_KEYS.SKILLS, skills);
    this.recalcDomainSkills();
    this.addAuditLog('Updated Skill', 'Skill', skills[idx].name);
    return skills[idx];
  },

  deleteSkill(id: string): { success: boolean; error?: string } {
    const roles = this.getRoles();
    const usingRoles = roles.filter(r => r.requiredSkills.some(s => s.skillId === id));
    if (usingRoles.length > 0) {
      return {
        success: false,
        error: `Cannot delete skill "${id}" because it is currently assigned to ${usingRoles.length} job roles. Remove it from those roles first.`
      };
    }
    let skills = this.getSkills();
    const target = skills.find(s => s.id === id);
    skills = skills.filter(s => s.id !== id);
    saveToStorage(STORAGE_KEYS.SKILLS, skills);
    this.recalcDomainSkills();
    if (target) {
      this.addAuditLog('Deleted Skill', 'Skill', target.name);
    }
    return { success: true };
  },

  recalcDomainSkills() {
    const skills = this.getSkills();
    const domains = this.getDomains();
    domains.forEach(d => {
      d.skillsCount = skills.filter(s => s.domainIds.includes(d.id)).length;
    });
    saveToStorage(STORAGE_KEYS.DOMAINS, domains);
  },

  // Analyses
  getAnalyses(): ResumeAnalysis[] {
    return getFromStorage(STORAGE_KEYS.ANALYSES, INITIAL_ANALYSES);
  },

  deleteAnalysis(id: string): boolean {
    let analyses = this.getAnalyses();
    const target = analyses.find(a => a.id === id);
    if (!target) return false;
    analyses = analyses.filter(a => a.id !== id);
    saveToStorage(STORAGE_KEYS.ANALYSES, analyses);
    this.addAuditLog('Deleted Resume Analysis Record', 'Analysis', id);
    return true;
  },

  retryAnalysis(id: string): ResumeAnalysis | null {
    const analyses = this.getAnalyses();
    const idx = analyses.findIndex(a => a.id === id);
    if (idx === -1) return null;
    // Simulate successful OCR and NLP extraction
    analyses[idx].status = 'Completed';
    analyses[idx].atsScore = 79;
    analyses[idx].processingTimeMs = 1520;
    analyses[idx].failureReason = undefined;
    analyses[idx].matchedSkills = [
      { name: 'Python', weight: 2.8, foundContext: 'Recovered via high-precision OCR text normalization layer.' },
      { name: 'SQL & Relational DBs', weight: 2.6, foundContext: 'Extracted relational querying experience.' }
    ];
    analyses[idx].missingSkills = [
      { name: 'Docker & Containers', weight: 2.5, importance: 'High', recommendation: 'Mention containerized deployments.' }
    ];
    analyses[idx].scoreBreakdown = {
      skillMatch: 32,
      keywordDensity: 20,
      sectionStructure: 16,
      formatting: 11
    };
    analyses[idx].summaryFeedback = 'Successfully reprocessed via ResuNova NLP fallback parser. Score updated.';
    saveToStorage(STORAGE_KEYS.ANALYSES, analyses);
    this.addAuditLog('Retried Resume Analysis', 'Analysis', id);
    return analyses[idx];
  },

  // Interview Questions
  getQuestions(): InterviewQuestion[] {
    return getFromStorage(STORAGE_KEYS.QUESTIONS, INITIAL_QUESTIONS);
  },

  addQuestion(question: Omit<InterviewQuestion, 'id' | 'createdAt'>): InterviewQuestion {
    const questions = this.getQuestions();
    const newQuestion: InterviewQuestion = {
      ...question,
      id: `qst-${Date.now().toString().slice(-4)}`,
      createdAt: new Date().toISOString().split('T')[0]
    };
    questions.push(newQuestion);
    saveToStorage(STORAGE_KEYS.QUESTIONS, questions);
    this.addAuditLog('Added Interview Question', 'Question', newQuestion.question.slice(0, 30) + '...');
    return newQuestion;
  },

  updateQuestion(id: string, updates: Partial<InterviewQuestion>): InterviewQuestion | null {
    const questions = this.getQuestions();
    const idx = questions.findIndex(q => q.id === id);
    if (idx === -1) return null;
    questions[idx] = { ...questions[idx], ...updates };
    saveToStorage(STORAGE_KEYS.QUESTIONS, questions);
    this.addAuditLog('Updated Interview Question', 'Question', questions[idx].question.slice(0, 30) + '...');
    return questions[idx];
  },

  deleteQuestion(id: string): boolean {
    let questions = this.getQuestions();
    const target = questions.find(q => q.id === id);
    if (!target) return false;
    questions = questions.filter(q => q.id !== id);
    saveToStorage(STORAGE_KEYS.QUESTIONS, questions);
    this.addAuditLog('Deleted Interview Question', 'Question', target.question.slice(0, 30) + '...');
    return true;
  },

  toggleQuestionStatus(id: string): InterviewQuestion | null {
    const questions = this.getQuestions();
    const idx = questions.findIndex(q => q.id === id);
    if (idx === -1) return null;
    questions[idx].status = questions[idx].status === 'active' ? 'inactive' : 'active';
    saveToStorage(STORAGE_KEYS.QUESTIONS, questions);
    return questions[idx];
  },

  // Templates
  getTemplates(options?: { onlyPublished?: boolean; includeArchived?: boolean }): ResumeTemplate[] {
    const list = getFromStorage<ResumeTemplate[]>(STORAGE_KEYS.TEMPLATES, INITIAL_TEMPLATES);
    // Normalize legacy active/inactive to Published/Unpublished
    const normalized = list.map(t => {
      let normStatus = t.status;
      if (t.status === 'active') normStatus = 'Published';
      if (t.status === 'inactive') normStatus = 'Unpublished';
      return {
        ...t,
        status: normStatus
      };
    });

    return normalized.filter(t => {
      if (!options?.includeArchived && t.isArchived) return false;
      if (options?.onlyPublished && t.status !== 'Published') return false;
      return true;
    });
  },

  addTemplate(template: Omit<ResumeTemplate, 'id' | 'uploadDate' | 'downloadsCount'>): ResumeTemplate {
    const rawTemplates = getFromStorage<ResumeTemplate[]>(STORAGE_KEYS.TEMPLATES, INITIAL_TEMPLATES);
    const newTemplate: ResumeTemplate = {
      ...template,
      id: `tpl-${Date.now().toString().slice(-6)}`,
      downloadsCount: 0,
      purchasesCount: 0,
      savedResumesCount: 0,
      uploadDate: new Date().toISOString().split('T')[0],
      status: template.status || 'Published'
    };
    rawTemplates.push(newTemplate);
    saveToStorage(STORAGE_KEYS.TEMPLATES, rawTemplates);
    this.addAuditLog('Created Resume Template', 'Template', `${newTemplate.title} (${newTemplate.status})`);
    return newTemplate;
  },

  updateTemplate(id: string, updates: Partial<ResumeTemplate>): ResumeTemplate | null {
    const templates = getFromStorage<ResumeTemplate[]>(STORAGE_KEYS.TEMPLATES, INITIAL_TEMPLATES);
    const idx = templates.findIndex(t => t.id === id);
    if (idx === -1) return null;
    templates[idx] = { ...templates[idx], ...updates };
    saveToStorage(STORAGE_KEYS.TEMPLATES, templates);
    this.addAuditLog('Updated Resume Template', 'Template', templates[idx].title);
    return templates[idx];
  },

  publishTemplate(id: string): ResumeTemplate | null {
    return this.updateTemplate(id, { status: 'Published' });
  },

  unpublishTemplate(id: string): ResumeTemplate | null {
    return this.updateTemplate(id, { status: 'Unpublished' });
  },

  duplicateTemplate(id: string): ResumeTemplate | null {
    const templates = getFromStorage<ResumeTemplate[]>(STORAGE_KEYS.TEMPLATES, INITIAL_TEMPLATES);
    const original = templates.find(t => t.id === id);
    if (!original) return null;

    const copy: ResumeTemplate = {
      ...original,
      id: `tpl-copy-${Date.now().toString().slice(-5)}`,
      title: `${original.title} (Copy)`,
      status: 'Draft',
      downloadsCount: 0,
      purchasesCount: 0,
      savedResumesCount: 0,
      uploadDate: new Date().toISOString().split('T')[0]
    };
    templates.push(copy);
    saveToStorage(STORAGE_KEYS.TEMPLATES, templates);
    this.addAuditLog('Duplicated Resume Template', 'Template', copy.title);
    return copy;
  },

  deleteTemplate(id: string, forceHardDelete = false): { success: boolean; softDeleted?: boolean; warning?: string } {
    let templates = getFromStorage<ResumeTemplate[]>(STORAGE_KEYS.TEMPLATES, INITIAL_TEMPLATES);
    const target = templates.find(t => t.id === id);
    if (!target) return { success: false, warning: 'Template not found' };

    const hasPurchases = (target.purchasesCount || 0) > 0;
    const hasSavedResumes = (target.savedResumesCount || 0) > 0;

    // Prefer soft-delete / archiving to preserve user purchase integrity and saved resumes
    if ((hasPurchases || hasSavedResumes) && !forceHardDelete) {
      target.isArchived = true;
      target.status = 'Unpublished';
      saveToStorage(STORAGE_KEYS.TEMPLATES, templates);
      this.addAuditLog('Archived Resume Template', 'Template', `${target.title} (Safe Archival)`);
      return {
        success: true,
        softDeleted: true,
        warning: `Template "${target.title}" archived rather than permanently purged to safeguard ${target.purchasesCount || 0} user purchase receipts and ${target.savedResumesCount || 0} existing candidate resumes.`
      };
    }

    templates = templates.filter(t => t.id !== id);
    saveToStorage(STORAGE_KEYS.TEMPLATES, templates);
    this.addAuditLog('Permanently Deleted Resume Template', 'Template', target.title);
    return { success: true, softDeleted: false };
  },

  toggleTemplateStatus(id: string): ResumeTemplate | null {
    const templates = getFromStorage<ResumeTemplate[]>(STORAGE_KEYS.TEMPLATES, INITIAL_TEMPLATES);
    const idx = templates.findIndex(t => t.id === id);
    if (idx === -1) return null;
    const current = templates[idx].status;
    templates[idx].status = current === 'Published' ? 'Unpublished' : 'Published';
    saveToStorage(STORAGE_KEYS.TEMPLATES, templates);
    return templates[idx];
  },

  // Stats calculation directly derived from actual database records
  getStats(): DashboardStats {
    const users = this.getUsers();
    const analyses = this.getAnalyses();
    const domains = this.getDomains();
    const skills = this.getSkills();
    const questions = this.getQuestions();
    const templates = this.getTemplates();

    const completedAnalyses = analyses.filter(a => a.status === 'Completed');
    const avgAts = completedAnalyses.length > 0
      ? Math.round(completedAnalyses.reduce((acc, a) => acc + a.atsScore, 0) / completedAnalyses.length * 10) / 10
      : 0;

    return {
      totalUsers: users.length,
      totalResumesAnalyzed: analyses.length,
      totalDomains: domains.length,
      totalSkills: skills.length,
      totalQuestions: questions.length,
      totalTemplates: templates.length,
      averageAtsScore: avgAts,
      userGrowthPct: 14.2,
      resumeGrowthPct: 22.8,
      atsScoreChangePct: 3.4
    };
  },

  // Audit Logs
  getAuditLogs(): AuditLog[] {
    return getFromStorage(STORAGE_KEYS.AUDIT_LOGS, INITIAL_AUDIT_LOGS);
  },

  addAuditLog(action: string, targetType: string, targetName: string) {
    const logs = this.getAuditLogs();
    const newLog: AuditLog = {
      id: `log-${Date.now().toString().slice(-4)}`,
      adminName: 'Iram',
      action,
      targetType,
      targetName,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 16),
      ipAddress: '192.168.1.104',
      status: 'Success'
    };
    logs.unshift(newLog);
    if (logs.length > 50) logs.pop();
    saveToStorage(STORAGE_KEYS.AUDIT_LOGS, logs);
  },

  // Admin Profile & Auth
  getAdminProfile(): AdminProfile {
    const prof = getFromStorage(STORAGE_KEYS.ADMIN_PROFILE, INITIAL_ADMIN);
    if (prof.name.includes('Sarah') || prof.name.includes('Jenkins')) {
      prof.name = 'Iram';
      prof.role = 'Super Admin';
      saveToStorage(STORAGE_KEYS.ADMIN_PROFILE, prof);
    }
    return prof;
  },

  updateAdminProfile(updates: Partial<AdminProfile>): AdminProfile {
    const current = this.getAdminProfile();
    const updated = { ...current, ...updates };
    saveToStorage(STORAGE_KEYS.ADMIN_PROFILE, updated);
    this.addAuditLog('Updated Profile Information', 'Security', 'Admin Profile');
    return updated;
  },

  // Global Search across all database entities
  globalSearch(rawQuery: string): import('../types').SearchResult[] {
    const q = (rawQuery || '').trim().toLowerCase();
    if (!q) return [];

    const results: import('../types').SearchResult[] = [];

    // 1. Search Users
    const users = this.getUsers();
    for (const u of users) {
      if (
        u.name.toLowerCase().includes(q) ||
        u.email.toLowerCase().includes(q) ||
        u.id.toLowerCase().includes(q) ||
        (u.university && u.university.toLowerCase().includes(q))
      ) {
        results.push({
          id: u.id,
          title: u.name,
          subtitle: `${u.email} · ${u.university || u.role}`,
          category: 'User',
          targetTab: 'users',
          itemData: u
        });
      }
    }

    // 2. Search Resume Analyses
    const analyses = this.getAnalyses();
    for (const a of analyses) {
      if (
        a.id.toLowerCase().includes(q) ||
        a.userName.toLowerCase().includes(q) ||
        a.jobRoleTitle.toLowerCase().includes(q) ||
        a.jobDomainName.toLowerCase().includes(q) ||
        a.userEmail.toLowerCase().includes(q)
      ) {
        results.push({
          id: a.id,
          title: `${a.userName} — ${a.jobRoleTitle}`,
          subtitle: `ATS ${a.atsScore}% · ${a.jobDomainName} (${a.status})`,
          category: 'Resume Analysis',
          targetTab: 'analyses',
          itemData: a
        });
      }
    }

    // 3. Search Skills
    const skills = this.getSkills();
    for (const s of skills) {
      if (
        s.name.toLowerCase().includes(q) ||
        s.id.toLowerCase().includes(q) ||
        s.category.toLowerCase().includes(q) ||
        s.description.toLowerCase().includes(q)
      ) {
        results.push({
          id: s.id,
          title: s.name,
          subtitle: `${s.category} · Weight ${s.weight}x (${s.importance} Priority)`,
          category: 'Skill',
          targetTab: 'skills',
          itemData: s
        });
      }
    }

    // 4. Search Job Domains
    const domains = this.getDomains();
    for (const d of domains) {
      if (
        d.name.toLowerCase().includes(q) ||
        d.id.toLowerCase().includes(q) ||
        d.description.toLowerCase().includes(q)
      ) {
        results.push({
          id: d.id,
          title: d.name,
          subtitle: `${d.rolesCount} Roles · ${d.skillsCount} Skills · ${d.description.slice(0, 50)}...`,
          category: 'Job Domain',
          targetTab: 'domains',
          itemData: d
        });
      }
    }


    // 6. Search Templates
    const templates = this.getTemplates();
    for (const t of templates) {
      if (
        t.title.toLowerCase().includes(q) ||
        t.id.toLowerCase().includes(q) ||
        t.category.toLowerCase().includes(q) ||
        t.domainName.toLowerCase().includes(q)
      ) {
        results.push({
          id: t.id,
          title: t.title,
          subtitle: `${t.category} · Format: ${t.format} (${t.downloadsCount} downloads)`,
          category: 'Resume Template',
          targetTab: 'templates',
          itemData: t
        });
      }
    }

    return results;
  },

  // JWT Token Management
  getAuthToken(): string | null {
    return localStorage.getItem(STORAGE_KEYS.AUTH_TOKEN) || sessionStorage.getItem(STORAGE_KEYS.AUTH_TOKEN);
  },

  setAuthToken(token: string, remember: boolean = true) {
    if (remember) {
      localStorage.setItem(STORAGE_KEYS.AUTH_TOKEN, token);
    } else {
      sessionStorage.setItem(STORAGE_KEYS.AUTH_TOKEN, token);
    }
  },

  clearAuthToken() {
    localStorage.removeItem(STORAGE_KEYS.AUTH_TOKEN);
    sessionStorage.removeItem(STORAGE_KEYS.AUTH_TOKEN);
  }
};

// Initialize immediately
ResuNovaStore.init();
