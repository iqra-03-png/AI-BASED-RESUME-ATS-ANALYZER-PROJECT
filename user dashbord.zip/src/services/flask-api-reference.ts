/**
 * ResuNova Flask Backend & MySQL Database Architecture Reference
 *
 * This reference specifies the exact REST API contract, JWT authentication,
 * and normalized relational MySQL database schema designed for ResuNova.
 */

export const MYSQL_SCHEMA_SQL = `-- ====================================================================
-- RESUNOVA AI RESUME ATS ANALYZER - NORMALIZED MYSQL SCHEMA (v2.4)
-- Engine: InnoDB | Character Set: utf8mb4 | Collation: utf8mb4_unicode_ci
-- ====================================================================

CREATE DATABASE IF NOT EXISTS resunova_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE resunova_db;

-- 1. ADMIN USERS TABLE (Supports JWT and bcrypt password hash)
CREATE TABLE IF NOT EXISTS admin_users (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL DEFAULT 'Super Admin',
    avatar_url VARCHAR(255) NULL,
    two_factor_enabled BOOLEAN NOT NULL DEFAULT TRUE,
    session_timeout_minutes INT NOT NULL DEFAULT 60,
    last_login DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_admin_email (email)
) ENGINE=InnoDB;

-- 2. REGISTERED USERS TABLE (Students, Job Seekers, Alumni)
CREATE TABLE IF NOT EXISTS users (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL DEFAULT 'Student Candidate',
    status ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
    university VARCHAR(150) NULL,
    avatar_url VARCHAR(255) NULL,
    registration_date DATE NOT NULL,
    last_active DATE NULL,
    resumes_analyzed_count INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_status (status),
    INDEX idx_user_email (email)
) ENGINE=InnoDB;

-- 3. JOB DOMAINS TABLE
CREATE TABLE IF NOT EXISTS job_domains (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    slug VARCHAR(120) NOT NULL UNIQUE,
    description TEXT NOT NULL,
    icon_name VARCHAR(50) NOT NULL DEFAULT 'Briefcase',
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 4. JOB ROLES TABLE
CREATE TABLE IF NOT EXISTS job_roles (
    id VARCHAR(36) PRIMARY KEY,
    domain_id VARCHAR(36) NOT NULL,
    title VARCHAR(120) NOT NULL,
    description TEXT NOT NULL,
    level ENUM('Junior', 'Mid', 'Senior', 'Lead') NOT NULL DEFAULT 'Mid',
    status ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (domain_id) REFERENCES job_domains(id) ON DELETE RESTRICT,
    INDEX idx_role_domain (domain_id),
    INDEX idx_role_status (status)
) ENGINE=InnoDB;

-- 5. SKILLS CATALOG TABLE (Normalized skill definitions)
CREATE TABLE IF NOT EXISTS skills (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    category ENUM('Technical', 'Soft Skills', 'Framework', 'Database', 'Cloud', 'DevOps', 'Tooling') NOT NULL,
    description TEXT NULL,
    importance ENUM('High', 'Medium', 'Low') NOT NULL DEFAULT 'Medium',
    weight DECIMAL(3,2) NOT NULL DEFAULT 2.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_skill_category (category),
    INDEX idx_skill_importance (importance)
) ENGINE=InnoDB;

-- 6. ROLE_SKILLS JUNCTION TABLE (Many-to-Many with custom role weights)
CREATE TABLE IF NOT EXISTS role_skills (
    role_id VARCHAR(36) NOT NULL,
    skill_id VARCHAR(36) NOT NULL,
    importance ENUM('High', 'Medium', 'Low') NOT NULL DEFAULT 'Medium',
    weight DECIMAL(3,2) NOT NULL DEFAULT 2.00,
    PRIMARY KEY (role_id, skill_id),
    FOREIGN KEY (role_id) REFERENCES job_roles(id) ON DELETE CASCADE,
    FOREIGN KEY (skill_id) REFERENCES skills(id) ON DELETE RESTRICT,
    INDEX idx_rs_role (role_id),
    INDEX idx_rs_skill (skill_id)
) ENGINE=InnoDB;

-- 7. DOMAIN_SKILLS JUNCTION TABLE (For domain-level skill categorization)
CREATE TABLE IF NOT EXISTS domain_skills (
    domain_id VARCHAR(36) NOT NULL,
    skill_id VARCHAR(36) NOT NULL,
    PRIMARY KEY (domain_id, skill_id),
    FOREIGN KEY (domain_id) REFERENCES job_domains(id) ON DELETE CASCADE,
    FOREIGN KEY (skill_id) REFERENCES skills(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 8. RESUME ANALYSES TABLE (ATS scoring history)
CREATE TABLE IF NOT EXISTS resume_analyses (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    job_role_id VARCHAR(36) NOT NULL,
    ats_score DECIMAL(5,2) NOT NULL DEFAULT 0.00,
    status ENUM('Completed', 'Processing', 'Failed') NOT NULL DEFAULT 'Processing',
    processing_time_ms INT NOT NULL DEFAULT 0,
    file_name VARCHAR(255) NOT NULL,
    file_size_kb INT NOT NULL DEFAULT 0,
    file_path VARCHAR(500) NULL,
    summary_feedback TEXT NULL,
    failure_reason TEXT NULL,
    skill_match_score DECIMAL(5,2) NOT NULL DEFAULT 0.00,
    keyword_density_score DECIMAL(5,2) NOT NULL DEFAULT 0.00,
    section_structure_score DECIMAL(5,2) NOT NULL DEFAULT 0.00,
    formatting_score DECIMAL(5,2) NOT NULL DEFAULT 0.00,
    analysis_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (job_role_id) REFERENCES job_roles(id) ON DELETE RESTRICT,
    INDEX idx_analysis_user (user_id),
    INDEX idx_analysis_role (job_role_id),
    INDEX idx_analysis_status (status),
    INDEX idx_analysis_score (ats_score)
) ENGINE=InnoDB;

-- 9. ANALYSIS_MATCHED_SKILLS TABLE
CREATE TABLE IF NOT EXISTS analysis_matched_skills (
    id INT AUTO_INCREMENT PRIMARY KEY,
    analysis_id VARCHAR(36) NOT NULL,
    skill_name VARCHAR(100) NOT NULL,
    weight DECIMAL(3,2) NOT NULL DEFAULT 1.00,
    found_context TEXT NULL,
    FOREIGN KEY (analysis_id) REFERENCES resume_analyses(id) ON DELETE CASCADE,
    INDEX idx_match_analysis (analysis_id)
) ENGINE=InnoDB;

-- 10. ANALYSIS_MISSING_SKILLS TABLE
CREATE TABLE IF NOT EXISTS analysis_missing_skills (
    id INT AUTO_INCREMENT PRIMARY KEY,
    analysis_id VARCHAR(36) NOT NULL,
    skill_name VARCHAR(100) NOT NULL,
    weight DECIMAL(3,2) NOT NULL DEFAULT 1.00,
    importance ENUM('High', 'Medium', 'Low') NOT NULL DEFAULT 'Medium',
    recommendation TEXT NULL,
    FOREIGN KEY (analysis_id) REFERENCES resume_analyses(id) ON DELETE CASCADE,
    INDEX idx_missing_analysis (analysis_id)
) ENGINE=InnoDB;

-- 11. INTERVIEW QUESTIONS TABLE
CREATE TABLE IF NOT EXISTS interview_questions (
    id VARCHAR(36) PRIMARY KEY,
    question TEXT NOT NULL,
    sample_answer TEXT NOT NULL,
    category ENUM('Technical', 'HR', 'Behavioral', 'Situational') NOT NULL,
    domain_id VARCHAR(36) NULL, -- NULL denotes 'All Domains'
    role_id VARCHAR(36) NULL,   -- NULL denotes general for domain
    difficulty ENUM('Easy', 'Medium', 'Hard') NOT NULL DEFAULT 'Medium',
    status ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (domain_id) REFERENCES job_domains(id) ON DELETE SET NULL,
    FOREIGN KEY (role_id) REFERENCES job_roles(id) ON DELETE SET NULL,
    INDEX idx_iq_category (category),
    INDEX idx_iq_domain (domain_id),
    INDEX idx_iq_status (status)
) ENGINE=InnoDB;

-- 12. RESUME TEMPLATES TABLE
CREATE TABLE IF NOT EXISTS resume_templates (
    id VARCHAR(36) PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    category VARCHAR(100) NOT NULL,
    domain_id VARCHAR(36) NOT NULL,
    description TEXT NOT NULL,
    format ENUM('DOCX', 'PDF', 'LATEX') NOT NULL DEFAULT 'PDF',
    downloads_count INT NOT NULL DEFAULT 0,
    status ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
    accent_color VARCHAR(20) NOT NULL DEFAULT '#6D5DFB',
    template_file_url VARCHAR(500) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (domain_id) REFERENCES job_domains(id) ON DELETE RESTRICT,
    INDEX idx_tmpl_domain (domain_id),
    INDEX idx_tmpl_status (status)
) ENGINE=InnoDB;

-- 13. AUDIT LOGS TABLE
CREATE TABLE IF NOT EXISTS audit_logs (
    id VARCHAR(36) PRIMARY KEY,
    admin_name VARCHAR(100) NOT NULL,
    action VARCHAR(100) NOT NULL,
    target_type VARCHAR(50) NOT NULL,
    target_name VARCHAR(150) NOT NULL,
    ip_address VARCHAR(45) NOT NULL,
    status ENUM('Success', 'Warning', 'Failed') NOT NULL DEFAULT 'Success',
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_audit_time (timestamp)
) ENGINE=InnoDB;
`;

export const FLASK_SERVER_CODE = `# ====================================================================
# RESUNOVA - PYTHON FLASK REST API SERVER ARCHITECTURE (Flask + SQLAlchemy + JWT)
# ====================================================================

import os
from datetime import datetime, timedelta
from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_jwt_extended import (
    JWTManager, create_access_token, jwt_required,
    get_jwt_identity, get_jwt
)
from werkzeug.security import generate_password_hash, check_password_hash
from flask_cors import CORS

app = Flask(__name__)
CORS(app, resources={r"/api/*": {"origins": "*"}})

# Configurations from Environment Variables
app.config['SECRET_KEY'] = os.environ.get('FLASK_SECRET_KEY', 'resunova-production-secret-key-9283')
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get(
    'DATABASE_URL',
    'mysql+pymysql://resunova_user:ResuNova_Pass2026@localhost:3306/resunova_db'
)
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['JWT_SECRET_KEY'] = os.environ.get('JWT_SECRET_KEY', 'resunova-jwt-signing-key-4921')
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(hours=8)

db = SQLAlchemy(app)
jwt = JWTManager(app)

# ----------------- JWT ADMIN GUARD DECORATOR -----------------
def admin_required(fn):
    from functools import wraps
    @wraps(fn)
    @jwt_required()
    def wrapper(*args, **kwargs):
        claims = get_jwt()
        if not claims.get('is_admin', False):
            return jsonify({'error': 'Unauthorized: Admin privileges required'}), 403
        return fn(*args, **kwargs)
    return wrapper

# ----------------- 1. AUTHENTICATION ENDPOINTS -----------------
@app.route('/api/admin/login', methods=['POST'])
def admin_login():
    data = request.get_json() or {}
    email = data.get('email', '').strip().lower()
    password = data.get('password', '')

    # Query admin_users table (using parameterized SQLAlchemy queries)
    # user = AdminUser.query.filter_by(email=email).first()
    # verify check_password_hash(user.password_hash, password)

    if email == 'admin@resunova.ai' and password:
        token = create_access_token(
            identity=email,
            additional_claims={'is_admin': True, 'name': 'Iram'}
        )
        return jsonify({
            'status': 'success',
            'token': token,
            'user': {
                'name': 'Iram',
                'email': 'admin@resunova.ai',
                'role': 'Super Admin'
            }
        }), 200

    return jsonify({'error': 'Invalid administrative credentials'}), 401

# ----------------- 2. DASHBOARD KPI SUMMARY -----------------
@app.route('/api/admin/dashboard/stats', methods=['GET'])
@admin_required
def get_dashboard_stats():
    # Calculated directly from MySQL tables:
    # total_users = db.session.query(db.func.count(User.id)).scalar()
    # total_analyses = db.session.query(db.func.count(ResumeAnalysis.id)).scalar()
    # avg_ats = db.session.query(db.func.avg(ResumeAnalysis.ats_score)).filter(ResumeAnalysis.status == 'Completed').scalar() or 0.0
    return jsonify({
        'totalUsers': 8,
        'totalResumesAnalyzed': 6,
        'totalDomains': 8,
        'totalSkills': 20,
        'totalInterviewQuestions': 7,
        'totalResumeTemplates': 5,
        'averageAtsScore': 82.8,
        'userGrowthPct': 14.2,
        'resumeGrowthPct': 22.8
    }), 200

# ----------------- 3. USER MANAGEMENT ENDPOINTS -----------------
@app.route('/api/admin/users', methods=['GET'])
@admin_required
def list_users():
    status = request.args.get('status')
    search = request.args.get('search')
    # Filter and paginate via SQLAlchemy:
    # query = User.query
    # if status: query = query.filter_by(status=status)
    # ...
    return jsonify({'users': []}), 200

@app.route('/api/admin/users/<user_id>/toggle-status', methods=['PATCH'])
@admin_required
def toggle_user_status(user_id):
    # Safe state toggle in MySQL
    return jsonify({'status': 'success', 'user_id': user_id}), 200

# ----------------- 4. RESUME ANALYSIS OCR & NLP PIPELINE -----------------
@app.route('/api/admin/analyses/<analysis_id>/retry', methods=['POST'])
@admin_required
def retry_resume_analysis(analysis_id):
    # Runs the NLP pipeline:
    # 1. Spacy / PyMuPDF OCR extraction
    # 2. Skill token embedding extraction
    # 3. Weighted ATS mathematical calculation against job_role required skills
    return jsonify({'status': 'reprocessed', 'analysisId': analysis_id, 'atsScore': 79}), 200

if __name__ == '__main__':
    # Flask port 5000 for local development
    app.run(host='0.0.0.0', port=5000, debug=True)
`;
