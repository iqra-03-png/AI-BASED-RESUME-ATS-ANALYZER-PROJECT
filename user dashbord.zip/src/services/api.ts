import {
  User,
  ResumeFile,
  ExtractedResumeData,
  JobDomain,
  SkillItem,
  AnalysisReport,
  ResumeTemplate,
  ResumeDraft,
  ChatMessage,
  InterviewPrepData,
} from '../types';

const TOKEN_KEY = 'resunova_auth_token';

export function getStoredToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setStoredToken(token: string | null) {
  if (token) {
    localStorage.setItem(TOKEN_KEY, token);
  } else {
    localStorage.removeItem(TOKEN_KEY);
  }
}

async function fetchApi<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const token = getStoredToken();
  const headers = new Headers(options.headers || {});

  if (token) {
    headers.set('Authorization', `Bearer ${token}`);
  }

  if (!headers.has('Content-Type') && !(options.body instanceof FormData)) {
    headers.set('Content-Type', 'application/json');
  }

  const response = await fetch(`/api${endpoint}`, {
    ...options,
    headers,
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(data.error || `Request failed with status ${response.status}`);
  }

  return data as T;
}

export const api = {
  // Auth
  async register(name: string, email: string, password: string) {
    const res = await fetchApi<{ user: User; token: string }>('/auth/register', {
      method: 'POST',
      body: JSON.stringify({ name, email, password }),
    });
    setStoredToken(res.token);
    return res;
  },

  async login(email: string, password: string) {
    const res = await fetchApi<{ user: User; token: string }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    setStoredToken(res.token);
    return res;
  },

  async getMe() {
    return fetchApi<{ user: User }>('/auth/me');
  },

  async updateProfile(payload: { name?: string; email?: string; currentPassword?: string; newPassword?: string }) {
    return fetchApi<{ user: User; message: string }>('/auth/update-profile', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  async upgradePlan() {
    return fetchApi<{ user: User; message: string }>('/auth/upgrade-plan', {
      method: 'POST',
    });
  },

  logout() {
    setStoredToken(null);
  },

  // Resumes
  async uploadResume(file: File) {
    const formData = new FormData();
    formData.append('resume', file);
    return fetchApi<{ message: string; resume: ResumeFile; extractedData: ExtractedResumeData }>(
      '/resume/upload',
      {
        method: 'POST',
        body: formData,
      }
    );
  },

  async updateExtractedData(resumeId: string, extractedData: ExtractedResumeData) {
    return fetchApi<{ resume: ResumeFile; message: string }>(`/resume/${resumeId}/update-extracted`, {
      method: 'POST',
      body: JSON.stringify({ extractedData }),
    });
  },

  async getMyResumes() {
    return fetchApi<{ resumes: ResumeFile[] }>('/resume/my-resumes');
  },

  // Analysis
  async analyzeResume(payload: {
    resumeId: string;
    domain: string;
    role: string;
    jobDescription?: string;
    extractedDataOverride?: ExtractedResumeData;
  }) {
    return fetchApi<{ report: AnalysisReport }>('/resume/analyze', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  // History
  async getHistory() {
    return fetchApi<{ reports: AnalysisReport[] }>('/history');
  },

  async getReport(id: string) {
    return fetchApi<{ report: AnalysisReport }>(`/history/${id}`);
  },

  async deleteReport(id: string) {
    return fetchApi<{ message: string }>(`/history/${id}`, {
      method: 'DELETE',
    });
  },

  async compareReports(id1: string, id2: string) {
    return fetchApi<{ report1: AnalysisReport; report2: AnalysisReport }>(
      `/history/compare/${id1}/${id2}`
    );
  },

  // Interview Prep
  async getInterviewPrep(payload: { role: string; domain: string; skills: string[]; projects: any[] }) {
    return fetchApi<InterviewPrepData>('/interview/prep', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  async evaluateInterviewAnswer(payload: { question: string; userAnswer: string; role: string }) {
    return fetchApi<{
      rating: number;
      verdict: string;
      feedback: string;
      strengths: string[];
      improvements: string[];
    }>('/interview/evaluate-answer', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  // Templates
  async getTemplates() {
    return fetchApi<{ templates: ResumeTemplate[] }>('/templates');
  },

  async getTemplate(id: string) {
    return fetchApi<{ template: ResumeTemplate }>(`/templates/${id}`);
  },

  async purchaseTemplate(id: string) {
    return fetchApi<{ message: string; templateId: string; isUnlocked: boolean }>(
      `/templates/${id}/purchase`,
      { method: 'POST' }
    );
  },

  async saveDraft(templateId: string, title: string, data: any) {
    return fetchApi<{ draft: ResumeDraft; message: string }>(`/templates/${templateId}/draft`, {
      method: 'POST',
      body: JSON.stringify({ title, data }),
    });
  },

  async getDraft(templateId: string) {
    return fetchApi<{ draft: ResumeDraft | null }>(`/templates/${templateId}/draft`);
  },

  async getAllDrafts() {
    return fetchApi<{ drafts: ResumeDraft[] }>('/templates/drafts/all');
  },

  // Chatbot
  async sendChatMessage(message: string, context?: any) {
    return fetchApi<{ reply: string; messageId: string }>('/chat', {
      method: 'POST',
      body: JSON.stringify({ message, context }),
    });
  },

  async getChatHistory() {
    return fetchApi<{ messages: ChatMessage[] }>('/chat/history');
  },

  async clearChat() {
    return fetchApi<{ message: string }>('/chat/clear', {
      method: 'DELETE',
    });
  },

  // Admin
  async getAdminOverview() {
    return fetchApi<{
      totalUsers: number;
      totalResumes: number;
      totalAnalyses: number;
      totalDomains: number;
      totalSkills: number;
      avgScore: number;
      popularDomains: Array<{ name: string; count: number }>;
      recentReports: AnalysisReport[];
      recentUsers: User[];
    }>('/admin/overview');
  },

  async getAdminUsers() {
    return fetchApi<{ users: User[] }>('/admin/users');
  },

  async updateAdminUserRole(userId: string, role: 'admin' | 'user') {
    return fetchApi<{ user: User; message: string }>(`/admin/users/${userId}/role`, {
      method: 'PUT',
      body: JSON.stringify({ role }),
    });
  },

  async deleteAdminUser(userId: string) {
    return fetchApi<{ message: string }>(`/admin/users/${userId}`, {
      method: 'DELETE',
    });
  },

  async getAdminDomains() {
    return fetchApi<{ domains: JobDomain[] }>('/admin/domains');
  },

  async createAdminDomain(domain: Partial<JobDomain>) {
    return fetchApi<{ domain: JobDomain }>('/admin/domains', {
      method: 'POST',
      body: JSON.stringify(domain),
    });
  },

  async updateAdminDomain(id: string, domain: Partial<JobDomain>) {
    return fetchApi<{ domain: JobDomain }>(`/admin/domains/${id}`, {
      method: 'PUT',
      body: JSON.stringify(domain),
    });
  },

  async deleteAdminDomain(id: string) {
    return fetchApi<{ message: string }>(`/admin/domains/${id}`, {
      method: 'DELETE',
    });
  },

  async getAdminSkills() {
    return fetchApi<{ skills: SkillItem[] }>('/admin/skills');
  },

  async createAdminSkill(skill: Partial<SkillItem>) {
    return fetchApi<{ skill: SkillItem }>('/admin/skills', {
      method: 'POST',
      body: JSON.stringify(skill),
    });
  },

  async updateAdminSkill(id: string, skill: Partial<SkillItem>) {
    return fetchApi<{ skill: SkillItem }>(`/admin/skills/${id}`, {
      method: 'PUT',
      body: JSON.stringify(skill),
    });
  },

  async deleteAdminSkill(id: string) {
    return fetchApi<{ message: string }>(`/admin/skills/${id}`, {
      method: 'DELETE',
    });
  },

  async getAdminTemplates() {
    return fetchApi<{ templates: ResumeTemplate[] }>('/admin/templates');
  },

  async createAdminTemplate(template: Partial<ResumeTemplate>) {
    return fetchApi<{ template: ResumeTemplate }>('/admin/templates', {
      method: 'POST',
      body: JSON.stringify(template),
    });
  },

  async updateAdminTemplate(id: string, template: Partial<ResumeTemplate>) {
    return fetchApi<{ template: ResumeTemplate; message: string }>(`/admin/templates/${id}`, {
      method: 'PUT',
      body: JSON.stringify(template),
    });
  },

  async duplicateAdminTemplate(id: string) {
    return fetchApi<{ template: ResumeTemplate; message: string }>(
      `/admin/templates/${id}/duplicate`,
      { method: 'POST' }
    );
  },

  async deleteAdminTemplate(id: string) {
    return fetchApi<{ message: string }>(`/admin/templates/${id}`, {
      method: 'DELETE',
    });
  },

  async getAdminAnalyses() {
    return fetchApi<{ reports: AnalysisReport[] }>('/admin/analyses');
  },

  async getAdminAnalytics() {
    return fetchApi<{
      totalUsers: number;
      premiumUsers: number;
      totalAnalyses: number;
      totalTemplates: number;
      publishedTemplates: number;
      scoreBuckets: Record<string, number>;
    }>('/admin/analytics');
  },
};
